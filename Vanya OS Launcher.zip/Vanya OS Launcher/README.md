# Vanya OS

Vanya OS — Python/Tkinter desktop environment with internal windows, Explorer, Notes, Games, Terminal, Store, Task Manager, Control Center and many built-in tools.

## Новое

- 🖥️ Значки рабочего стола можно перетаскивать мышкой.
- 💾 Раскладка значков сохраняется в `desktop_icons.json`.
- 📌 Панель задач в стиле Windows 10.
- 📁 Проводник, 📝 Заметки и 🎮 Игры закреплены по центру панели задач.
- 🔎 Поиск на панели задач.
- 🧰 50 встроенных функций Vanya OS.

## Запуск

### macOS / Linux

```bash
python3 vanya_desktop.py
```

### Windows

```bat
py -3 vanya_desktop.py
```

Если используются дополнительные зависимости, установите их согласно окружению Python.

## Структура

- `vanya_desktop.py` — основной графический интерфейс
- `vanya_os.py` — консольные функции
- `vanya_classic.py` — классические функции и игры
- `desktop_icons.json` — сохранённое расположение значков
- `mods/` — моды Vanya OS
- `notes/` — заметки
- `vanya_apps/` — встроенные приложения

## Лицензия

MIT — см. `LICENSE`.

> В папке `eaglercraft/` находится заглушка/пользовательский контент. Не добавляйте сторонний Eaglercraft-код без проверки его лицензии и разрешения на распространение.
