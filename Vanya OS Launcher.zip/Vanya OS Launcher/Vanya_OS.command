#!/bin/bash
cd "$(dirname "$0")"
exec python3 vanya_desktop.py
