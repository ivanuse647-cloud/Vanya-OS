@echo off
cd /d "%~dp0"
where py >nul 2>&1 && (py -3 vanya_desktop.py & exit /b)
where python >nul 2>&1 && (python vanya_desktop.py & exit /b)
echo Python 3 not found.
pause
