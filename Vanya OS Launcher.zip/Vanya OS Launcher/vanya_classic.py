import re
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VANYA OS v16.0 (Python / macOS edition)
Порт vanya_os.bat на Python. Работает на macOS (и вообще везде, где есть Python 3).

Скрипт живёт прямо в папке лаунчера (Vanya OS Launcher) и хранит все свои
данные (моды, дневник, список дел, хранилище, заметки) прямо там же, рядом
с собой — как и .bat-файл раньше. Нужные папки (mods и т.д.) создаются
автоматически и тихо, без вопросов "создать папку?".
"""

import os
import sys
import time
import random
import string
import shutil
import getpass
import platform
import socket
import subprocess
import math
import hashlib
import json as _json
from pathlib import Path
from datetime import datetime

# ============================================================
# ПУТИ И ДАННЫЕ (создаются тихо, без вопросов)
# ============================================================
APP_DIR = Path(__file__).resolve().parent  # папка "Vanya OS Launcher"
MODS_DIR = APP_DIR / "mods"
STORAGE_DIR = APP_DIR / "secret_files"
NOTES_DIR = APP_DIR / "notes"
DIARY_FILE = APP_DIR / "secret.txt"
TODO_FILE = APP_DIR / "todo.txt"
SETTINGS_FILE = APP_DIR / "vanya_settings.txt"

# тихо создаём нужные папки прямо в папке лаунчера, без вопросов
for _d in (MODS_DIR, STORAGE_DIR, NOTES_DIR):
    _d.mkdir(parents=True, exist_ok=True)

VERSION = "27.1"

# ============================================================
# ЦВЕТА (ANSI вместо Windows `color`)
# ============================================================
RESET = "\033[0m"
BOLD = "\033[1m"

# карта "цвет CMD" -> ANSI-код текста (приближённо)
CMD_TO_ANSI = {
    "0": "30", "1": "34", "2": "32", "3": "36",
    "4": "31", "5": "35", "6": "33", "7": "37",
    "8": "90", "9": "94", "A": "92", "B": "96",
    "C": "91", "D": "95", "E": "93", "F": "97",
}
HEX_CHARS = "0123456789ABCDEF"

STATE = {
    "fg": "92",  # ярко-зелёный по умолчанию, как классический терминал хакера
}


def c(text, code=None):
    """Раскрасить текст текущим (или заданным) цветом темы."""
    code = code or STATE["fg"]
    return f"\033[{code}m{text}{RESET}"


def cls():
    os.system("clear" if os.name != "nt" else "cls")


def pause(msg="Нажми Enter, чтобы продолжить..."):
    try:
        input(c(msg))
    except (EOFError, KeyboardInterrupt):
        pass


def ask(prompt):
    try:
        return input(c(prompt)).strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def line(ch="=", n=58):
    print(c(ch * n))


def header(title):
    cls()
    line()
    print(c(f"  {title}"))
    line()
    print()


def sleep(sec):
    try:
        time.sleep(sec)
    except KeyboardInterrupt:
        pass


# ============================================================
# СИСТЕМА МОДОВ
# ============================================================
def parse_mod_file(path: Path):
    mod = {
        "file": path,
        "name": path.stem,
        "author": "",
        "description": "",
        "color": "",
        "title": "",
        "status": "1",
        "compat": "1",
    }
    key_map = {
        "[MOD_NAME]": "name",
        "[MOD_AUTHOR]": "author",
        "[MOD_DESCRIPTION]": "description",
        "[CHANGE_COLOR]": "color",
        "[CHANGE_TITLE]": "title",
        "[MOD_STATUS]": "status",
        "[MOD_COMPAT]": "compat",
    }
    current_key = None
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return mod
    for raw_line in text.splitlines():
        stripped = raw_line.strip()
        if stripped.startswith("[") and stripped.endswith("]"):
            current_key = stripped
            continue
        if not stripped:
            continue
        if current_key in key_map:
            mod[key_map[current_key]] = stripped
    if not mod["name"]:
        mod["name"] = path.stem
    return mod


def load_mods():
    files = sorted(MODS_DIR.glob("*.txt"))
    return [parse_mod_file(f) for f in files]


def apply_mods(mods):
    """Возвращает (custom_title, custom_fg_ansi, active_count, active_names)"""
    custom_title = f"VANYA OS v{VERSION}"
    custom_fg = "92"
    active = [m for m in mods if m["status"] == "1" and m["compat"] == "1"]
    names = []
    for m in active:
        names.append(m["name"])
        if m["color"]:
            # берём последний символ CMD-кода как цвет текста
            ch = m["color"].strip()[-1].upper()
            if ch in CMD_TO_ANSI:
                custom_fg = CMD_TO_ANSI[ch]
        if m["title"]:
            custom_title = m["title"]
    return custom_title, custom_fg, len(active), names


def mod_status_text(m):
    if m["status"] == "1":
        return "[OK] РАБОТАЕТ" if m["compat"] == "1" else "[~] БЕЗОПАСНЫЙ"
    return "[X] ОТКЛЮЧЁН"


# ============================================================
# 1. СИСТЕМНЫЙ МОНИТОР / 4. ИНФОРМАЦИЯ О СИСТЕМЕ
# ============================================================
def run_cmd(args, timeout=5):
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return r.stdout.strip()
    except Exception:
        return ""


def sys_monitor():
    header("СИСТЕМНЫЙ МОНИТОР")
    print(f"  Компьютер:   {platform.node()}")
    print(f"  Пользователь:{getpass.getuser()}")
    print(f"  Процессор:   {platform.processor() or run_cmd(['sysctl', '-n', 'machdep.cpu.brand_string'])}")
    print(f"  Архитектура: {platform.machine()}")
    print(f"  Ядер:        {os.cpu_count()}")
    print(f"  Время:       {datetime.now().strftime('%H:%M:%S')}")
    print(f"  Дата:        {datetime.now().strftime('%d.%m.%Y')}")
    print()
    line()
    pause()


def about_os():
    header(f"VANYA OS v{VERSION} - ИНФОРМАЦИЯ")
    mods = load_mods()
    _, _, active_count, _ = apply_mods(mods)
    mem_bytes = run_cmd(["sysctl", "-n", "hw.memsize"])
    try:
        mem_gb = round(int(mem_bytes) / (1024 ** 3), 2)
    except ValueError:
        mem_gb = "?"
    cpu_name = run_cmd(["sysctl", "-n", "machdep.cpu.brand_string"]) or platform.processor()
    print(f"  Компьютер:  {platform.node()}")
    print(f"  Пользователь: {getpass.getuser()}")
    print(f"  ОС:         {platform.system()} {platform.mac_ver()[0] or platform.release()}")
    print(f"  Версия:     {platform.version()}")
    print(f"  CPU:        {cpu_name}")
    print(f"  RAM:        {mem_gb} ГБ")
    print(f"  Python:     {platform.python_version()}")
    print()
    print(f"  Версия VANYA OS: {VERSION}")
    print(f"  Модов активно: {active_count} из {len(mods)}")
    print()
    print('  "Лучшая ОС в мире!" (c) Ваня')
    line()
    pause()


def calendar_view():
    header("ДАТА И ВРЕМЯ")
    now = datetime.now()
    print(f"  Сегодня: {now.strftime('%d.%m.%Y')}")
    print(f"  Время:   {now.strftime('%H:%M:%S')}")
    print()
    line()
    pause()


# ============================================================
# 2. ДИСПЕТЧЕР ЗАДАЧ
# ============================================================
def task_manager():
    header("ДИСПЕТЧЕР ЗАДАЧ")
    out = run_cmd(["ps", "-A", "-o", "pid,comm"], timeout=5)
    lines = out.splitlines()
    for l in lines[:40]:
        print("  " + l)
    if len(lines) > 40:
        print(f"  ... и ещё {len(lines) - 40} процессов")
    print()
    print("  1 - Завершить процесс (по имени)")
    print("  0 - Назад")
    print()
    choice = ask("Выбор: ")
    if choice == "1":
        name = ask("Имя процесса: ")
        if name:
            r = subprocess.run(["pkill", "-f", name], capture_output=True)
            print("[OK] Завершён!" if r.returncode == 0 else "[!] Не найден!")
    pause()


# ============================================================
# 3. СЕТЬ
# ============================================================
def network_info():
    while True:
        header("СЕТЕВЫЕ НАСТРОЙКИ")
        try:
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
        except socket.error:
            ip = "не удалось определить"
        print(f"  IPv4: {ip}")
        print()
        print("  1 - Полная информация (ifconfig)")
        print("  2 - Пинг Yandex")
        print("  3 - Пинг Google")
        print("  0 - Назад")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            print(run_cmd(["ifconfig"], timeout=5))
            pause()
        elif choice == "2":
            subprocess.run(["ping", "-c", "4", "yandex.ru"])
            pause()
        elif choice == "3":
            subprocess.run(["ping", "-c", "4", "google.com"])
            pause()


# ============================================================
# 6. КАЛЬКУЛЯТОР
# ============================================================
def calculator():
    header("КАЛЬКУЛЯТОР VANYA OS")
    print("  Операции: + - * /")
    print('  Пример: 5 + 3')
    print('  Введи "exit" для выхода')
    print()
    allowed = set("0123456789+-*/. ")
    while True:
        expr = ask("VANYA CALC> ")
        if expr.lower() == "exit":
            return
        if not expr:
            continue
        if not set(expr) <= allowed:
            print("[!] Только цифры и + - * /")
            continue
        try:
            result = eval(expr, {"__builtins__": {}}, {})
            print(f"  = {result}")
        except Exception:
            print("[!] Ошибка!")


# ============================================================
# 7. БЛОКИРОВКА ЭКРАНА
# ============================================================
def lock_screen():
    cls()
    old_fg = STATE["fg"]
    STATE["fg"] = "91"
    print()
    print(c("  ==============================="))
    print(c("     ЭКРАН ЗАБЛОКИРОВАН"))
    print(c("  Нажми любую клавишу"))
    print(c("  ==============================="))
    print()
    pause("")
    STATE["fg"] = old_fg


# ============================================================
# 8. ПИТАНИЕ
# ============================================================
def power_menu():
    header("МЕНЮ ПИТАНИЯ")
    print("  1 - Выключить")
    print("  2 - Перезагрузить")
    print("  3 - Сон")
    print("  4 - Выйти из учётки")
    print("  0 - Отмена")
    print()
    choice = ask("Выбор: ")
    if choice == "0":
        return
    confirm = ask('Точно? Набери "да": ')
    if confirm.lower() != "да":
        print("[ОТМЕНА]")
        pause()
        return
    if choice == "1":
        subprocess.run(["osascript", "-e", 'tell application "System Events" to shut down'])
    elif choice == "2":
        subprocess.run(["osascript", "-e", 'tell application "System Events" to restart'])
    elif choice == "3":
        subprocess.run(["pmset", "sleepnow"])
    elif choice == "4":
        subprocess.run(["osascript", "-e", 'tell application "System Events" to log out'])
    pause()


# ============================================================
# 9 / A / V / W / 16. ИНТЕРНЕТ-ФУНКЦИИ
# ============================================================
def open_browser(url):
    try:
        subprocess.run(["open", url], check=False)
    except Exception:
        import webbrowser
        webbrowser.open(url)


def web_search():
    header("ПОИСК В YANDEX")
    query = ask("Что ищем?: ")
    if not query:
        return
    encoded = query.replace(" ", "+")
    open_browser(f"https://ya.ru/search/?text={encoded}")
    print("[OK] Поиск активирован!")
    pause()


def open_youtube():
    header("ОТКРЫТИЕ YOUTUBE")
    open_browser("https://www.youtube.com")
    print("Портал открыт!")
    pause()


def wikipedia():
    header("ПОИСК В ВИКИПЕДИИ")
    query = ask("Что ищем?: ")
    if not query:
        return
    encoded = query.replace(" ", "+")
    open_browser(f"https://ru.wikipedia.org/wiki/Special:Search?search={encoded}")
    print("[OK] Поиск активирован!")
    pause()


def weather():
    header("ПОГОДА")
    print("[СИСТЕМА]: Открываю сайт погоды...")
    open_browser("https://yandex.ru/pogoda/")
    print("[OK] Сайт открыт!")
    pause()


def qr_generator():
    header("ГЕНЕРАТОР QR-КОДОВ")
    text = ask("Текст или ссылка: ")
    if not text:
        return
    encoded = text.replace(" ", "%20")
    print("[СИСТЕМА]: Открываю генератор...")
    open_browser(f"https://api.qrserver.com/v1/create-qr-code/?size=300x300&data={encoded}")
    print("[OK] QR-код создан!")
    pause()


# ============================================================
# B. СИМУЛЯТОР ОШИБКИ (через osascript display dialog)
# ============================================================
def show_error():
    header("СИМУЛЯТОР ОШИБКИ (окно macOS)")
    title = ask("Заголовок: ") or "Ошибка"
    text = ask("Текст: ") or "Произошла ошибка."
    print()
    print("  1 - OK")
    print("  2 - OK / Отмена")
    print("  3 - Да / Нет")
    print()
    buttons_choice = ask("Выбор (1-3): ")
    buttons_map = {
        "1": '{"OK"}',
        "2": '{"Отмена", "OK"}',
        "3": '{"Нет", "Да"}',
    }
    buttons = buttons_map.get(buttons_choice, '{"OK"}')
    safe_title = title.replace('"', "'")
    safe_text = text.replace('"', "'")
    script = f'display dialog "{safe_text}" with title "{safe_title}" buttons {buttons} default button 1'
    subprocess.run(["osascript", "-e", script], capture_output=True)
    print("[OK] Окно показано!")
    pause()


# ============================================================
# C. ЗАПУСК ПРОГРАММЫ / D. ОТКРЫТИЕ ПАПКИ
# ============================================================
def run_program():
    header("ЗАПУСК ПРОГРАММЫ")
    print("  Примеры: TextEdit, Calculator, Safari")
    print()
    name = ask("Название приложения: ")
    if not name:
        return
    subprocess.run(["open", "-a", name], capture_output=True)
    print("[OK] Запущено (если приложение найдено)!")
    pause()


def open_folder():
    header("ОТКРЫТИЕ ПАПКИ")
    home = Path.home()
    print("  1 - Рабочий стол")
    print("  2 - Загрузки")
    print("  3 - Документы")
    print("  4 - Изображения")
    print("  5 - Папка Vanya OS Launcher")
    print("  6 - Свой путь")
    print()
    choice = ask("Выбор (1-6): ")
    targets = {
        "1": home / "Desktop",
        "2": home / "Downloads",
        "3": home / "Documents",
        "4": home / "Pictures",
        "5": APP_DIR,
    }
    if choice in targets:
        subprocess.run(["open", str(targets[choice])])
    elif choice == "6":
        custom = ask("Путь: ")
        if custom and Path(custom).expanduser().exists():
            subprocess.run(["open", str(Path(custom).expanduser())])
        else:
            print("[!] Не найден!")
    pause()


# ============================================================
# E. СЕКРЕТНЫЙ ДНЕВНИК
# ============================================================
def secret_diary():
    while True:
        header("СЕКРЕТНЫЙ ДНЕВНИК")
        print("  1 - Написать")
        print("  2 - Прочитать")
        print("  3 - Открыть папку")
        print("  4 - Удалить")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            text = ask("Запись: ")
            if text:
                with open(DIARY_FILE, "a", encoding="utf-8") as f:
                    f.write(f"[{datetime.now().strftime('%d.%m.%Y %H:%M:%S')}] {text}\n")
                print("[OK] Сохранено!")
            pause()
        elif choice == "2":
            header("ЧТЕНИЕ ДНЕВНИКА")
            if DIARY_FILE.exists():
                print(DIARY_FILE.read_text(encoding="utf-8"))
            else:
                print("[!] Дневник пуст.")
            pause()
        elif choice == "3":
            subprocess.run(["open", str(APP_DIR)])
        elif choice == "4":
            confirm = ask("Удалить? (да/нет): ")
            if confirm.lower() == "да":
                DIARY_FILE.unlink(missing_ok=True)
                print("[OK] Удалён!")
            else:
                print("[ОТМЕНА]")
            pause()


# ============================================================
# F. СЕКРЕТНОЕ ХРАНИЛИЩЕ
# ============================================================
def secret_storage():
    while True:
        header("СЕКРЕТНОЕ ХРАНИЛИЩЕ")
        print("  1 - Загрузить файл")
        print("  2 - Просмотреть")
        print("  3 - Открыть папку")
        print("  4 - Удалить файл")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            path = ask("Путь к файлу: ")
            src = Path(path).expanduser() if path else None
            if not src or not src.exists():
                print("[!] Не найден!")
            else:
                dst = STORAGE_DIR / src.name
                shutil.copy(src, dst)
                print(f'[OK] Файл "{src.name}" загружен!')
            pause()
        elif choice == "2":
            header("ФАЙЛЫ В ХРАНИЛИЩЕ")
            files = list(STORAGE_DIR.iterdir())
            if not files:
                print("[!] Пусто.")
            else:
                for f in files:
                    print(f"  {f.name}")
            pause()
        elif choice == "3":
            subprocess.run(["open", str(STORAGE_DIR)])
        elif choice == "4":
            files = list(STORAGE_DIR.iterdir())
            if not files:
                print("[!] Пусто.")
                pause()
                continue
            for f in files:
                print(f"  {f.name}")
            name = ask("Имя файла: ")
            target = STORAGE_DIR / name
            if name and target.exists():
                target.unlink()
                print("[OK] Удалён!")
            else:
                print("[!] Не найден!")
            pause()


# ============================================================
# G. МАТРИЦА
# ============================================================
def matrix_effect():
    cls()
    old_fg = STATE["fg"]
    STATE["fg"] = "32"
    print(c('  ПРОТОКОЛ "МАТРИЦА"'))
    sleep(0.6)
    cls()
    words = ["10101010", "CHIKINGAN"]
    for _ in range(30):
        parts = [str(random.randint(0, 99999)) for _ in range(2)]
        line_txt = f"{parts[0]} {random.choice(words)} {parts[1]}"
        print(c(line_txt))
    STATE["fg"] = "92"
    print()
    print(c("[OK] Матрица расшифрована."))
    sleep(1)


# ============================================================
# H. ВЗЛОМ КОДА
# ============================================================
def hack_game():
    header("ВЗЛОМ СЕКРЕТНОГО КОДА")
    print("[СИСТЕМА]: Я загадал число от 1 до 100.")
    print()
    secret = random.randint(1, 100)
    attempts = 0
    while True:
        guess = ask("Догадка (или exit): ")
        if guess.lower() == "exit":
            return
        if not guess.isdigit():
            print("[!] Введи число!")
            continue
        attempts += 1
        n = int(guess)
        if n < secret:
            print("[СИСТЕМА]: БОЛЬШЕ!")
        elif n > secret:
            print("[СИСТЕМА]: МЕНЬШЕ!")
        else:
            break
    header("ВЗЛОМ УСПЕШЕН!")
    print(f"  Код: {secret} | Попыток: {attempts}")
    print()
    if attempts <= 3:
        rank = "ЛЕГЕНДАРНЫЙ ХАКЕР!"
    elif attempts <= 5:
        rank = "ПРОФЕССИОНАЛ!"
    elif attempts <= 7:
        rank = "ОПЫТНЫЙ ХАКЕР!"
    else:
        rank = "НАЧИНАЮЩИЙ"
    print(f"  [РАНГ]: {rank}")
    print()
    line()
    pause()


# ============================================================
# I. КАМЕНЬ-НОЖНИЦЫ-БУМАГА
# ============================================================
def rock_game():
    names = {"1": "КАМЕНЬ", "2": "НОЖНИЦЫ", "3": "БУМАГА"}
    beats = {"1": "2", "2": "3", "3": "1"}  # ключ побеждает значение
    while True:
        header("КАМЕНЬ-НОЖНИЦЫ-БУМАГА vs ИИ")
        print("  1 - КАМЕНЬ")
        print("  2 - НОЖНИЦЫ")
        print("  3 - БУМАГА")
        print("  0 - Выход")
        print()
        player = ask("Выбор: ")
        if player == "0":
            return
        if player not in names:
            print("[!] 1, 2 или 3!")
            pause()
            continue
        cpu = random.choice(list(names.keys()))
        if player == cpu:
            result = "НИЧЬЯ"
        elif beats[player] == cpu:
            result = "ПОБЕДА!"
        else:
            result = "ПОРАЖЕНИЕ!"
        header("РЕЗУЛЬТАТ!")
        print(f"  ТЫ: {names[player]}")
        print(f"  ИИ: {names[cpu]}")
        print()
        print(f"  >>> {result} <<<")
        print()
        line()
        pause()


# ============================================================
# J. ФАКТ / Y. ШУТКА
# ============================================================
FACTS = [
    "У осьминогов ТРИ сердца!",
    "В Майнкрафте день = 10 минут!",
    "Собаки понимают 250 слов!",
    "Свет от Солнца летит 8 минут!",
    "Мёд никогда не портится!",
]

JOKES = [
    "Почему программисты путают Хэллоуин и Рождество? Потому что OCT 31 = DEC 25!",
    'Что сказал хакер, когда нашёл баг? "Это не баг, это фича!"',
    "Сколько программистов нужно, чтобы вкрутить лампочку? Ни одного!",
    "Почему программист ушёл с работы? Потому что он не получил массив!",
    "Что делает хакер, когда ему скучно? Пишет VANYA OS!",
]


def cool_fact():
    header("СЛУЧАЙНЫЙ ФАКТ")
    print(random.choice(FACTS))
    print()
    line()
    pause()


def random_joke():
    header("СЛУЧАЙНАЯ ШУТКА")
    print(random.choice(JOKES))
    print()
    line()
    pause()


# ============================================================
# K. СКОЛЬКО Я ПРОЖИЛ
# ============================================================
def age_converter():
    header("СКОЛЬКО Я ПРОЖИЛ?")
    age = ask("Сколько лет?: ")
    if not age.replace(".", "", 1).isdigit():
        return
    age_f = float(age)
    days = age_f * 365
    months = age_f * 12
    weeks = days / 7
    hours = days * 24
    minutes = hours * 60
    seconds = minutes * 60
    header("СТАТИСТИКА")
    print(f"  Лет:     {age_f:g}")
    print(f"  Месяцев: {months:.0f}")
    print(f"  Недель:  {weeks:.0f}")
    print(f"  Дней:    {days:.0f}")
    print(f"  Часов:   {hours:.0f}")
    print(f"  Минут:   {minutes:.0f}")
    print(f"  Секунд:  {seconds:.0f}")
    print()
    line()
    pause()


# ============================================================
# L. СЛУЧАЙНЫЙ ЦВЕТ / M. ТЕМА ОФОРМЛЕНИЯ
# ============================================================
def random_color():
    header("СМЕНА ЦВЕТА")
    fg = random.choice(list(CMD_TO_ANSI.values()))
    STATE["fg"] = fg
    hexname = [k for k, v in CMD_TO_ANSI.items() if v == fg][0]
    print(c(f"[OK] Новый цвет темы: {hexname}"))
    print()
    pause()


def screen_settings():
    header("ТЕМА ОФОРМЛЕНИЯ")
    options = list(CMD_TO_ANSI.items())
    for i, (hexcode, ansi) in enumerate(options, start=1):
        print(f"  {i} - Пример цвета \033[{ansi}m{hexcode}{RESET}")
    print("  0 - Отмена")
    print()
    choice = ask("Выбор: ")
    if choice.isdigit() and 1 <= int(choice) <= len(options):
        STATE["fg"] = options[int(choice) - 1][1]
        print("[OK] Тема применена!")
    pause()


# ============================================================
# N. ЯРИК
# ============================================================
YARIK = r"""
     / \__
    (  @  \____      * ТЯФ-ТЯФ! *
     /         O
    /   (_____/    Ярик машет хвостом!
   /_____/
"""


def hello_yarik():
    header("ПРИВЕТ ЯРИКУ!")
    print(YARIK)
    line()
    pause()


def yarik_age():
    header("ВОЗРАСТ ЯРИКА В СОБАЧЬИХ ГОДАХ")
    print(YARIK)
    dog_age = ask("Сколько Ярику лет?: ")
    if not dog_age.replace(".", "", 1).isdigit():
        return
    dog_age_f = float(dog_age)
    dog_years = dog_age_f * 7
    header("ЯРИК - СТАТИСТИКА")
    print(f"  В человеческих: {dog_age_f:g}")
    print(f"  В собачьих:     {dog_years:g}")
    print()
    if dog_years < 14:
        print("  Ярик - ещё щенок!")
    elif dog_years < 35:
        print("  Ярик - молодой пёс!")
    elif dog_years < 50:
        print("  Ярик - взрослый пёс!")
    else:
        print("  Ярик - мудрый пёс!")
    print()
    print("  * ТЯФ-ТЯФ! *")
    print()
    line()
    pause()


# ============================================================
# O. ГЕНЕРАТОР ПАРОЛЕЙ
# ============================================================
def generate_password():
    header("ГЕНЕРАТОР ПАРОЛЕЙ")
    for_what = ask("Для чего?: ")
    n1 = random.randint(1000, 9999)
    n2 = random.randint(1000, 9999)
    pw = f"VanyaHacker{n1}_{n2}_2026!"
    print()
    print(f'  Пароль для "{for_what}":')
    print(f"  >>> {pw} <<<")
    print()
    pause()


# ============================================================
# P. ОЧИСТКА КЭША
# ============================================================
def clear_cache():
    header("ОЧИСТКА КЭША")
    cleared = 0
    for pycache in APP_DIR.rglob("__pycache__"):
        shutil.rmtree(pycache, ignore_errors=True)
        cleared += 1
    print(f"Кэш очищен! (папок удалено: {cleared})")
    print()
    pause()


# ============================================================
# R. КУБИК
# ============================================================
DICE_FACES = {
    1: ["     *     "],
    2: ["  *     *  "],
    3: ["  *   *   *"],
    4: ["  *  *  *  "],
    5: ["  * * * * *"],
    6: [" * * * * * "],
}


def dice_roll():
    while True:
        header("КУБИК")
        print("  Бросаю...")
        sleep(0.5)
        dice = random.randint(1, 6)
        print("  +-----------+")
        print("  |           |")
        print(f"  |{DICE_FACES[dice][0]}|")
        print("  |           |")
        print("  +-----------+")
        print()
        print(f"  Выпало: {dice}")
        print()
        line()
        print()
        print("  1 - Ещё раз")
        print("  0 - Выход")
        print()
        again = ask("Выбор: ")
        if again != "1":
            return


# ============================================================
# S. СЕКУНДОМЕР
# ============================================================
def stopwatch():
    while True:
        header("СЕКУНДОМЕР")
        print("  1 - Засечь время")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            header("ЗАСЕЧКА ВРЕМЕНИ")
            print("  Нажми Enter, чтобы СТАРТовать, потом ещё раз, чтобы СТОП!")
            print()
            pause("Нажми Enter для старта...")
            start = time.time()
            pause("Нажми Enter для стоп...")
            elapsed = time.time() - start
            header("РЕЗУЛЬТАТ")
            print(f"  Прошло времени: {elapsed:.2f} сек")
            print()
            line()
            pause()


# ============================================================
# T. БЫСТРАЯ ЗАМЕТКА
# ============================================================
def quick_note():
    header("БЫСТРАЯ ЗАМЕТКА")
    name = ask("Имя файла (без .txt): ")
    if not name:
        return
    text = ask("Текст: ")
    if not text:
        return
    note_path = NOTES_DIR / f"{name}.txt"
    note_path.write_text(text + "\n", encoding="utf-8")
    print()
    print(f'[OK] Заметка "{name}.txt" сохранена в папке notes рядом со скриптом!')
    print()
    pause()


# ============================================================
# U. ASCII-АРТ
# ============================================================
ASCII_ART = {
    "1": ("Домик", r"""
         /\
        /  \
       /    \
      /______\
      |      |
      |  /\  |
      | /  \ |
      |/    \|
      |______|
"""),
    "2": ("Котик", r"""
     /\_/\
    ( o.o )
     >   <
    /|   |\
   (_|   |_)
"""),
    "3": ("Ракета", r"""
        /\
       /  \
      |    |
      | VA |
      | NY |
      | A  |
      |    |
     /|____\
    / |    | \
   /__|____|__\
      |    |
      |____|
     /______\
"""),
    "4": ("Сердце", r"""
    ***   ***
  **   ***   **
 **     *     **
 **           **
  **         **
   **       **
    **     **
     **   **
      ** **
       ***
        *
"""),
    "5": ("Звезда", r"""
         *
        ***
       *****
      *******
     *********
    ***********
   *************
  ***************
 *****************
*******************
"""),
}


def ascii_art():
    while True:
        header("ASCII-АРТ")
        for k, (name, _) in ASCII_ART.items():
            print(f"  {k} - {name}")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        if choice in ASCII_ART:
            header(ASCII_ART[choice][0])
            print(ASCII_ART[choice][1])
            pause()


# ============================================================
# X. ТАЙМЕР ДЛЯ УРОКОВ
# ============================================================
def study_timer():
    header("ТАЙМЕР ДЛЯ УРОКОВ")
    minutes = ask("Сколько минут? (1-60): ")
    if not minutes.isdigit():
        return
    minutes_n = max(1, min(60, int(minutes)))
    print()
    print(f"[СИСТЕМА]: Таймер на {minutes_n} минут!")
    print("(Ctrl+C чтобы прервать)")
    print()
    try:
        total = minutes_n * 60
        for remaining in range(total, 0, -1):
            mm, ss = divmod(remaining, 60)
            print(f"\r  Осталось: {mm:02d}:{ss:02d} ", end="", flush=True)
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[!] Таймер прерван.")
        pause()
        return
    header("ВРЕМЯ ВЫШЛО! Пора отдохнуть!")
    pause()


# ============================================================
# 10 буквой K уже занята; 11. ГЕНЕРАТОР НИКОВ
# ============================================================
NICK_LISTS = {
    "1": ("ХАКЕРСКИЙ НИК", ["DarkHacker", "CyberVanya", "ShadowByte", "GhostCoder", "NeoHack"]),
    "2": ("МАЙНКРАФТ НИК", ["VanyaCrafter", "DiamondVanya", "BlockMaster", "CreeperHunter", "RedstoneVanya"]),
    "3": ("НИК ВОИНА", ["DragonSlayer", "VanyaTheBrave", "ShadowKnight", "IronFist", "ThunderVanya"]),
}


def nickname_gen():
    while True:
        header("ГЕНЕРАТОР НИКОВ")
        print("  1 - Хакерский")
        print("  2 - Майнкрафт")
        print("  3 - Воин")
        print("  4 - Случайный")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        if choice in NICK_LISTS:
            title, options = NICK_LISTS[choice]
            header(title)
            base = random.choice(options)
            print(f"  >>> {base}{random.randint(1, 9999)} <<<")
            print()
            line()
            pause()
        elif choice == "4":
            header("СЛУЧАЙНЫЙ НИК")
            print(f"  >>> Player_{random.randint(1,9999)}_{random.randint(1,9999)} <<<")
            print()
            line()
            pause()


# ============================================================
# 12. ТЕСТ СКОРОСТИ ПЕЧАТИ
# ============================================================
def typing_test():
    header("ТЕСТ СКОРОСТИ ПЕЧАТИ")
    target = "vanya hacker 2026"
    print(f'  Напечатай: "{target}"')
    print()
    pause("Нажми Enter и начни!")
    start = time.time()
    typed = ask("Печатай: ")
    elapsed = time.time() - start
    print()
    if typed == target:
        print("[OK] Правильно!")
    else:
        print(f'[!] Неверно! Было: "{target}"')
        print(f'    Ты написал: "{typed}"')
    print()
    print(f"  Время: {elapsed:.2f} сек")
    print()
    line()
    pause()


# ============================================================
# 13. БОЛЬШИЕ ЧАСЫ
# ============================================================
def big_clock():
    print(c("Нажми Ctrl+C, чтобы выйти из часов."))
    sleep(1)
    try:
        while True:
            cls()
            now = datetime.now()
            print("\n" * 3)
            print("             +-----------------+")
            print(f"             |    {now.strftime('%H:%M:%S')}    |")
            print("             +-----------------+")
            print()
            print(f"             {now.strftime('%d.%m.%Y')}")
            print("\n" * 3)
            time.sleep(1)
    except KeyboardInterrupt:
        pass


# ============================================================
# 15. КОНВЕРТЕР ЕДИНИЦ
# ============================================================
def _read_float(prompt):
    val = ask(prompt)
    try:
        return float(val)
    except ValueError:
        return None


def unit_converter():
    conversions = {
        "1": ("Метры в футы", "Метры: ", lambda v: (v * 3.28084, "футов")),
        "2": ("Футы в метры", "Футы: ", lambda v: (v * 0.3048, "м")),
        "3": ("Кг в фунты", "Кг: ", lambda v: (v * 2.20462, "фунтов")),
        "4": ("Фунты в кг", "Фунты: ", lambda v: (v * 0.453592, "кг")),
        "5": ("Цельсий в Фаренгейт", "°C: ", lambda v: (v * 9 / 5 + 32, "°F")),
        "6": ("Фаренгейт в Цельсий", "°F: ", lambda v: ((v - 32) * 5 / 9, "°C")),
    }
    while True:
        header("КОНВЕРТЕР ЕДИНИЦ")
        for k, (name, _, _) in conversions.items():
            print(f"  {k} - {name}")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        if choice in conversions:
            name, prompt, fn = conversions[choice]
            val = _read_float(prompt)
            if val is None:
                continue
            result, unit = fn(val)
            print(f"  {val:g} = {round(result, 2):g} {unit}")
            pause()


# ============================================================
# 17. КАЛЬКУЛЯТОР ИМТ
# ============================================================
def bmi_calculator():
    header("КАЛЬКУЛЯТОР ИМТ")
    weight = _read_float("Вес (кг): ")
    if weight is None:
        return
    height_cm = _read_float("Рост (см): ")
    if height_cm is None or height_cm <= 0:
        print("[!] Рост должен быть больше 0!")
        pause()
        return
    height_m = height_cm / 100
    bmi = round(weight / (height_m * height_m), 1)
    header(f"ТВОЙ ИМТ: {bmi}")
    if bmi < 18.5:
        cat = "Недостаточный вес"
    elif bmi < 25:
        cat = "Нормальный вес"
    elif bmi < 30:
        cat = "Избыточный вес"
    else:
        cat = "Ожирение"
    print(f"  Категория: {cat}")
    print()
    line()
    pause()


# ============================================================
# 18. ГЕНЕРАТОР СЛУЧАЙНЫХ ЧИСЕЛ
# ============================================================
def random_number():
    while True:
        header("ГЕНЕРАТОР СЛУЧАЙНЫХ ЧИСЕЛ")
        min_s = ask("Мин: ")
        if not min_s:
            return
        max_s = ask("Макс: ")
        if not max_s:
            return
        try:
            lo, hi = int(min_s), int(max_s)
            if lo > hi:
                lo, hi = hi, lo
            result = random.randint(lo, hi)
        except ValueError:
            print("[!] Введи числа!")
            pause()
            continue
        header(f"СЛУЧАЙНОЕ ЧИСЛО ОТ {lo} ДО {hi}")
        print(f"              {result}")
        line()
        print()
        print("  1 - Ещё раз")
        print("  0 - Выход")
        print()
        again = ask("Выбор: ")
        if again != "1":
            return


# ============================================================
# 19. СИСТЕМЫ СЧИСЛЕНИЯ
# ============================================================
def base_converter():
    while True:
        header("КОНВЕРТЕР СИСТЕМ СЧИСЛЕНИЯ")
        print("  1 - Десятичное в Двоичное")
        print("  2 - Двоичное в Десятичное")
        print("  3 - Десятичное в Шестнадцатеричное")
        print("  4 - Шестнадцатеричное в Десятичное")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        try:
            if choice == "1":
                n = ask("Десятичное: ")
                print(f"  {n} = {bin(int(n))[2:]} (двоичное)")
            elif choice == "2":
                n = ask("Двоичное: ")
                print(f"  {n} = {int(n, 2)} (десятичное)")
            elif choice == "3":
                n = ask("Десятичное: ")
                print(f"  {n} = {hex(int(n))[2:].upper()} (шестнадцатеричное)")
            elif choice == "4":
                n = ask("Шестнадцатеричное: ")
                print(f"  {n} = {int(n, 16)} (десятичное)")
            else:
                continue
        except ValueError:
            print("[!] Неверный формат числа!")
        pause()


# ============================================================
# Z. СПРАВОЧНИК ТЕРМИНАЛА
# ============================================================
def cmd_help():
    header("СПРАВОЧНИК КОМАНД ТЕРМИНАЛА (macOS)")
    lines_help = [
        ("ls", "показать файлы"),
        ("cd", "перейти в папку"),
        ("cd ..", "вернуться назад"),
        ("clear", "очистить экран"),
        ("cp", "копировать файл"),
        ("rm", "удалить файл"),
        ("mkdir", "создать папку"),
        ("cat", "показать файл"),
        ("ping", "проверить соединение"),
        ("ifconfig", "сетевые настройки"),
        ("ps aux", "список процессов"),
        ("kill / pkill", "завершить процесс"),
    ]
    for cmd, desc in lines_help:
        print(f"  {cmd:<12} - {desc}")
    print()
    line()
    pause()


# ============================================================
# Q. СПИСОК ДЕЛ
# ============================================================
def todo_list():
    while True:
        header("СПИСОК ДЕЛ")
        print("  1 - Добавить задачу")
        print("  2 - Показать задачи")
        print("  3 - Очистить список")
        print("  0 - Выход")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            text = ask("Задача: ")
            if text:
                with open(TODO_FILE, "a", encoding="utf-8") as f:
                    f.write(f"[ ] {text}\n")
                print()
                print("[OK] Задача добавлена!")
            pause()
        elif choice == "2":
            header("ТВОИ ЗАДАЧИ")
            if TODO_FILE.exists():
                print(TODO_FILE.read_text(encoding="utf-8"))
            else:
                print("[!] Список пуст.")
            print()
            line()
            pause()
        elif choice == "3":
            confirm = ask("Очистить? (да/нет): ")
            if confirm.lower() == "да":
                TODO_FILE.unlink(missing_ok=True)
                print("[OK] Список очищен!")
            else:
                print("[ОТМЕНА]")
            pause()


# ============================================================
# 20 / 21. УПРАВЛЕНИЕ МОДАМИ
# ============================================================
def mods_manager():
    while True:
        mods = load_mods()
        header("УПРАВЛЕНИЕ МОДАМИ")
        print(f"  Папка: {MODS_DIR}")
        print()
        if not mods:
            print("  [!] Моды не найдены!")
            print(f"  [!] Положи .txt файлы модов в: {MODS_DIR}")
            pause()
            return
        print("  Список модов:")
        print()
        for i, m in enumerate(mods, start=1):
            print(f"  {i}. {m['name']} - {mod_status_text(m)}")
        print()
        line()
        print()
        print(f"  Выбери мод (1-{len(mods)}) или 0 - назад")
        print()
        sel = ask("Выбор: ")
        if sel == "0":
            return
        if sel.isdigit() and 1 <= int(sel) <= len(mods):
            mod_options(mods[int(sel) - 1])
        else:
            print("[!] Неверно!")
            pause()


def mod_options(mod):
    while True:
        mod = parse_mod_file(mod["file"])  # перечитать на случай изменений
        header(f"УПРАВЛЕНИЕ МОДОМ: {mod['name']}")
        print(f"  Статус: {mod_status_text(mod)}")
        print()
        print("  1 - Переключить статус")
        print("  2 - Изменить режим совместимости")
        print("  3 - Просмотреть мод")
        print("  0 - Назад")
        print()
        action = ask("Выбор: ")
        if action == "0":
            return
        elif action == "1":
            new_status = "0" if mod["status"] == "1" else "1"
            _replace_mod_field(mod["file"], "MOD_STATUS", new_status)
            print("[OK] Мод включён!" if new_status == "1" else "[OK] Мод отключён!")
            pause()
        elif action == "2":
            header("РЕЖИМ СОВМЕСТИМОСТИ")
            print(f"  Мод: {mod['name']}")
            print()
            print("  [OK] Обычный режим" if mod["compat"] == "1" else "  [~] Безопасный режим")
            print()
            print("  1 - Обычный")
            print("  2 - Безопасный")
            print("  0 - Отмена")
            print()
            new_compat_choice = ask("Выбор: ")
            if new_compat_choice == "0":
                continue
            new_compat = "1" if new_compat_choice == "1" else "0"
            _replace_mod_field(mod["file"], "MOD_COMPAT", new_compat)
            print("[OK] Обычный режим!" if new_compat == "1" else "[OK] Безопасный режим!")
            pause()
        elif action == "3":
            header("ИНФОРМАЦИЯ О МОДЕ")
            print(f"  Файл: {mod['file'].name}")
            print()
            line("-")
            print(mod["file"].read_text(encoding="utf-8", errors="ignore"))
            line("-")
            print()
            pause()


def _replace_mod_field(path: Path, key: str, new_value: str):
    """Заменить значение под [KEY] в файле мода (первая строка после заголовка)."""
    text = path.read_text(encoding="utf-8", errors="ignore")
    raw_lines = text.splitlines()
    out_lines = []
    target = f"[{key}]"
    i = 0
    replaced = False
    while i < len(raw_lines):
        out_lines.append(raw_lines[i])
        if raw_lines[i].strip() == target and not replaced:
            i += 1
            if i < len(raw_lines):
                out_lines.append(new_value)
                replaced = True
                i += 1
                continue
        i += 1
    if not replaced:
        out_lines.append(target)
        out_lines.append(new_value)
    path.write_text("\n".join(out_lines) + "\n", encoding="utf-8")


def create_mod():
    header("СОЗДАТЬ НОВЫЙ МОД")
    name = ask("Название: ")
    if not name:
        return
    author = ask("Автор: ") or "Ваня"
    desc = ask("Описание: ") or "Пользовательский мод"
    print()
    print("  1 - Изменить цвет")
    print("  2 - Изменить заголовок")
    print("  3 - Полный мод")
    print()
    mod_type = ask("Выбор: ")

    color = title = ""
    if mod_type == "1":
        color = ask("Цвет (0A, 0B, 0C, 0E): ")
    elif mod_type == "2":
        title = ask("Заголовок: ")
    elif mod_type == "3":
        color = ask("Цвет: ")
        title = ask("Заголовок: ")
    else:
        return

    mod_file = MODS_DIR / f"{name}.txt"
    parts = [
        "[MOD_NAME]", name, "",
        "[MOD_AUTHOR]", author, "",
        "[MOD_DESCRIPTION]", desc, "",
    ]
    if color:
        parts += ["[CHANGE_COLOR]", color, ""]
    if title:
        parts += ["[CHANGE_TITLE]", title, ""]
    parts += ["[MOD_STATUS]", "1", "", "[MOD_COMPAT]", "1"]
    mod_file.write_text("\n".join(parts) + "\n", encoding="utf-8")

    print()
    print(f"[OK] Мод создан: {mod_file}")
    pause()


# ============================================================
# НОВОЕ В v17.0: VANYA EXPLORER, STORE, TERMINAL, NOTES,
# СИСТЕМНАЯ ИНФОРМАЦИЯ, НАСТРОЙКИ, О ПРОГРАММЕ
# (существующие функции и меню выше не менялись)
# ============================================================
def _human_size(num_bytes):
    try:
        n = float(num_bytes)
    except (TypeError, ValueError):
        return "?"
    for unit in ["Б", "КБ", "МБ", "ГБ", "ТБ"]:
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} ПБ"


def _edit_text_file(path: Path):
    """Встроенный текстовый редактор (используется в Explorer и Notes)."""
    header(f"РЕДАКТОР — {path.name}")
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except OSError as ex:
        print(f"[!] Не удалось открыть файл: {ex}")
        pause()
        return
    print("  --- Текущее содержимое ---")
    print(content if content else "(пусто)")
    print("  --------------------------")
    print()
    print("  1 - Заменить весь текст")
    print("  2 - Дописать текст в конец")
    print("  0 - Назад без сохранения")
    print()
    choice = ask("Выбор: ")
    if choice == "1":
        print('  Введи новый текст. Строка "." отдельно завершает ввод.')
        new_lines = []
        while True:
            try:
                l = input()
            except (EOFError, KeyboardInterrupt):
                break
            if l == ".":
                break
            new_lines.append(l)
        path.write_text("\n".join(new_lines) + ("\n" if new_lines else ""), encoding="utf-8")
        print("[OK] Сохранено!")
        pause()
    elif choice == "2":
        extra = ask("Текст для добавления: ")
        if extra:
            with open(path, "a", encoding="utf-8") as f:
                f.write(extra + "\n")
            print("[OK] Сохранено!")
        pause()


# ------------------------------------------------------------
# 14. VANYA EXPLORER — файловый менеджер
# ------------------------------------------------------------
def vanya_explorer():
    current = Path.home()
    back_stack = []
    forward_stack = []

    def list_dir(path):
        try:
            return sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            return None

    while True:
        header(f"VANYA EXPLORER — {current}")
        entries = list_dir(current)
        if entries is None:
            print("  [!] Нет доступа к этой папке.")
            entries = []
        for i, e in enumerate(entries, start=1):
            try:
                st = e.stat()
                size = "-" if e.is_dir() else _human_size(st.st_size)
                kind = "Папка" if e.is_dir() else (e.suffix.lstrip(".").upper() or "Файл")
            except OSError:
                size, kind = "?", "?"
            print(f"  {i:>3} - {e.name:<38} {kind:<8} {size}")
        if not entries:
            print("  (пусто)")
        print()
        line("-")
        print("  B-Назад F-Вперёд U-Вверх R-Обновить  N-Новая папка  T-Новый файл")
        print("  O<№>-Открыть  E<№>-Редактировать  M<№>-Переименовать  D<№>-Удалить")
        print("  0 - Выход в главное меню")
        print()
        choice = ask("EXPLORER> ").strip()
        low = choice.lower()

        if choice == "0":
            return
        elif low == "r":
            continue
        elif low == "u":
            if current.parent != current:
                back_stack.append(current)
                forward_stack.clear()
                current = current.parent
        elif low == "b":
            if back_stack:
                forward_stack.append(current)
                current = back_stack.pop()
            else:
                print("[!] История назад пуста.")
                pause()
        elif low == "f":
            if forward_stack:
                back_stack.append(current)
                current = forward_stack.pop()
            else:
                print("[!] История вперёд пуста.")
                pause()
        elif low == "n":
            name = ask("Имя новой папки: ")
            if name:
                try:
                    (current / name).mkdir(exist_ok=False)
                    print("[OK] Папка создана!")
                except OSError as ex:
                    print(f"[!] Ошибка: {ex}")
                pause()
        elif low == "t":
            name = ask("Имя файла (например notes.txt): ")
            if name:
                target = current / name
                if target.exists():
                    print("[!] Уже существует!")
                else:
                    try:
                        target.write_text("", encoding="utf-8")
                        print("[OK] Файл создан!")
                    except OSError as ex:
                        print(f"[!] Ошибка: {ex}")
                pause()
        elif low[:1] in ("o", "e", "m", "d") and low[1:].strip().isdigit():
            idx = int(low[1:].strip())
            if 1 <= idx <= len(entries):
                target = entries[idx - 1]
                action = low[0]
                if action == "o":
                    if target.is_dir():
                        back_stack.append(current)
                        forward_stack.clear()
                        current = target
                    else:
                        subprocess.run(["open", str(target)])
                        print("[OK] Открыто во внешнем приложении!")
                        pause()
                elif action == "e":
                    if target.is_dir():
                        print("[!] Это папка, а не текстовый файл.")
                        pause()
                    else:
                        _edit_text_file(target)
                elif action == "m":
                    new_name = ask(f"Новое имя для '{target.name}': ")
                    if new_name:
                        try:
                            target.rename(target.with_name(new_name))
                            print("[OK] Переименовано!")
                        except OSError as ex:
                            print(f"[!] Ошибка: {ex}")
                        pause()
                elif action == "d":
                    confirm = ask(f"Удалить '{target.name}'? (да/нет): ")
                    if confirm.lower() == "да":
                        try:
                            if target.is_dir():
                                shutil.rmtree(target)
                            else:
                                target.unlink()
                            print("[OK] Удалено!")
                        except OSError as ex:
                            print(f"[!] Ошибка: {ex}")
                    else:
                        print("[ОТМЕНА]")
                    pause()
            else:
                print("[!] Неверный номер.")
                pause()
        else:
            print("[!] Неизвестная команда.")
            pause()


# ------------------------------------------------------------
# 22. VANYA STORE — магазин приложений через Homebrew
# ------------------------------------------------------------
def vanya_store():
    brew = shutil.which("brew")
    while True:
        header("VANYA STORE")
        if not brew:
            print("  [!] Homebrew не найден на этом компьютере.")
            print("  Установи его с https://brew.sh, затем зайди сюда снова.")
            print()
            print("  0 - Назад")
            ask("Выбор: ")
            return
        print(f"  Homebrew найден: {brew}")
        print()
        print("  1 - Поиск пакетов")
        print("  2 - Установленные пакеты")
        print("  3 - Установить пакет")
        print("  4 - Удалить пакет")
        print("  5 - Популярные пакеты (подборка)")
        print("  0 - Назад")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            query = ask("Что ищем?: ")
            if query:
                header(f"РЕЗУЛЬТАТЫ ПОИСКА: {query}")
                print("Идёт поиск...")
                print(run_cmd([brew, "search", query], timeout=30) or "[!] Ничего не найдено.")
                pause()
        elif choice == "2":
            header("УСТАНОВЛЕННЫЕ ПАКЕТЫ")
            print(run_cmd([brew, "list"], timeout=30) or "[!] Пакетов нет.")
            pause()
        elif choice == "3":
            name = ask("Имя пакета для установки: ")
            if name:
                header(f"УСТАНОВКА: {name}")
                print("Идёт установка, это может занять время...")
                print()
                _run_brew_streaming([brew, "install", name])
                pause()
        elif choice == "4":
            name = ask("Имя пакета для удаления: ")
            if name:
                confirm = ask(f"Точно удалить '{name}'? (да/нет): ")
                if confirm.lower() == "да":
                    header(f"УДАЛЕНИЕ: {name}")
                    _run_brew_streaming([brew, "uninstall", name])
                else:
                    print("[ОТМЕНА]")
                pause()
        elif choice == "5":
            header("ПОПУЛЯРНЫЕ ПАКЕТЫ")
            for p in ["wget", "git", "htop", "tree", "ffmpeg", "node", "vlc"]:
                print(f"  - {p}")
            print()
            print("  Зайди в 'Установить пакет' и введи одно из этих имён.")
            pause()


def _run_brew_streaming(args):
    """Запускает команду brew и печатает вывод по мере выполнения."""
    try:
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for out_line in proc.stdout:
            print("  " + out_line.rstrip())
        proc.wait()
        print()
        if proc.returncode == 0:
            print("[OK] Готово!")
        else:
            print(f"[!] Завершилось с кодом {proc.returncode}.")
    except Exception as ex:
        print(f"[!] Ошибка: {ex}")


# ------------------------------------------------------------
# 23. VANYA TERMINAL — встроенный терминал
# ------------------------------------------------------------
def vanya_terminal():
    history = []
    cwd = Path.home()
    header("VANYA TERMINAL")
    print("  Команды выполняются как в обычном терминале macOS.")
    print("  'history' - история, 'clear' - очистить экран, 'exit' - выход.")
    print()
    while True:
        cmd = ask(f"{cwd} $ ")
        stripped = cmd.strip()
        if not stripped:
            continue
        low = stripped.lower()
        if low == "exit":
            return
        if low == "clear":
            cls()
            continue
        if low == "history":
            if history:
                for i, h in enumerate(history, start=1):
                    print(f"  {i}. {h}")
            else:
                print("  [!] История пуста.")
            continue
        history.append(stripped)
        if len(history) > 200:
            history.pop(0)
        if stripped == "cd" or stripped.startswith("cd "):
            arg = stripped[2:].strip() or str(Path.home())
            target = Path(arg).expanduser()
            if not target.is_absolute():
                target = current_join(cwd, target)
            try:
                target = target.resolve()
                if target.is_dir():
                    cwd = target
                else:
                    print(f"[!] Не найдена папка: {target}")
            except OSError as ex:
                print(f"[!] Ошибка: {ex}")
            continue
        try:
            proc = subprocess.run(stripped, shell=True, cwd=str(cwd),
                                   capture_output=True, text=True, timeout=60)
            if proc.stdout:
                print(proc.stdout.rstrip())
            if proc.stderr:
                print(c(proc.stderr.rstrip(), "91"))
        except subprocess.TimeoutExpired:
            print("[!] Команда выполняется слишком долго (таймаут 60с).")
        except Exception as ex:
            print(f"[!] Ошибка: {ex}")


def current_join(base: Path, rel: Path) -> Path:
    return base / rel


# ------------------------------------------------------------
# 24. VANYA NOTES — заметки (хранятся в notes/ рядом со скриптом)
# ------------------------------------------------------------
def vanya_notes():
    while True:
        header("VANYA NOTES")
        notes = sorted(NOTES_DIR.glob("*.txt"))
        if notes:
            for i, n in enumerate(notes, start=1):
                print(f"  {i} - {n.stem}")
        else:
            print("  (заметок пока нет)")
        print()
        print("  N - Новая заметка   O<№> - Открыть/редактировать   D<№> - Удалить")
        print("  0 - Выход")
        print()
        choice = ask("NOTES> ").strip()
        low = choice.lower()
        if choice == "0":
            return
        elif low == "n":
            name = ask("Имя новой заметки (без .txt): ")
            if name:
                target = NOTES_DIR / f"{name}.txt"
                if target.exists():
                    print("[!] Заметка с таким именем уже есть.")
                    pause()
                else:
                    target.write_text("", encoding="utf-8")
                    _edit_text_file(target)
        elif low[:1] in ("o", "d") and low[1:].strip().isdigit():
            idx = int(low[1:].strip())
            if 1 <= idx <= len(notes):
                target = notes[idx - 1]
                if low[0] == "o":
                    _edit_text_file(target)
                else:
                    confirm = ask(f"Удалить заметку '{target.stem}'? (да/нет): ")
                    if confirm.lower() == "да":
                        target.unlink()
                        print("[OK] Удалено!")
                    else:
                        print("[ОТМЕНА]")
                    pause()
            else:
                print("[!] Неверный номер.")
                pause()
        else:
            print("[!] Неизвестная команда.")
            pause()


# ------------------------------------------------------------
# 25. СИСТЕМНАЯ ИНФОРМАЦИЯ (расширенная)
# ------------------------------------------------------------
def system_info_full():
    header("СИСТЕМНАЯ ИНФОРМАЦИЯ")
    mac_ver = platform.mac_ver()[0] or "?"
    model = run_cmd(["sysctl", "-n", "hw.model"]) or "?"
    cpu = run_cmd(["sysctl", "-n", "machdep.cpu.brand_string"]) or platform.processor() or "?"
    mem_bytes = run_cmd(["sysctl", "-n", "hw.memsize"])
    try:
        mem_gb = round(int(mem_bytes) / (1024 ** 3), 2)
    except ValueError:
        mem_gb = "?"
    try:
        _, _, free = shutil.disk_usage(str(Path.home()))
        free_str = _human_size(free)
    except OSError:
        free_str = "?"
    print(f"  Версия macOS:        {mac_ver}")
    print(f"  Версия Python:       {platform.python_version()}")
    print(f"  Модель компьютера:   {model}")
    print(f"  Процессор:           {cpu}")
    print(f"  Оперативная память:  {mem_gb} ГБ")
    print(f"  Свободно на диске:   {free_str}")
    print(f"  Имя пользователя:    {getpass.getuser()}")
    print()
    line()
    pause()


# ------------------------------------------------------------
# 26. НАСТРОЙКИ VANYA OS
# ------------------------------------------------------------
def _load_settings():
    settings = {"theme": STATE["fg"], "ui_size": "normal"}
    if SETTINGS_FILE.exists():
        for l in SETTINGS_FILE.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "=" in l:
                k, v = l.split("=", 1)
                settings[k.strip()] = v.strip()
    return settings


def _save_settings(settings):
    SETTINGS_FILE.write_text("\n".join(f"{k}={v}" for k, v in settings.items()) + "\n", encoding="utf-8")


def vanya_settings():
    settings = _load_settings()
    while True:
        header("НАСТРОЙКИ VANYA OS")
        print(f"  1 - Тема оформления (сейчас цвет: {settings.get('theme', STATE['fg'])})")
        print(f"  2 - Размер интерфейса (сейчас: {settings.get('ui_size', 'normal')})")
        print("  3 - Настройки приложений (пути к данным)")
        print("  4 - Информация о Vanya OS")
        print("  0 - Назад")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        elif choice == "1":
            screen_settings()
            settings["theme"] = STATE["fg"]
            _save_settings(settings)
        elif choice == "2":
            print("  1 - Компактный   2 - Обычный   3 - Крупный")
            size_choice = ask("Выбор: ")
            size_map = {"1": "compact", "2": "normal", "3": "large"}
            if size_choice in size_map:
                settings["ui_size"] = size_map[size_choice]
                _save_settings(settings)
                print("[OK] Сохранено!")
            pause()
        elif choice == "3":
            header("НАСТРОЙКИ ПРИЛОЖЕНИЙ")
            print(f"  Папка модов:         {MODS_DIR}")
            print(f"  Папка заметок:       {NOTES_DIR}")
            print(f"  Секретное хранилище: {STORAGE_DIR}")
            print(f"  Файл дневника:       {DIARY_FILE}")
            print(f"  Список дел:          {TODO_FILE}")
            pause()
        elif choice == "4":
            about_program()


# ------------------------------------------------------------
# 27. О ПРОГРАММЕ
# ------------------------------------------------------------
def about_program():
    header("О ПРОГРАММЕ")
    print("  Vanya OS")
    print(f"  Версия: {VERSION}")
    print()
    print("  Vanya OS — персональная операционная система-проект.")
    print()
    line()
    pause()



# ============================================================
# НОВОЕ В v18.0 — НОВЫЕ ПРИЛОЖЕНИЯ (РАБОЧИЙ СТОЛ НЕ МЕНЯЕМ)
# ============================================================
def mini_snake():
    """Безопасная консольная мини-игра: угадай направление змейки."""
    directions = ["W (вверх)", "A (влево)", "S (вниз)", "D (вправо)"]
    score = 0
    while True:
        header("VANYA SNAKE — МИНИ-ИГРА")
        print("  Управление: W/A/S/D. Здесь змейка представлена как мини-челлендж.")
        print(f"  Счёт: {score}")
        print()
        print("  Куда ползём?")
        for i, d in enumerate(directions, 1):
            print(f"  {i} - {d}")
        print("  0 - Выход")
        print()
        choice = ask("SNAKE> ").lower()
        if choice == "0":
            return
        if choice in {"1", "2", "3", "4", "w", "a", "s", "d"}:
            score += 1
            print(random.choice(["🍎 Яблоко найдено! +1", "🐍 ШШШ... +1", "⭐ Бонус! +1"]))
            pause()
        else:
            print("[!] W/A/S/D или 1-4!")
            pause()


def reaction_game():
    header("VANYA REACTION TEST")
    print("  Сейчас появится слово СТАРТ. После него нажми Enter.")
    print("  Не спеши — сначала идёт случайная пауза!")
    print()
    input(c("  Нажми Enter, чтобы начать..."))
    delay = random.uniform(1.0, 3.0)
    time.sleep(delay)
    print("\n  >>> СТАРТ! <<<")
    start = time.time()
    input(c("  ENTER! "))
    elapsed = time.time() - start
    header("РЕЗУЛЬТАТ")
    print(f"  Твоя реакция: {elapsed:.3f} сек")
    if elapsed < 0.25:
        print("  ⚡ МОЛНИЯ!")
    elif elapsed < 0.5:
        print("  🚀 Очень быстро!")
    elif elapsed < 1.0:
        print("  😎 Отличная реакция!")
    else:
        print("  🐢 Ничего, попробуй ещё раз!")
    print()
    line()
    pause()


def memory_game():
    header("VANYA MEMORY")
    items = ["РОБОТ", "ЯРИК", "ШАРИК", "БЛЕНДЕР", "МОД", "VANYA"]
    sequence = random.sample(items, 4)
    print("  Запомни порядок:")
    print("  " + " → ".join(sequence))
    print()
    time.sleep(2.5)
    header("VANYA MEMORY — ПРОВЕРКА")
    answer = ask("Введи слова через пробел: ")
    if [x.upper() for x in answer.split()] == sequence:
        print("\n  🧠 ПАМЯТЬ СРАБОТАЛА! +100 XP")
    else:
        print("\n  🙂 Почти! Правильный порядок:")
        print("  " + " → ".join(sequence))
    print()
    line()
    pause()


def text_stats():
    header("VANYA TEXT STATS")
    text = ask("Введи текст: ")
    words = text.split()
    letters = sum(ch.isalpha() for ch in text)
    digits = sum(ch.isdigit() for ch in text)
    spaces = sum(ch.isspace() for ch in text)
    print()
    print(f"  Символов: {len(text)}")
    print(f"  Букв:     {letters}")
    print(f"  Цифр:     {digits}")
    print(f"  Пробелов: {spaces}")
    print(f"  Слов:     {len(words)}")
    print()
    line()
    pause()


def color_picker():
    header("VANYA COLOR PICKER")
    colors = [
        ("Красный", "C"), ("Зелёный", "A"), ("Жёлтый", "E"),
        ("Синий", "9"), ("Фиолетовый", "D"), ("Голубой", "B"),
        ("Белый", "F"), ("Серый", "7"),
    ]
    for i, (name, code) in enumerate(colors, 1):
        ansi = CMD_TO_ANSI[code]
        print(f"  {i} - \033[{ansi}m{name} [{code}]\033[0m")
    print("  0 - Назад")
    print()
    choice = ask("Выбор: ")
    if choice.isdigit() and 1 <= int(choice) <= len(colors):
        name, code = colors[int(choice) - 1]
        print(f"\n  Выбран цвет: \033[{CMD_TO_ANSI[code]}m{name}\033[0m")
    pause()


def mod_template():
    header("VANYA MOD LAB")
    print("  Создаём безопасный шаблон мода .txt в папке mods.")
    name = ask("Имя мода: ")
    if not name:
        return
    safe_name = "".join(ch for ch in name if ch.isalnum() or ch in " _-").strip()
    if not safe_name:
        print("[!] Неверное имя.")
        pause()
        return
    path = MODS_DIR / f"{safe_name}.txt"
    if path.exists():
        print("[!] Такой мод уже существует.")
        pause()
        return
    text = (
        "[MOD_NAME]\n" + safe_name + "\n\n"
        "[MOD_AUTHOR]\nВаня\n\n"
        "[MOD_DESCRIPTION]\nМод для Vanya OS 20.0\n\n"
        "[MOD_STATUS]\n1\n\n"
        "[MOD_COMPAT]\n1\n"
    )
    path.write_text(text, encoding="utf-8")
    print(f"[OK] Шаблон создан: {path.name}")
    pause()


# ============================================================
# VANYA OS 18.0 — ДОПОЛНИТЕЛЬНЫЕ ПРИЛОЖЕНИЯ
# Рабочий стол и существующие приложения не изменяем.
# ============================================================
VANYA_TRASH = APP_DIR / "vanya_trash"
VANYA_TRASH.mkdir(exist_ok=True)

def vanya_notifications():
    header("VANYA NOTIFICATIONS")
    print("  🔔 Центр уведомлений")
    print()
    print("  • Vanya OS работает нормально.")
    print("  • Моды загружаются из папки mods/.")
    print(f"  • Версия системы: {VERSION}")
    print()
    pause()

def vanya_updater():
    header("VANYA UPDATER")
    print("  Проверка обновлений Vanya OS...")
    for msg in ["Проверяем сервер...", "Проверяем файлы...", "Проверяем моды..."]:
        print("  [OK] " + msg)
        sleep(0.35)
    print()
    print(f"  ✓ Установлена последняя локальная версия v{VERSION}.")
    print("  Обновление не скачивает и не меняет системные файлы macOS.")
    print()
    pause()

def vanya_trash():
    header("VANYA TRASH")
    files = [x for x in VANYA_TRASH.iterdir() if x.is_file()]
    if not files:
        print("  🗑️ Корзина Vanya OS пуста.")
    else:
        for i, f in enumerate(files, 1):
            print(f"  {i} - {f.name}")
        print()
        print("  C - очистить корзину")
        choice = ask("TRASH> ").lower()
        if choice == "c":
            for f in files:
                try: f.unlink()
                except OSError: pass
            print("  [OK] Корзина очищена.")
        elif choice.isdigit() and 1 <= int(choice) <= len(files):
            try:
                files[int(choice)-1].unlink()
                print("  [OK] Файл удалён из корзины Vanya OS.")
            except OSError:
                print("  [!] Не удалось удалить файл.")
    pause()

def vanya_lock():
    header("VANYA LOCK")
    print("  🔒 Vanya OS заблокирована.")
    print("  Введи слово UNLOCK для возврата.")
    while True:
        if ask("LOCK> ").strip().upper() == "UNLOCK":
            return
        print("  🔒 Доступ закрыт.")

def vanya_pong():
    header("VANYA PONG")
    score = 0
    print("  Мини-версия Pong: угадай, куда полетит мяч.")
    print("  1 - Лево   2 - Центр   3 - Право   0 - Выход")
    while True:
        choice = ask("PONG> ")
        if choice == "0": return
        if choice not in {"1","2","3"}:
            print("  [!] Выбери 1, 2 или 3."); continue
        ball = random.randint(1,3)
        if int(choice) == ball:
            score += 10
            print("  🏓 ПОПАДАНИЕ! +10")
        else:
            print(f"  Мяч был в позиции {ball}.")
        print(f"  Счёт: {score}")

def vanya_tetris():
    header("VANYA TETRIS")
    print("  🧱 Консольный мини-Тетрис-челлендж")
    print("  Собери виртуальную линию из 4 блоков.")
    score = 0
    for _ in range(5):
        blocks = random.randint(1,4)
        print("  " + "[]" * blocks)
        if blocks == 4:
            score += 100
            print("  ЛИНИЯ! +100")
        else:
            score += blocks * 10
        if ask("  Enter — следующий ход, 0 — выход: ") == "0":
            break
    print(f"  Итоговый счёт: {score}")
    pause()

def chickingan_game():
    header("CHICKINGAN GAME")
    print("  🐔 Секретная игра из mods/chickingan.txt")
    score = 0
    for _ in range(5):
        if random.choice([True, False]):
            score += 20
            print("  🐔 КУ-КА-РЕ-КУ! +20")
        else:
            print("  🐔 Тихая курица...")
        sleep(0.25)
    print(f"\n  Счёт курицы: {score}")
    pause()

def vanya_memory2():
    header("VANYA MEMORY 2")
    items = ["ROBOT", "CHICKINGAN", "VANYA", "STORE", "TERMINAL", "MOD"]
    sequence = random.sample(items, 5)
    print("  Запомни:")
    print("  " + " | ".join(sequence))
    sleep(3)
    cls(); header("VANYA MEMORY 2 — ПРОВЕРКА")
    ans = ask("Введи порядок через пробел: ").upper().split()
    if ans == sequence:
        print("  🧠 ИДЕАЛЬНО! +500 XP")
    else:
        print("  🙂 Правильный порядок: " + " | ".join(sequence))
    pause()

def vanya_mod_manager():
    while True:
        mods = load_mods()
        header("VANYA MOD MANAGER")
        if not mods:
            print("  Модов пока нет.")
        for i, m in enumerate(mods, 1):
            print(f"  {i} - {m['name']} — {mod_status_text(m)}")
        print()
        print("  Введи номер мода для включения/выключения.")
        print("  0 - Назад")
        choice = ask("MODS> ")
        if choice == "0": return
        if choice.isdigit() and 1 <= int(choice) <= len(mods):
            m = mods[int(choice)-1]
            data = m["file"].read_text(encoding="utf-8", errors="ignore")
            new_status = "0" if m["status"] == "1" else "1"
            data = re.sub(r"(\[MOD_STATUS\]\s*\n)\s*[01]", rf"\g<1>{new_status}", data, count=1)
            m["file"].write_text(data, encoding="utf-8")
            print(f"  [OK] {m['name']}: {'включён' if new_status == '1' else 'выключен'}")
            pause()
        else:
            print("  [!] Неверный номер."); pause()

def vanya_paint():
    header("VANYA PAINT")
    print("  🎨 Консольный художник: составь рисунок символами.")
    print("  Введи строку из символов *, #, @ и пробелов.")
    print("  Пустая строка завершает рисунок.")
    while True:
        s = ask("PAINT> ")
        if not s: return
        print("  " + s)

def vanya_calculator():
    header("VANYA CALCULATOR")
    print("  Безопасный калькулятор: числа и + - * / ( ).")
    expr = ask("CALC> ")
    if not expr: return
    if not re.fullmatch(r"[0-9+\-*/(). %]+", expr):
        print("  [!] Разрешены только числа и арифметические знаки.")
    else:
        try:
            print("  =", eval(expr, {"__builtins__": {}}, {}))
        except Exception:
            print("  [!] Не получилось вычислить.")
    pause()

def vanya_games():
    while True:
        header("VANYA GAMES")
        print("  1 - Snake")
        print("  2 - Tetris")
        print("  3 - Pong")
        print("  4 - Chickingan Game 🐔")
        print("  5 - Memory 2")
        print("  0 - Назад")
        c0 = ask("GAMES> ")
        if c0 == "0": return
        actions = {"1": mini_snake, "2": vanya_tetris, "3": vanya_pong,
                   "4": chickingan_game, "5": vanya_memory2}
        if c0 in actions: actions[c0]()
        else: print("  [!] Неверный выбор."); pause()

def developer_room():
    header("VANYA OS DEVELOPER ROOM")
    print("  🛠️ Добро пожаловать, разработчик!")
    print()
    print(f"  Версия: {VERSION}")
    print(f"  Модов: {len(load_mods())}")
    print(f"  Папка проекта: {APP_DIR}")
    print()
    print("  Секретные команды:")
    print("    chickingan      — 🐔")
    print("    vanya easteregg — ⭐")
    print()
    pause()

# ============================================================
# НОВОЕ В v27.1: 50 ДОПОЛНИТЕЛЬНЫХ ПРОГРАММ
# ============================================================

def easter_egg():
    header("⭐ EASTER EGG")
    print("  V A N Y A   O S")
    print("       ↓")
    print("  🚀 СИСТЕМА СЕКРЕТНЫХ ПАСХАЛОК АКТИВНА!")
    print("  🐔 КУ-КА-РЕ-КУ")
    print()
    pause()

# --- Игры (1-15) ---

def guess_number():
    header("УГАДАЙ ЧИСЛО")
    target = random.randint(1, 100)
    tries = 0
    print("  Я загадал число от 1 до 100. Попробуй угадать!")
    print()
    while True:
        guess = ask("Твоё число: ")
        if not guess.isdigit():
            print("  [!] Введи число."); continue
        guess = int(guess); tries += 1
        if guess < target:
            print("  Больше! 📈")
        elif guess > target:
            print("  Меньше! 📉")
        else:
            print(f"  🎉 Угадал за {tries} попыток! Это было {target}.")
            break
    pause()


def hangman():
    words = ["python", "vanya", "robot", "blender", "клавиатура", "компьютер", "терминал"]
    word = random.choice(words)
    guessed = set()
    lives = 6
    while True:
        header("ВИСЕЛИЦА")
        shown = " ".join(ch if ch in guessed else "_" for ch in word)
        print(f"  Слово: {shown}")
        print(f"  Жизней: {'❤️' * lives}")
        print(f"  Использованные буквы: {', '.join(sorted(guessed)) or '—'}")
        print()
        if "_" not in shown:
            print("  🎉 Ты победил!"); pause(); return
        if lives <= 0:
            print(f"  💀 Ты проиграл! Слово было: {word}"); pause(); return
        letter = ask("Буква: ").lower()
        if not letter or len(letter) != 1:
            continue
        if letter in guessed:
            print("  Уже вводил эту букву."); pause(); continue
        guessed.add(letter)
        if letter not in word:
            lives -= 1


def tic_tac_toe():
    board = [" "] * 9
    def show():
        header("КРЕСТИКИ-НОЛИКИ")
        for r in range(0, 9, 3):
            print(f"   {board[r]} | {board[r+1]} | {board[r+2]}")
            if r < 6: print("  ---+---+---")
        print()
    def winner():
        lines = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
        for a,b,c_ in lines:
            if board[a] != " " and board[a] == board[b] == board[c_]:
                return board[a]
        return None
    player = "X"
    while True:
        show()
        if " " not in board:
            print("  Ничья!"); pause(); return
        move = ask(f"Ход игрока {player} (1-9): ")
        if not move.isdigit() or not (1 <= int(move) <= 9) or board[int(move)-1] != " ":
            print("  [!] Некорректный ход."); pause(); continue
        board[int(move)-1] = player
        w = winner()
        if w:
            show(); print(f"  🎉 Победил игрок {w}!"); pause(); return
        player = "O" if player == "X" else "X"


def word_scramble():
    words = ["python", "vanya", "computer", "keyboard", "internet", "программа", "клавиша"]
    word = random.choice(words)
    letters = list(word)
    random.shuffle(letters)
    scrambled = "".join(letters)
    header("АНАГРАММА")
    print(f"  Собери слово из букв: {scrambled.upper()}")
    print()
    guess = ask("Твой ответ: ").lower()
    if guess == word:
        print("  🎉 Правильно!")
    else:
        print(f"  ❌ Неверно. Правильный ответ: {word}")
    pause()


def trivia_quiz():
    questions = [
        ("Столица Франции?", "париж"),
        ("Сколько будет 7*8?", "56"),
        ("Химический символ золота?", "au"),
        ("Сколько планет в Солнечной системе?", "8"),
        ("Год начала Второй мировой войны?", "1939"),
    ]
    header("ВИКТОРИНА")
    score = 0
    for q, a in questions:
        ans = ask(f"  {q} ").strip().lower()
        if ans == a:
            print("  ✅ Верно!"); score += 1
        else:
            print(f"  ❌ Неверно, правильный ответ: {a}")
    print()
    print(f"  Итог: {score} из {len(questions)}")
    pause()


def math_duel():
    header("МАТЕМАТИЧЕСКАЯ ДУЭЛЬ")
    print("  Реши как можно больше примеров за 30 секунд!")
    pause("Нажми Enter, чтобы начать...")
    start = time.time()
    score = 0
    while time.time() - start < 30:
        a, b = random.randint(1, 20), random.randint(1, 20)
        op = random.choice(["+", "-", "*"])
        correct = {"+": a + b, "-": a - b, "*": a * b}[op]
        ans = ask(f"  {a} {op} {b} = ")
        if ans.strip() == str(correct):
            score += 1
            print("  ✅")
        else:
            print(f"  ❌ ({correct})")
        if time.time() - start >= 30:
            break
    print()
    print(f"  🏁 Время вышло! Решено правильно: {score}")
    pause()


def coin_flip():
    header("МОНЕТКА")
    print("  Подбрасываю...")
    sleep(0.4)
    result = random.choice(["ОРЁЛ", "РЕШКА"])
    print(f"  Выпало: 🪙 {result}")
    pause()


def magic_8_ball():
    answers = ["Да", "Нет", "Возможно", "Спроси позже", "Определённо да",
               "Сомнительно", "Даже не думай", "Скорее всего", "Мой ответ — нет"]
    header("МАГИЧЕСКИЙ ШАР")
    ask("Задай вопрос и нажми Enter: ")
    sleep(0.5)
    print(f"  🎱 {random.choice(answers)}")
    pause()


def slot_machine():
    symbols = ["🍒", "🍋", "🔔", "⭐", "💎", "7️⃣"]
    header("ИГРОВОЙ АВТОМАТ")
    ask("Нажми Enter, чтобы крутить барабаны...")
    reels = [random.choice(symbols) for _ in range(3)]
    print(f"  [ {reels[0]} | {reels[1]} | {reels[2]} ]")
    if reels[0] == reels[1] == reels[2]:
        print("  🎉 ДЖЕКПОТ!")
    elif len(set(reels)) == 2:
        print("  👍 Неплохо, две совпали!")
    else:
        print("  😅 Не повезло, попробуй ещё раз.")
    pause()


def story_generator():
    heroes = ["Ваня", "робот-механик", "маленький дракон", "храбрая собачка"]
    places = ["в тёмном лесу", "на далёкой планете", "в старом замке", "в цифровом мире Vanya OS"]
    events = ["нашёл волшебный ключ", "сразился с драконом", "спас деревню", "починил летающий корабль"]
    endings = ["и жил долго и счастливо.", "и стал легендой.", "и вернулся домой с победой."]
    header("ГЕНЕРАТОР ИСТОРИЙ")
    story = f"  Однажды {random.choice(heroes)} оказался {random.choice(places)}. "
    story += f"Там он {random.choice(events)}, {random.choice(endings)}"
    print(story)
    pause()


def riddle_game():
    riddles = [
        ("Что имеет ключи, но не открывает замки?", "клавиатура"),
        ("Что растёт, когда его едят?", "огонь"),
        ("Без рук, без ног, а рисовать умеет?", "мороз"),
        ("Чем больше из неё берёшь, тем больше она становится?", "яма"),
    ]
    header("ЗАГАДКИ")
    q, a = random.choice(riddles)
    print(f"  {q}")
    ans = ask("Твой ответ: ").strip().lower()
    if a in ans:
        print("  🎉 Верно!")
    else:
        print(f"  ❌ Правильный ответ: {a}")
    pause()


def would_you_rather():
    options = [
        ("иметь способность летать", "иметь способность читать мысли"),
        ("жить без интернета", "жить без музыки"),
        ("быть невидимым", "уметь телепортироваться"),
        ("всегда говорить правду", "никогда не говорить"),
    ]
    header("ЧТО БЫ ТЫ ВЫБРАЛ?")
    a, b = random.choice(options)
    print(f"  1) {a}")
    print(f"  2) {b}")
    ask("Твой выбор (1/2): ")
    print("  Интересный выбор! 😄")
    pause()


def never_have_i_ever():
    statements = [
        "Я никогда не терял телефон.",
        "Я никогда не засыпал на уроке.",
        "Я никогда не забывал день рождения друга.",
        "Я никогда не ел что-то с пола.",
        "Я никогда не боялся темноты.",
    ]
    header("Я НИКОГДА НЕ...")
    print(f"  {random.choice(statements)}")
    print("  (загни палец, если делал это!)")
    pause()


def rock_paper_lizard_spock():
    options = ["камень", "ножницы", "бумага", "ящерица", "спок"]
    beats = {
        "камень": ["ножницы", "ящерица"],
        "бумага": ["камень", "спок"],
        "ножницы": ["бумага", "ящерица"],
        "ящерица": ["спок", "бумага"],
        "спок": ["ножницы", "камень"],
    }
    header("КАМЕНЬ-НОЖНИЦЫ-БУМАГА-ЯЩЕРИЦА-СПОК")
    for i, o in enumerate(options, 1):
        print(f"  {i} - {o}")
    choice = ask("Твой выбор (1-5): ")
    if not choice.isdigit() or not (1 <= int(choice) <= 5):
        print("  [!] Некорректный выбор."); pause(); return
    you = options[int(choice) - 1]
    comp = random.choice(options)
    print(f"  Ты выбрал: {you}. Компьютер выбрал: {comp}.")
    if you == comp:
        print("  Ничья!")
    elif comp in beats[you]:
        print("  🎉 Ты выиграл!")
    else:
        print("  💻 Компьютер выиграл!")
    pause()


# --- Конвертеры и утилиты (16-30) ---

def temperature_converter():
    header("КОНВЕРТЕР ТЕМПЕРАТУРЫ")
    print("  1 - Цельсий в Фаренгейт")
    print("  2 - Фаренгейт в Цельсий")
    choice = ask("Выбор: ")
    val = _read_float("Значение: ")
    if val is None:
        return
    if choice == "1":
        print(f"  = {val * 9/5 + 32:.2f} °F")
    else:
        print(f"  = {(val - 32) * 5/9:.2f} °C")
    pause()


def currency_converter():
    header("КОНВЕРТЕР ВАЛЮТ (примерные курсы)")
    rates = {"USD": 1.0, "EUR": 0.92, "RUB": 90.0, "GBP": 0.79}
    print("  Доступные валюты:", ", ".join(rates))
    frm = ask("Из какой валюты: ").upper()
    to = ask("В какую валюту: ").upper()
    if frm not in rates or to not in rates:
        print("  [!] Неизвестная валюта."); pause(); return
    amount = _read_float("Сумма: ")
    if amount is None:
        return
    result = amount / rates[frm] * rates[to]
    print(f"  = {result:.2f} {to} (курсы примерные, для реальных операций сверяйся с банком)")
    pause()


def binary_text_converter():
    header("ТЕКСТ <-> ДВОИЧНЫЙ КОД")
    print("  1 - Текст в двоичный код")
    print("  2 - Двоичный код в текст")
    choice = ask("Выбор: ")
    if choice == "1":
        text = ask("Текст: ")
        print("  " + " ".join(format(ord(ch), "08b") for ch in text))
    elif choice == "2":
        binstr = ask("Двоичный код (через пробел): ")
        try:
            chars = [chr(int(b, 2)) for b in binstr.split()]
            print("  " + "".join(chars))
        except ValueError:
            print("  [!] Некорректный формат.")
    pause()


MORSE_TABLE = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
    'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
    'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
    'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
    'Y': '-.--', 'Z': '--..', ' ': '/',
    '0': '-----', '1': '.----', '2': '..---', '3': '...--', '4': '....-',
    '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.',
}


def morse_code():
    header("АЗБУКА МОРЗЕ")
    print("  1 - Текст в морзе")
    print("  2 - Морзе в текст")
    choice = ask("Выбор: ")
    if choice == "1":
        text = ask("Текст: ").upper()
        print("  " + " ".join(MORSE_TABLE.get(ch, "?") for ch in text))
    elif choice == "2":
        rev = {v: k for k, v in MORSE_TABLE.items()}
        code = ask("Код (буквы через пробел, слова через /): ")
        print("  " + "".join(rev.get(sym, "?") for sym in code.split()))
    pause()


def caesar_cipher():
    header("ШИФР ЦЕЗАРЯ")
    text = ask("Текст: ")
    shift = ask("Сдвиг (число): ")
    if not shift.lstrip("-").isdigit():
        print("  [!] Введи число."); pause(); return
    shift = int(shift)
    result = []
    for ch in text:
        if ch.isalpha():
            base = ord('А') if 'А' <= ch.upper() <= 'Я' else ord('A')
            upper = ch.isupper()
            code = ord(ch.upper()) - base
            new_ch = chr((code + shift) % 26 + base)
            result.append(new_ch if upper else new_ch.lower())
        else:
            result.append(ch)
    print("  Результат: " + "".join(result))
    pause()


def text_reverser():
    header("РЕВЕРС ТЕКСТА")
    text = ask("Текст: ")
    print(f"  Задом наперёд: {text[::-1]}")
    words_rev = " ".join(text.split()[::-1])
    print(f"  Слова в обратном порядке: {words_rev}")
    pause()


def sentence_analyzer():
    header("АНАЛИЗ ПРЕДЛОЖЕНИЙ")
    text = ask("Текст (можно несколько предложений): ")
    sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
    print(f"  Предложений: {len(sentences)}")
    for i, s in enumerate(sentences, 1):
        print(f"    {i}. {s} ({len(s.split())} слов)")
    pause()


def palindrome_checker():
    header("ПРОВЕРКА НА ПАЛИНДРОМ")
    text = ask("Текст: ").lower().replace(" ", "")
    if text == text[::-1]:
        print("  ✅ Это палиндром!")
    else:
        print("  ❌ Это не палиндром.")
    pause()


def anagram_checker():
    header("ПРОВЕРКА НА АНАГРАММЫ")
    a = ask("Первое слово: ").lower().replace(" ", "")
    b = ask("Второе слово: ").lower().replace(" ", "")
    if sorted(a) == sorted(b):
        print("  ✅ Это анаграммы!")
    else:
        print("  ❌ Это не анаграммы.")
    pause()


def leap_year_checker():
    header("ПРОВЕРКА ВИСОКОСНОГО ГОДА")
    year = ask("Год: ")
    if not year.isdigit():
        print("  [!] Введи число."); pause(); return
    year = int(year)
    is_leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    print(f"  {year} {'високосный ✅' if is_leap else 'не високосный ❌'}")
    pause()


def prime_checker():
    header("ПРОВЕРКА ЧИСЛА НА ПРОСТОТУ")
    n = ask("Число: ")
    if not n.isdigit():
        print("  [!] Введи число."); pause(); return
    n = int(n)
    is_prime = n > 1 and all(n % i for i in range(2, int(math.sqrt(n)) + 1))
    print(f"  {n} {'простое ✅' if is_prime else 'не простое ❌'}")
    pause()


def fibonacci_generator():
    header("ЧИСЛА ФИБОНАЧЧИ")
    n = ask("Сколько чисел показать: ")
    if not n.isdigit():
        print("  [!] Введи число."); pause(); return
    n = int(n)
    seq = [0, 1]
    while len(seq) < n:
        seq.append(seq[-1] + seq[-2])
    print("  " + ", ".join(str(x) for x in seq[:n]))
    pause()


def gcd_lcm_calculator():
    header("НОД И НОК")
    a = ask("Первое число: ")
    b = ask("Второе число: ")
    if not (a.isdigit() and b.isdigit()):
        print("  [!] Введи числа."); pause(); return
    a, b = int(a), int(b)
    g = math.gcd(a, b)
    lcm = a * b // g if g else 0
    print(f"  НОД: {g}")
    print(f"  НОК: {lcm}")
    pause()


def roman_numeral_converter():
    header("АРАБСКИЕ <-> РИМСКИЕ ЦИФРЫ")
    vals = [(1000,"M"),(900,"CM"),(500,"D"),(400,"CD"),(100,"C"),(90,"XC"),
            (50,"L"),(40,"XL"),(10,"X"),(9,"IX"),(5,"V"),(4,"IV"),(1,"I")]
    n = ask("Введи число от 1 до 3999: ")
    if not n.isdigit() or not (1 <= int(n) <= 3999):
        print("  [!] Введи число от 1 до 3999."); pause(); return
    n = int(n)
    result = ""
    for v, sym in vals:
        while n >= v:
            result += sym; n -= v
    print(f"  Римскими: {result}")
    pause()


def percentage_calculator():
    header("КАЛЬКУЛЯТОР ПРОЦЕНТОВ")
    print("  1 - Сколько составляет X% от Y")
    print("  2 - Какой процент X составляет от Y")
    choice = ask("Выбор: ")
    x = _read_float("X: ")
    y = _read_float("Y: ")
    if x is None or y is None:
        return
    if choice == "1":
        print(f"  = {x/100*y:.2f}")
    else:
        print(f"  = {(x/y*100 if y else 0):.2f}%")
    pause()


# --- Системные инструменты (31-40) ---

def battery_status():
    header("СОСТОЯНИЕ БАТАРЕИ")
    out = run_cmd(["pmset", "-g", "batt"], timeout=5)
    print(out or "  [!] Не удалось получить данные (возможно, это не MacBook).")
    pause()


def disk_usage_chart():
    header("ИСПОЛЬЗОВАНИЕ ДИСКА")
    try:
        total, used, free = shutil.disk_usage(str(Path.home()))
        pct = used / total * 100
        bar_len = 40
        filled = int(bar_len * pct / 100)
        bar = "█" * filled + "░" * (bar_len - filled)
        print(f"  [{bar}] {pct:.1f}%")
        print(f"  Занято: {used / (1024**3):.1f} ГБ из {total / (1024**3):.1f} ГБ")
        print(f"  Свободно: {free / (1024**3):.1f} ГБ")
    except OSError as e:
        print(f"  [!] Ошибка: {e}")
    pause()


def wifi_info():
    header("WI-FI ИНФОРМАЦИЯ")
    out = run_cmd(["ipconfig", "getsummary", "en0"], timeout=5)
    print(out[:1500] if out else "  [!] Не удалось получить данные о Wi-Fi.")
    pause()


def uptime_display():
    header("ВРЕМЯ РАБОТЫ СИСТЕМЫ")
    out = run_cmd(["uptime"], timeout=5)
    print("  " + (out or "недоступно"))
    pause()


def process_finder():
    header("ПОИСК ПРОЦЕССА")
    name = ask("Название процесса: ")
    if not name:
        return
    out = run_cmd(["pgrep", "-fli", name], timeout=5)
    print(out or "  [!] Процессы не найдены.")
    pause()


def env_variables_viewer():
    header("ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ")
    items = sorted(os.environ.items())[:40]
    for k, v in items:
        display = v if len(v) < 60 else v[:57] + "..."
        print(f"  {k} = {display}")
    if len(os.environ) > 40:
        print(f"  ... и ещё {len(os.environ) - 40} переменных")
    pause()


def clipboard_tool():
    header("БУФЕР ОБМЕНА")
    print("  1 - Скопировать текст в буфер")
    print("  2 - Показать содержимое буфера")
    choice = ask("Выбор: ")
    if choice == "1":
        text = ask("Текст: ")
        try:
            subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=True)
            print("  [OK] Скопировано в буфер обмена!")
        except Exception as e:
            print(f"  [!] Ошибка: {e}")
    elif choice == "2":
        try:
            out = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
            print(f"  Содержимое буфера: {out.stdout}")
        except Exception as e:
            print(f"  [!] Ошибка: {e}")
    pause()


def screenshot_tool():
    header("СКРИНШОТ")
    target = APP_DIR / f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
    try:
        subprocess.run(["screencapture", "-i", str(target)], timeout=30)
        if target.exists():
            print(f"  [OK] Скриншот сохранён: {target}")
        else:
            print("  [ОТМЕНА] Скриншот не был сделан.")
    except Exception as e:
        print(f"  [!] Ошибка: {e}")
    pause()


def file_hash_calculator():
    header("ХЭШ ФАЙЛА")
    path = ask("Путь к файлу: ")
    p = Path(path).expanduser() if path else None
    if not p or not p.exists() or not p.is_file():
        print("  [!] Файл не найден."); pause(); return
    try:
        data = p.read_bytes()
        print(f"  MD5:    {hashlib.md5(data).hexdigest()}")
        print(f"  SHA256: {hashlib.sha256(data).hexdigest()}")
    except OSError as e:
        print(f"  [!] Ошибка: {e}")
    pause()


def json_formatter():
    header("ФОРМАТИРОВАНИЕ JSON")
    print('  Введи JSON в одну строку. Строка "." завершает ввод.')
    lines = []
    while True:
        l = ask("")
        if l == ".":
            break
        lines.append(l)
    raw = "\n".join(lines)
    try:
        parsed = _json.loads(raw)
        print(_json.dumps(parsed, indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"  [!] Некорректный JSON: {e}")
    pause()


# --- Разное и веселье (41-50) ---

def motivational_quote():
    quotes = [
        "Маленькие шаги каждый день приводят к большим результатам.",
        "Лучшее время начать было вчера. Следующее лучшее — сейчас.",
        "Ошибки — это доказательство того, что ты пробуешь.",
        "Программист — это волшебник, который пишет заклинания на Python.",
        "Не бойся медленного прогресса, бойся остановки.",
    ]
    header("ЦИТАТА ДНЯ")
    print(f"  💬 {random.choice(quotes)}")
    pause()


def zodiac_sign():
    header("ЗНАК ЗОДИАКА")
    day = ask("День рождения (1-31): ")
    month = ask("Месяц рождения (1-12): ")
    if not (day.isdigit() and month.isdigit()):
        print("  [!] Введи числа."); pause(); return
    day, month = int(day), int(month)
    signs = [(20,"Козерог"),(19,"Водолей"),(21,"Рыбы"),(20,"Овен"),(21,"Телец"),
             (21,"Близнецы"),(23,"Рак"),(23,"Лев"),(23,"Дева"),(23,"Весы"),
             (22,"Скорпион"),(22,"Стрелец"),(32,"Козерог")]
    cutoff, sign = signs[month - 1]
    result = sign if day < cutoff else signs[month % 12][1]
    print(f"  ✨ Твой знак зодиака: {result}")
    pause()


def fantasy_name_gen():
    first = ["Эль", "Тор", "Кир", "Зара", "Мир", "Люм", "Вел", "Аль"]
    second = ["дор", "рин", "ваниэль", "гард", "тис", "лия", "нар", "вин"]
    header("ГЕНЕРАТОР ФЭНТЕЗИ-ИМЁН")
    name = random.choice(first) + random.choice(second)
    print(f"  🧙 Твоё фэнтези-имя: {name}")
    pause()


def compliment_generator():
    compliments = [
        "Ты справляешься лучше, чем думаешь!",
        "У тебя классные идеи для проектов.",
        "Твоя настойчивость в Vanya OS впечатляет!",
        "Ты быстро учишься новому.",
        "С тобой интересно работать над проектами.",
    ]
    header("ГЕНЕРАТОР КОМПЛИМЕНТОВ")
    print(f"  😊 {random.choice(compliments)}")
    pause()


def pun_generator():
    puns = [
        "Почему программисты путают Хэллоуин и Рождество? Потому что OCT 31 == DEC 25.",
        "Что сказал 0 восьмёрке? Классный пояс!",
        "Почему компьютер простыл? Забыл закрыть Windows.",
        "Я бы рассказал шутку про UDP, но не уверен, что она дойдёт.",
    ]
    header("КАЛАМБУРЫ И ШУТКИ")
    print(f"  😂 {random.choice(puns)}")
    pause()


def lucky_number():
    header("СЧАСТЛИВОЕ ЧИСЛО")
    print(f"  🍀 Твоё счастливое число сегодня: {random.randint(1, 99)}")
    pause()


def countdown_timer():
    header("ОБРАТНЫЙ ОТСЧЁТ")
    secs = ask("Сколько секунд? ")
    if not secs.isdigit():
        print("  [!] Введи число."); pause(); return
    secs = int(secs)
    for i in range(secs, 0, -1):
        print(f"  {i}...", end="\r")
        sleep(1)
    print("  🎉 Время вышло!            ")
    pause()


def pomodoro_timer():
    header("ТАЙМЕР ПОМОДОРО")
    print("  Классический цикл: 25 минут работы, 5 минут отдыха.")
    minutes = ask("Сколько минут работать (Enter = 25): ")
    minutes = int(minutes) if minutes.isdigit() else 25
    print(f"  ⏳ Симуляция таймера на {minutes} мин (ускоренно, 1 сек = 1 мин)...")
    for i in range(minutes, 0, -1):
        print(f"  Осталось: {i} мин", end="\r")
        sleep(0.2)
    print("  🍅 Помодоро завершён! Пора отдохнуть.       ")
    pause()


def accent_color_changer():
    header("СМЕНА АКЦЕНТНОГО ЦВЕТА (терминал)")
    screen_settings()


def vanya_horoscope():
    predictions = [
        "Сегодня отличный день, чтобы доделать функцию в Vanya OS!",
        "Возможно, тебя ждёт неожиданная находка в коде.",
        "День благоприятен для новых идей и экспериментов.",
        "Будь осторожен с опечатками в коде сегодня 😄",
        "Сегодня удачный день для дебага и рефакторинга.",
    ]
    header("ГОРОСКОП VANYA OS")
    print(f"  🔮 {random.choice(predictions)}")
    pause()


EXTRA_FUNCTIONS = [
    ("Угадай число", guess_number), ("Виселица", hangman), ("Крестики-нолики", tic_tac_toe),
    ("Анаграмма", word_scramble), ("Викторина", trivia_quiz), ("Математическая дуэль", math_duel),
    ("Монетка", coin_flip), ("Магический шар", magic_8_ball), ("Игровой автомат", slot_machine),
    ("Генератор историй", story_generator), ("Загадки", riddle_game), ("Что бы ты выбрал?", would_you_rather),
    ("Я никогда не...", never_have_i_ever), ("КНБ-ящерица-спок", rock_paper_lizard_spock),
    ("Температура", temperature_converter), ("Валюты", currency_converter),
    ("Текст <-> двоичный код", binary_text_converter), ("Азбука Морзе", morse_code),
    ("Шифр Цезаря", caesar_cipher), ("Реверс текста", text_reverser),
    ("Анализ предложений", sentence_analyzer), ("Палиндром", palindrome_checker),
    ("Анаграммы (проверка)", anagram_checker), ("Високосный год", leap_year_checker),
    ("Простое число", prime_checker), ("Числа Фибоначчи", fibonacci_generator),
    ("НОД и НОК", gcd_lcm_calculator), ("Римские цифры", roman_numeral_converter),
    ("Проценты", percentage_calculator), ("Батарея", battery_status),
    ("Диск (график)", disk_usage_chart), ("Wi-Fi инфо", wifi_info), ("Uptime", uptime_display),
    ("Поиск процесса", process_finder), ("Переменные окружения", env_variables_viewer),
    ("Буфер обмена", clipboard_tool), ("Скриншот", screenshot_tool),
    ("Хэш файла", file_hash_calculator), ("JSON форматтер", json_formatter),
    ("Цитата дня", motivational_quote), ("Знак зодиака", zodiac_sign),
    ("Фэнтези-имя", fantasy_name_gen), ("Комплимент", compliment_generator),
    ("Каламбуры", pun_generator), ("Счастливое число", lucky_number),
    ("Обратный отсчёт", countdown_timer), ("Таймер Помодоро", pomodoro_timer),
    ("Сменить акцент", accent_color_changer), ("Гороскоп Vanya OS", vanya_horoscope),
]


def extra_functions_hub():
    while True:
        header(f"60. ЕЩЁ {len(EXTRA_FUNCTIONS)} ФУНКЦИЙ (v27.1)")
        for i, (name, _fn) in enumerate(EXTRA_FUNCTIONS, 1):
            print(f"  {i:>2} - {name}")
        print()
        print("  0 - Назад")
        print()
        choice = ask("Выбор: ")
        if choice == "0":
            return
        if choice.isdigit() and 1 <= int(choice) <= len(EXTRA_FUNCTIONS):
            EXTRA_FUNCTIONS[int(choice) - 1][1]()
        else:
            print("  [!] Неверный выбор."); pause()


# ============================================================
# ГЛАВНОЕ МЕНЮ
# ============================================================
MENU_ACTIONS = {
    "1": sys_monitor,
    "2": task_manager,
    "3": network_info,
    "4": about_os,
    "5": calendar_view,
    "6": calculator,
    "7": lock_screen,
    "8": power_menu,
    "9": web_search,
    "10": yarik_age,
    "11": nickname_gen,
    "12": typing_test,
    "13": big_clock,
    "15": unit_converter,
    "16": qr_generator,
    "17": bmi_calculator,
    "18": random_number,
    "19": base_converter,
    "20": mods_manager,
    "21": create_mod,
    "14": vanya_explorer,
    "22": vanya_store,
    "23": vanya_terminal,
    "24": vanya_notes,
    "25": system_info_full,
    "26": vanya_settings,
    "27": about_program,
    "28": mini_snake,
    "29": reaction_game,
    "30": memory_game,
    "31": text_stats,
    "32": color_picker,
    "33": mod_template,
    "34": vanya_notifications,
    "35": vanya_updater,
    "36": vanya_trash,
    "37": vanya_lock,
    "38": vanya_paint,
    "39": vanya_calculator,
    "41": vanya_games,
    "42": vanya_mod_manager,
    "43": developer_room,
    "44": easter_egg,
    "60": extra_functions_hub,
    "a": open_youtube,
    "b": show_error,
    "c": run_program,
    "d": open_folder,
    "e": secret_diary,
    "f": secret_storage,
    "g": matrix_effect,
    "h": hack_game,
    "i": rock_game,
    "j": cool_fact,
    "k": age_converter,
    "l": random_color,
    "m": screen_settings,
    "n": hello_yarik,
    "o": generate_password,
    "p": clear_cache,
    "q": todo_list,
    "r": dice_roll,
    "s": stopwatch,
    "t": quick_note,
    "u": ascii_art,
    "v": wikipedia,
    "w": weather,
    "x": study_timer,
    "y": random_joke,
    "z": cmd_help,
}


def boot_screen():
    cls()
    print()
    line()
    print(c(f"     VANYA OS v{VERSION} - ЗАГРУЗКА СИСТЕМЫ..."))
    line()
    print()
    print("  [OK] Ядро загружено")
    print("  [OK] Файловая система проверена")
    print("  [OK] Модуль VANYA активирован")
    print()
    sleep(0.8)


def show_menu(custom_title, mods_count, active_count, mods_list):
    cls()
    line()
    print(c(f"                  {custom_title}"))
    print(c("             ОПЕРАЦИОННАЯ СИСТЕМА ХАКЕРА (Python/macOS)"))
    line()
    print()
    print("  Статус системы:")
    if mods_count > 0:
        print(f"  Всего модов: {mods_count}")
        print(f"  Активных модов: {active_count}")
        print(f"  Моды: {', '.join(mods_list)}")
    else:
        print("  Моды: не установлены")
        print(f"  Совет: положи .txt мод в {MODS_DIR}")
    print()
    line("-")
    print()
    print("  -- СИСТЕМА -----------------------------------------------")
    print("  1  - Системный монитор       5  - Дата и время")
    print("  2  - Диспетчер задач         6  - Калькулятор")
    print("  3  - Сетевые настройки       7  - Блокировка экрана")
    print("  4  - Информация о системе    8  - Выключить/Перезагрузить")
    print("  13 - Большие часы")
    print()
    print("  -- ИНТЕРНЕТ ----------------------------------------------")
    print("  9  - Поиск в Yandex          V  - Википедия")
    print("  A  - YouTube                 W  - Погода")
    print()
    print("  -- ПРИЛОЖЕНИЯ --------------------------------------------")
    print("  B  - Симулятор ошибки        T  - Быстрая заметка")
    print("  C  - Запустить программу     Q  - Список дел")
    print("  D  - Открыть папку           E  - Секретный дневник")
    print("  F  - Секретное хранилище")
    print()
    print("  -- РАЗВЛЕЧЕНИЯ -------------------------------------------")
    print("  G  - Матрица                 R  - Кубик")
    print("  H  - Взлом кода (игра)       S  - Секундомер")
    print("  I  - Камень-ножницы-бумага   U  - ASCII-арт")
    print("  J  - Крутой факт             Y  - Случайная шутка")
    print("  K  - Сколько я прожил?       10 - Возраст Ярика в собачьих")
    print("  11 - Генератор ников         12 - Тест скорости печати")
    print()
    print("  -- УТИЛИТЫ -----------------------------------------------")
    print("  15 - Конвертер единиц        18 - Генератор случ. чисел")
    print("  16 - Генератор QR-кодов      19 - Системы счисления")
    print("  17 - Калькулятор ИМТ")
    print()
    print("  -- УЧЁБА -------------------------------------------------")
    print("  X  - Таймер для уроков       Z  - Справочник терминала")
    print()
    print("  -- НАСТРОЙКИ ---------------------------------------------")
    print("  L  - Случайный цвет          O  - Генератор паролей")
    print("  M  - Тема оформления         P  - Очистка кэша")
    print("  N  - Привет Ярику")
    print()
    print("  -- МОДЫ --------------------------------------------------")
    print("  20 - Управление модами       21 - Создать новый мод")
    print()
    print("  -- НОВОЕ В v17.0 -------------------------------------------")
    print("  14 - Vanya Explorer          22 - Vanya Store")
    print("  23 - Vanya Terminal          24 - Vanya Notes")
    print("  25 - Системная информация    26 - Настройки Vanya OS")
    print("  27 - О программе")
    print()
    print("  -- НОВОЕ В v18.0 -------------------------------------------")
    print("  28 - Vanya Snake              31 - Статистика текста")
    print("  29 - Тест реакции             32 - Выбор цвета")
    print("  30 - Vanya Memory             33 - Vanya Mod Lab")
    print("  Рабочий стол v17.0 НЕ ИЗМЕНЁН")
    print()
    print("  -- НОВОЕ В v18.0 -------------------------------------------")
    print("  34 - Уведомления              35 - Vanya Updater")
    print("  36 - Корзина Vanya OS        37 - Блокировка")
    print("  38 - Vanya Paint             39 - Vanya Calculator")
    print("  41 - Vanya Games")
    print("  42 - Vanya Mod Manager       43 - Developer Room")
    print("  44 - Easter Egg")
    print("  60 - Ещё 50 функций (v27.1)")
    print()
    line("-")
    print("  0  - ВЫХОД")
    print(f"  Время: {datetime.now().strftime('%H:%M:%S')}")
    line()


def main():
    boot_screen()
    try:
        while True:
            mods = load_mods()
            custom_title, custom_fg, active_count, mods_list = apply_mods(mods)
            STATE["fg"] = custom_fg
            show_menu(custom_title, len(mods), active_count, mods_list)
            choice = ask("VANYA OS> ").strip().lower()
            if choice == "0":
                break
            action = MENU_ACTIONS.get(choice)
            if action:
                try:
                    action()
                except KeyboardInterrupt:
                    pass
            # неверный выбор просто возвращает в меню, как в оригинале
    except KeyboardInterrupt:
        pass

    cls()
    print()
    line()
    print()
    print("       ВЫКЛЮЧЕНИЕ VANYA OS...")
    print()
    print("       До встречи, хакер!")
    print()
    line()
    print()
    sleep(1)


if __name__ == "__main__":
    main()
