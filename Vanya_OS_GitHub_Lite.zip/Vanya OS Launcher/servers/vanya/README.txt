Положи сюда ядро сервера. Для Java по умолчанию ожидается server.jar; для Bedrock — bedrock_server.
