#!/bin/bash
cd "$(dirname "$0")"
exec java -Xmx2G -jar server.jar nogui
