#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Vanya OS 27.1 — единый графический рабочий стол с внутренними окнами."""
import os, sys, re, time, random, platform, subprocess, importlib.util, builtins, threading, queue, types, json, struct, zlib, base64, shutil, uuid, socket, math
import urllib.request, urllib.parse, urllib.error
import zipfile
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog
from tkinter import messagebox, simpledialog
from pathlib import Path
from datetime import datetime

# Pillow используется только для плавного масштабирования обоев.
# Если его нет, Vanya OS всё равно запускается и использует встроенный масштаб Tk.
try:
    from PIL import Image, ImageTk
    HAVE_PIL = True
except Exception:
    Image = ImageTk = None
    HAVE_PIL = False

APP_DIR = Path(__file__).resolve().parent
VANYA_VERSION = "27.1"
USER_DATA_DIR = APP_DIR / "users"
USER_DATA_DIR.mkdir(exist_ok=True)
USER_DB = USER_DATA_DIR / "users.json"
APPS_DIR = APP_DIR / "vanya_apps"; APPS_DIR.mkdir(exist_ok=True)
NOTES_DIR = APP_DIR / "notes"; NOTES_DIR.mkdir(exist_ok=True)
MODS_DIR = APP_DIR / "mods"; MODS_DIR.mkdir(exist_ok=True)
TRASH_DIR = APP_DIR / "vanya_trash"; TRASH_DIR.mkdir(exist_ok=True)
SERVERS_DIR = APP_DIR / "servers"; SERVERS_DIR.mkdir(exist_ok=True)

BG="#20242b"; PANEL="#303640"; BAR="#4b515a"; CARD="#383f49"; TEXT="#f4f7ff"; MUTED="#c5cbd4"
ACCENT="#55d6be"; ACCENT2="#78a9ff"; WINDOW_BG="#d3d3d3"; WINDOW_TEXT="#111111"

# Встроенный запасной шрифт 5x5 для игры "Большие буковки" - используется,
# если библиотеку pyfiglet не удалось установить (работает без интернета).
FALLBACK_FONT = {
    "A": [".###.","#...#","#####","#...#","#...#"],
    "B": ["####.","#...#","####.","#...#","####."],
    "C": [".####","#....","#....","#....",".####"],
    "D": ["####.","#...#","#...#","#...#","####."],
    "E": ["#####","#....","###..","#....","#####"],
    "F": ["#####","#....","###..","#....","#...."],
    "G": [".####","#....","#.###","#...#",".####"],
    "H": ["#...#","#...#","#####","#...#","#...#"],
    "I": ["#####","..#..","..#..","..#..","#####"],
    "J": ["..###","...#.","...#.","#..#.",".##.."],
    "K": ["#...#","#..#.","###..","#..#.","#...#"],
    "L": ["#....","#....","#....","#....","#####"],
    "M": ["#...#","##.##","#.#.#","#...#","#...#"],
    "N": ["#...#","##..#","#.#.#","#..##","#...#"],
    "O": [".###.","#...#","#...#","#...#",".###."],
    "P": ["####.","#...#","####.","#....","#...."],
    "Q": [".###.","#...#","#.#.#","#..#.",".##.#"],
    "R": ["####.","#...#","####.","#..#.","#...#"],
    "S": [".####","#....",".###.","....#","####."],
    "T": ["#####","..#..","..#..","..#..","..#.."],
    "U": ["#...#","#...#","#...#","#...#",".###."],
    "V": ["#...#","#...#","#...#",".#.#.","..#.."],
    "W": ["#...#","#...#","#.#.#","##.##","#...#"],
    "X": ["#...#",".#.#.","..#..",".#.#.","#...#"],
    "Y": ["#...#",".#.#.","..#..","..#..","..#.."],
    "Z": ["#####","...#.","..#..",".#...","#####"],
    "0": [".###.","#...#","#.#.#","#...#",".###."],
    "1": ["..#..",".##..","..#..","..#..","#####"],
    "2": ["####.","....#",".###.","#....","#####"],
    "3": ["####.","....#",".###.","....#","####."],
    "4": ["#..#.","#..#.","#####","...#.","...#."],
    "5": ["#####","#....","####.","....#","####."],
    "6": [".####","#....","####.","#...#",".####"],
    "7": ["#####","....#","...#.","..#..","..#.."],
    "8": [".###.","#...#",".###.","#...#",".###."],
    "9": [".###.","#...#",".####","....#",".###."],
    " ": [".....",".....",".....",".....","....."],
    "!": ["..#..","..#..","..#..",".....","..#.."],
    "?": [".###.","#...#","..##.",".....","..#.."],
}

# User-facing functions from the old Vanya OS 27.1 terminal.
FUNCTIONS = [
("Система", [("1 — Монитор системы","sys_monitor"),("2 — Диспетчер задач","task_manager"),("3 — Сеть","network_info"),("4 — О Vanya OS","about_os"),("5 — Календарь","calendar_view"),("6 — Калькулятор","calculator"),("7 — Блокировка","lock_screen"),("8 — Питание","power_menu")]),
("Интернет", [("9 — Web Search","web_search"),("A — YouTube","open_youtube"),("V — Wikipedia","wikipedia"),("W — Погода","weather"),("16 — QR-код","qr_generator")]),
("Инструменты", [("10 — Возраст Ярика","yarik_age"),("11 — Никнейм","nickname_gen"),("12 — Тест печати","typing_test"),("13 — Большие часы","big_clock"),("15 — Конвертер единиц","unit_converter"),("18 — Случайное число","random_number"),("19 — Системы счисления","base_converter"),("K — Конвертер возраста","age_converter"),("L — Случайный цвет","random_color"),("O — Генератор пароля","generate_password"),("P — Очистка кэша","clear_cache")]),
("Игры", [("28 — Snake","mini_snake"),("29 — Reaction","reaction_game"),("30 — Memory","memory_game"),("38 — Paint","vanya_paint"),("41 — Все игры","vanya_games"),("H — Hack Game","hack_game"),("I — Камень-ножницы-бумага","rock_game"),("R — Кубик","dice_roll"),("S — Секундомер","stopwatch"),("Y — Случайная шутка","random_joke"),("— Pong","vanya_pong"),("— Tetris","vanya_tetris"),("— Chickingan","chickingan_game"),("— Memory 2","vanya_memory2")]),
("Vanya OS", [("14 — Explorer","vanya_explorer"),("20 — Mods","mods_manager"),("21 — Создать мод","create_mod"),("22 — Vanya Store","vanya_store"),("23 — Terminal","vanya_terminal"),("24 — Notes","vanya_notes"),("25 — System Info","system_info_full"),("26 — Settings","vanya_settings"),("27 — About","about_program"),("34 — Notifications","vanya_notifications"),("35 — Updater","vanya_updater"),("36 — Trash","vanya_trash"),("37 — Lock","vanya_lock"),("42 — Mod Manager","vanya_mod_manager"),("43 — Developer Room","developer_room"),("44 — Easter Egg","easter_egg"),("45 — Vanya Search","vanya_search"),("46 — Task Manager 2.0","vanya_task_manager"),("47 — Control Center","vanya_control_center"),("48 — Workspaces","vanya_workspaces"),("49 — Theme Studio","vanya_theme_studio"),("50 — App Builder","vanya_app_builder"),("51 — Vanya Arcade","vanya_arcade"),("52 — Developer Mode","vanya_developer_mode"),("53 — Vanya Assistant","vanya_assistant"),("54 — Vanya Hub","vanya_hub"),("55 — Users","vanya_users"),("56 — Network","vanya_network"),("57 — Backup","_mega_backup"),("58 — Widgets","_mega_widgets"),("59 — Server Hosting","server_hosting")]),
        # RAM = оперативная память, которую серверу можно выделить.
("Файлы и инструменты", [("B — Ошибка","show_error"),("C — Запуск программы","run_program"),("D — Открыть папку","open_folder"),("E — Секретный дневник","secret_diary"),("F — Secret Storage","secret_storage"),("G — Matrix","matrix_effect"),("J — Факт","cool_fact"),("M — Настройки экрана","screen_settings"),("N — Hello Yarik","hello_yarik"),("Q — Todo List","todo_list"),("T — Быстрая заметка","quick_note"),("U — ASCII Art","ascii_art"),("X — Таймер учёбы","study_timer"),("Z — Помощь","cmd_help"),("31 — Статистика текста","text_stats"),("32 — Палитра","color_picker"),("33 — Шаблон мода","mod_template"),("39 — Vanya Calculator","vanya_calculator")]),
("Новое в 27.1 — Игры", [("Угадай число","guess_number"),("Виселица","hangman"),("Крестики-нолики","tic_tac_toe"),("Анаграмма","word_scramble"),("Викторина","trivia_quiz"),("Мат. дуэль","math_duel"),("Монетка","coin_flip"),("Магический шар","magic_8_ball"),("Игровой автомат","slot_machine"),("Генератор историй","story_generator"),("Загадки","riddle_game"),("Что бы ты выбрал?","would_you_rather"),("Я никогда не...","never_have_i_ever"),("КНБ-ящерица-спок","rock_paper_lizard_spock")]),
("Новое в 27.1 — Конвертеры", [("Температура","temperature_converter"),("Валюты","currency_converter"),("Текст↔двоичный","binary_text_converter"),("Азбука Морзе","morse_code"),("Шифр Цезаря","caesar_cipher"),("Реверс текста","text_reverser"),("Анализ предложений","sentence_analyzer"),("Палиндром","palindrome_checker"),("Анаграммы","anagram_checker"),("Високосный год","leap_year_checker"),("Простое число","prime_checker"),("Фибоначчи","fibonacci_generator"),("НОД и НОК","gcd_lcm_calculator"),("Римские цифры","roman_numeral_converter"),("Проценты","percentage_calculator")]),
("Новое в 27.1 — Система и разное", [("Батарея","battery_status"),("Диск (график)","disk_usage_chart"),("Wi-Fi инфо","wifi_info"),("Uptime","uptime_display"),("Поиск процесса","process_finder"),("Переменные окружения","env_variables_viewer"),("Буфер обмена","clipboard_tool"),("Скриншот","screenshot_tool"),("Хэш файла","file_hash_calculator"),("JSON форматтер","json_formatter"),("Цитата дня","motivational_quote"),("Знак зодиака","zodiac_sign"),("Фэнтези-имя","fantasy_name_gen"),("Комплимент","compliment_generator"),("Каламбуры","pun_generator"),("Счастливое число","lucky_number"),("Обратный отсчёт","countdown_timer"),("Таймер Помодоро","pomodoro_timer"),("Сменить акцент","accent_color_changer"),("Гороскоп Vanya OS","vanya_horoscope")]),
]

("Vanya OS 50+", [("1 — Быстрый доступ","v50_01"),("2 — История буфера","v50_02"),("3 — Недавние файлы","v50_03"),("4 — Центр уведомлений 2.0","v50_04"),("5 — Менеджер автозагрузки","v50_05"),("6 — Очиститель","v50_06"),("7 — Диагностика","v50_07"),("8 — Системный журнал","v50_08"),("9 — Безопасный режим","v50_09"),("10 — Монитор системы 2.0","v50_10"),("11 — Поиск файлов","v50_11"),("12 — Размер папки","v50_12"),("13 — Поиск дубликатов","v50_13"),("14 — Хэш файла","v50_14"),("15 — JSON-проверка","v50_15"),("16 — Base64","v50_16"),("17 — URL-кодировщик","v50_17"),("18 — Генератор UUID","v50_18"),("19 — Генератор паролей","v50_19"),("20 — Проверка пароля","v50_20"),("21 — Генератор цвета","v50_21"),("22 — RGB ↔ HEX","v50_22"),("23 — Секундомер","v50_23"),("24 — Таймер","v50_24"),("25 — Помодоро","v50_25"),("26 — Мировые часы","v50_26"),("27 — Календарь","v50_27"),("28 — Поиск заметок","v50_28"),("29 — Статистика текста","v50_29"),("30 — Счётчик слов","v50_30"),("31 — Регулярные выражения","v50_31"),("32 — Генератор чисел","v50_32"),("33 — Проценты","v50_33"),("34 — НОД/НОК","v50_34"),("35 — Фибоначчи","v50_35"),("36 — Простые числа","v50_36"),("37 — Конвертер температуры","v50_37"),("38 — Конвертер длины","v50_38"),("39 — Конвертер данных","v50_39"),("40 — Римские цифры","v50_40"),("41 — Информация о Python","v50_41"),("42 — Переменные окружения","v50_42"),("43 — Информация о диске","v50_43"),("44 — Информация о сети","v50_44"),("45 — Проверка порта","v50_45"),("46 — DNS-информация","v50_46"),("47 — Информация о файле","v50_47"),("48 — Дерево папки","v50_48"),("49 — Случайная цитата","v50_49"),("50 — Секретный режим","v50_50")]),


# ================================================================
# VANYA OS 50 — встроенные функции (больше не отдельный vanya_50.py)
# ================================================================
V50_FEATURES = [
    'Быстрый доступ','История буфера','Недавние файлы','Центр уведомлений 2.0','Менеджер автозагрузки',
    'Очиститель','Диагностика','Системный журнал','Безопасный режим','Монитор системы 2.0','Поиск файлов',
    'Размер папки','Поиск дубликатов','Хэш файла','JSON-проверка','Base64','URL-кодировщик','Генератор UUID',
    'Генератор паролей','Проверка пароля','Генератор цвета','RGB ↔ HEX','Секундомер','Таймер','Помодоро',
    'Мировые часы','Календарь','Поиск заметок','Статистика текста','Счётчик слов','Регулярные выражения',
    'Генератор чисел','Проценты','НОД/НОК','Фибоначчи','Простые числа','Конвертер температуры','Конвертер длины',
    'Конвертер данных','Римские цифры','Информация о Python','Переменные окружения','Информация о диске',
    'Информация о сети','Проверка порта','DNS-информация','Информация о файле','Дерево папки','Случайная цитата','Секретный режим'
]

def _v50_result(i, text):
    return f"#{i}. {V50_FEATURES[i-1]}\n\n{text}"

def _v50_disk_info():
    try:
        st=os.statvfs(Path.home()); free=st.f_bavail*st.f_frsize; total=st.f_blocks*st.f_frsize
        return f"Свободно: {free/1024**3:.1f} ГБ\nВсего: {total/1024**3:.1f} ГБ"
    except Exception as e: return str(e)

def _v50_run(i):
    now=datetime.now()
    results={
      1:'Быстрый запуск приложений и папок.', 2:'История скопированного текста.', 3:'Список недавно открытых файлов.',
      4:'История системных уведомлений.', 5:'Просмотр приложений автозагрузки.', 6:'Очистка временных файлов и кэша.',
      7:'Проверка основных компонентов Vanya OS.', 8:'Просмотр системных событий и ошибок.',
      9:'Запуск только основных компонентов.', 10:'Монитор CPU/RAM и процессов.', 11:'Поиск файлов по имени и расширению.',
      12:'Подсчёт размера папки.', 13:'Поиск одинаковых файлов.', 14:'Расчёт SHA-256 файла.',
      15:'Проверка и форматирование JSON.', 16:'Кодирование и декодирование Base64.', 17:'URL-кодирование и декодирование.',
      18:str(uuid.uuid4()), 19:''.join(random.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%') for _ in range(20)),
      20:'Проверка длины и сложности пароля.', 21:'#'+''.join(random.choice('0123456789ABCDEF') for _ in range(6)),
      22:'Преобразование RGB и HEX.', 23:'Секундомер.', 24:'Таймер обратного отсчёта.', 25:'Таймер Pomodoro.',
      26:f'Сейчас: {now.strftime("%H:%M:%S")}', 27:now.strftime('%d.%m.%Y'), 28:'Поиск по заметкам.',
      29:'Статистика текста.', 30:'Счётчик слов.', 31:'Тестер регулярных выражений.', 32:str(random.randint(1,1000000)),
      33:'Калькулятор процентов.', 34:f'НОД(84,36) = {math.gcd(84,36)}; НОК = {abs(84*36)//math.gcd(84,36)}',
      35:'Генератор последовательности Фибоначчи.', 36:'Проверка простого числа.', 37:'Конвертер температуры.',
      38:'Конвертер длины.', 39:'Конвертер единиц данных.', 40:'Конвертер римских цифр.',
      41:f'Python {platform.python_version()}\nИсполнитель: {sys.executable}', 42:f'Переменных окружения: {len(os.environ)}',
      43:_v50_disk_info(), 44:f'Имя компьютера: {socket.gethostname()}', 45:'Проверка TCP-порта.',
      46:'DNS-информация.', 47:'Информация о файле.', 48:'Дерево папки.',
      49:random.choice(['Создавай, экспериментируй, улучшай!','Каждая функция начинается с идеи.','Vanya OS становится лучше шаг за шагом.']),
      50:'🥚 VANYA OS SECRET MODE ACTIVATED 😎'
    }
    return _v50_result(i, results.get(i,'Готово.'))


class InternalWindow(tk.Frame):
    """Окно внутри Canvas рабочего стола. Перетаскивается за заголовок."""
    def __init__(self, desktop, title, w=620, h=430):
        super().__init__(desktop.desktop, bg=WINDOW_BG, bd=1, relief="solid", highlightthickness=0)
        self.desktop=desktop; self._drag=None; self.window_width=w; self.window_height=h
        self.titlebar=tk.Frame(self,bg=BAR,height=46); self.titlebar.pack(fill="x",side="top"); self.titlebar.pack_propagate(False)
        self.title_label=tk.Label(self.titlebar,text=title,bg=BAR,fg="white",font=("Arial",14,"bold"),anchor="w")
        self.title_label.pack(side="left",fill="both",expand=True,padx=14)
        # Кнопки окна: свернуть, развернуть/восстановить и закрыть.
        self.close_btn=tk.Label(self.titlebar,text="✕",bg=BAR,fg="white",font=("Arial",20,"bold"),width=3,cursor="hand2")
        self.max_btn=tk.Label(self.titlebar,text="▢",bg=BAR,fg="white",font=("Arial",16,"bold"),width=3,cursor="hand2")
        self.min_btn=tk.Label(self.titlebar,text="_",bg=BAR,fg="white",font=("Arial",18,"bold"),width=3,cursor="hand2")
        self.close_btn.pack(side="right",fill="y")
        self.max_btn.pack(side="right",fill="y")
        self.min_btn.pack(side="right",fill="y")
        self.close_btn.bind("<Button-1>",lambda e:self.close())
        self.max_btn.bind("<Button-1>",lambda e:self.toggle_maximize())
        self.min_btn.bind("<Button-1>",lambda e:self.minimize())
        for btn, hover in ((self.close_btn,"#8d424f"),(self.max_btn,"#59697a"),(self.min_btn,"#59697a")):
            btn.bind("<Enter>",lambda e,b=btn,c=hover:b.config(bg=c))
            btn.bind("<Leave>",lambda e,b=btn:b.config(bg=BAR))
        self._maximized=False
        self._minimized=False
        self._normal_geometry=None
        for wdg in (self.titlebar,self.title_label):
            wdg.bind("<Button-1>",self.start_drag); wdg.bind("<B1-Motion>",self.drag)
        self.content=tk.Frame(self,bg=WINDOW_BG); self.content.pack(fill="both",expand=True,padx=10,pady=10)
        self.window_width=w; self.window_height=h
        self.x=40; self.y=40
        # Полупрозрачная PNG-тень под окном. Canvas не умеет alpha у rectangle,
        # поэтому stipple здесь больше не используется.
        self._shadow_image = None
        self.item=self.desktop.desktop.create_window(self.x,self.y,window=self,anchor="nw",width=self.window_width,height=self.window_height)
        self._closing=False
        self.lift_window()
        self._animate_open(0)
    def lift_window(self):
        
        self.desktop.desktop.tag_raise(self.item)
    def _animate_open(self,step):
        if self._closing: return
        steps=5
        t=min(1.0,step/steps)
        # Двигаем готовое окно, не меняем его width/height на каждом кадре.
        dy=int((1.0-t)*18)
        self.desktop.desktop.coords(self.item,self.x,self.y+dy)
        if step<steps:
            self.after(16,lambda:self._animate_open(step+1))
        else:
            self.desktop.desktop.coords(self.item,self.x,self.y)

    def _apply_geometry(self, x, y, w, h):
        self.x, self.y = int(x), int(y)
        self.window_width, self.window_height = max(120,int(w)), max(90,int(h))
        self.desktop.desktop.itemconfigure(self.item, width=self.window_width, height=self.window_height)
        self.desktop.desktop.coords(self.item, self.x, self.y)

    def toggle_maximize(self):
        if self._closing or self._minimized: return
        if not self._maximized:
            self._normal_geometry=(self.x,self.y,self.window_width,self.window_height)
            w=max(120,self.desktop.desktop.winfo_width()-8)
            h=max(90,self.desktop.desktop.winfo_height()-8)
            self._apply_geometry(4,4,w,h)
            self._maximized=True
            self.max_btn.config(text="❐")
        else:
            x,y,w,h=self._normal_geometry or (40,40,620,430)
            self._apply_geometry(x,y,w,h)
            self._maximized=False
            self.max_btn.config(text="▢")
        self.lift_window()

    def minimize(self):
        if self._closing or self._minimized: return
        self._minimized=True
        self.desktop.desktop.itemconfigure(self.item, state="hidden")
        self.desktop._add_minimized_window(self)

    def restore(self):
        if self._closing: return
        self._minimized=False
        self.desktop.desktop.itemconfigure(self.item, state="normal")
        self.desktop._remove_minimized_window(self)
        self.lift_window()

    def close(self):
        if self._closing: return
        self._closing=True
        if self in self.desktop.open_windows: self.desktop.open_windows.remove(self)
        self.desktop._remove_minimized_window(self)
        self._animate_close(8)
    def _animate_close(self,step):
        steps=5
        t=max(0.0,step/steps)
        dy=int((1.0-t)*18)
        self.desktop.desktop.coords(self.item,self.x,self.y+dy)
        if step>0:
            self.after(16,lambda:self._animate_close(step-1))
        else:
            try: self.desktop.desktop.delete(self.item)
            except Exception: pass
            self.destroy()
    def start_drag(self,e):
        self.lift_window(); self._drag=(e.x_root,e.y_root)
    def drag(self,e):
        if not self._drag or self._closing or self._maximized:return
        dx=e.x_root-self._drag[0]; dy=e.y_root-self._drag[1]
        self._drag=(e.x_root,e.y_root)
        x,y=self.desktop.desktop.coords(self.item)
        maxx=max(0,self.desktop.desktop.winfo_width()-self.window_width); maxy=max(0,self.desktop.desktop.winfo_height()-self.window_height)
        self.x=max(0,min(x+dx,maxx)); self.y=max(0,min(y+dy,maxy))
        self.desktop.desktop.coords(self.item,self.x,self.y)
class VanyaDesktop(tk.Tk):
    def __init__(self):
        super().__init__(); self.title("Vanya OS 27.1"); self.geometry("1100x700"); self.minsize(900,600); self.configure(bg=BG)
        try:
            self.attributes("-fullscreen", True)
        except Exception:
            try: self.state("zoomed")
            except Exception: pass
        self.bind("<Escape>", lambda e: self._toggle_fullscreen(), add="+")
        self.protocol("WM_DELETE_WINDOW",self.destroy); self.open_windows=[]; self.minimized_windows={}; self.legacy_busy=False; self.current_workspace=1; self.workspace_count=3; self.theme_name="Vanya Dark"; self.theme_path=APP_DIR/"vanya_theme.json"; self.taskbar_pins_path=APP_DIR/"taskbar_pins.json"
        self.current_user = None
        self.server_processes = {}
        self.users = self._load_users()
        self.notifications_log = []
        self.lock_overlay = None
        self.lock_clock = None
        self.top=tk.Frame(self,bg=PANEL,height=42); self.top.pack(side="top",fill="x"); self.top.pack_propagate(False)
        self.brand_label=tk.Label(self.top,text="  VANYA OS 27.1",bg=PANEL,fg=TEXT,font=("Arial",13,"bold")); self.brand_label.pack(side="left",fill="y",pady=10)
        self.user_label=tk.Label(self.top,text="👤 —",bg=PANEL,fg=ACCENT,font=("Arial",11,"bold")); self.user_label.pack(side="left",padx=18)
        self.clock=tk.Label(self.top,bg=PANEL,fg=MUTED,font=("Arial",12)); self.clock.pack(side="right",padx=14)
        self.desktop=tk.Canvas(self,bg=BG,highlightthickness=0,bd=0); self.desktop.pack(fill="both",expand=True)
        self.wallpaper_path=APP_DIR/"wallpaper.png"
        self._wallpaper_source = Image.open(self.wallpaper_path) if HAVE_PIL else None
        self.wallpaper_image=tk.PhotoImage(file=str(self.wallpaper_path))
        self.wallpaper_item=self.desktop.create_image(0,0,image=self.wallpaper_image,anchor="nw",tags=("wallpaper",))
        # Настоящая полупрозрачная тень: PNG с alpha-каналом, а не stipple.
        self._shadow_images={}
        self._shadow_image=None
        self.desktop.tag_lower(self.wallpaper_item)
        self._resize_job=None
        self._wallpaper_size=None
        self._shadow_cache={}
        self.desktop.bind("<Configure>",self._on_desktop_resize,add="+")
        self.dock=tk.Frame(self,bg=PANEL,height=58); self.dock.pack(side="bottom",fill="x"); self.dock.pack_propagate(False)
        self.build_windows10_taskbar()
        self.bind("<Command-space>",lambda e:self.vanya_search()); self.bind("<Control-space>",lambda e:self.vanya_search())
        self.bind("<Command-l>",lambda e:self.show_lock_screen()); self.bind("<Control-l>",lambda e:self.show_lock_screen())
        self.apply_desktop_mods(); self.build_icons(); self.update_clock()
        self.after(80, self.show_lock_screen)
    def _load_users(self):
        default = {
            "users": [
                {"id":"vanya","name":"Vanya","role":"Администратор","emoji":"😎","color":"#55d6be"},
                {"id":"guest","name":"Guest","role":"Гость","emoji":"🙂","color":"#78a9ff"},
                {"id":"developer","name":"Developer","role":"Разработчик","emoji":"🛠️","color":"#ffb86b"}
            ]
        }
        try:
            if not USER_DB.exists():
                USER_DB.write_text(json.dumps(default,ensure_ascii=False,indent=2),encoding="utf-8")
            data=json.loads(USER_DB.read_text(encoding="utf-8"))
            users=data.get("users",[])
            if not isinstance(users,list) or not users:
                return default["users"]
            return users
        except Exception:
            return default["users"]

    def _save_users(self):
        try:
            USER_DB.write_text(json.dumps({"users":self.users},ensure_ascii=False,indent=2),encoding="utf-8")
        except Exception:
            pass

    def _user_home(self, user):
        home = USER_DATA_DIR / re.sub(r"[^A-Za-z0-9_-]", "_", user.get("id","user"))
        home.mkdir(parents=True,exist_ok=True)
        return home

    def show_lock_screen(self):
        if self.lock_overlay is not None:
            try:
                self.lock_overlay.lift()
                return
            except Exception:
                self.lock_overlay=None
        self.lock_overlay=tk.Frame(self,bg="#0e1219")
        self.lock_overlay.place(x=0,y=0,relwidth=1,relheight=1)
        self.lock_overlay.lift()
        # Decorative background panels
        glow=tk.Frame(self.lock_overlay,bg="#151c27")
        glow.place(relx=0.5,rely=0.5,anchor="center",relwidth=0.78,relheight=0.78)
        tk.Label(glow,text="🔒",bg="#151c27",fg=ACCENT,font=("Arial",36)).pack(pady=(38,4))
        tk.Label(glow,text="VANYA OS 27.1",bg="#151c27",fg=TEXT,font=("Arial",28,"bold")).pack()
        tk.Label(glow,text="Выберите пользователя",bg="#151c27",fg=MUTED,font=("Arial",14)).pack(pady=(4,18))
        if self.current_user:
            tk.Label(glow,text=f"Заблокировано • {self.current_user.get('name','Vanya')}",bg="#151c27",fg="#9aa7b8",font=("Arial",10)).pack(pady=(0,6))
        cards=tk.Frame(glow,bg="#151c27"); cards.pack(fill="both",expand=True,padx=40,pady=10)
        for i,user in enumerate(self.users):
            card=tk.Frame(cards,bg="#202733",highlightbackground="#303b4a",highlightthickness=1,cursor="hand2")
            card.grid(row=0,column=i,padx=10,pady=12,sticky="nsew")
            cards.grid_columnconfigure(i,weight=1)
            tk.Label(card,text=user.get("emoji","👤"),bg="#202733",fg=user.get("color",ACCENT),font=("Arial",40)).pack(pady=(18,6))
            tk.Label(card,text=user.get("name","User"),bg="#202733",fg=TEXT,font=("Arial",15,"bold")).pack()
            tk.Label(card,text=user.get("role","Пользователь"),bg="#202733",fg=MUTED,font=("Arial",10)).pack(pady=(2,14))
            tk.Label(card,text="Войти",bg=user.get("color",ACCENT),fg="#091017",font=("Arial",10,"bold"),padx=18,pady=7).pack(pady=(0,18))
            for widget in (card,)+tuple(card.winfo_children()):
                widget.bind("<Button-1>",lambda e,u=user:self._unlock_user(u))
                widget.bind("<Enter>",lambda e,c=card:c.config(bg="#2a3442"))
                widget.bind("<Leave>",lambda e,c=card:c.config(bg="#202733"))
        tk.Label(glow,text="⌘L / Ctrl+L — заблокировать экран",bg="#151c27",fg="#748297",font=("Arial",10)).pack(pady=10)

    def _unlock_user(self,user):
        self.current_user=user
        self._user_home(user)
        self.user_label.config(text=f"👤 {user.get('name','User')}")
        if self.lock_overlay is not None:
            try: self.lock_overlay.destroy()
            except Exception: pass
        self.lock_overlay=None
        self._notify(f"Добро пожаловать, {user.get('name','User')}! 🟢")

    def lock_screen(self):
        self.show_lock_screen()

    def vanya_lock(self):
        self.show_lock_screen()

    def vanya_users(self):
        win,inner=self._scrollable_window("👤 Vanya Users",720,520); self.base(win,"👤 Пользователи")
        current=tk.Label(inner,text=f"Текущий: {self.current_user.get('name') if self.current_user else 'не выбран'}",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")); current.pack(anchor="w",padx=12,pady=8)
        for user in self.users:
            row=tk.Frame(inner,bg=CARD); row.pack(fill="x",padx=10,pady=5)
            tk.Label(row,text=user.get("emoji","👤"),bg=CARD,fg=user.get("color",ACCENT),font=("Arial",24),width=4).pack(side="left",padx=8,pady=6)
            tk.Label(row,text=f"{user.get('name')}\n{user.get('role')}",bg=CARD,fg=TEXT,font=("Arial",11,"bold"),justify="left").pack(side="left",fill="x",expand=True)
            self.make_button(row,"Войти",lambda u=user:self._unlock_from_users(u,current),14).pack(side="right",padx=8,pady=8)
        self.make_button(inner,"🔒 Заблокировать экран",self.show_lock_screen,24).pack(anchor="w",padx=10,pady=14)

    def _unlock_from_users(self,user,status):
        self._unlock_user(user)
        status.config(text=f"Текущий: {user.get('name')}")

    def vanya_hub(self):
        win,inner=self._scrollable_window("🌐 Vanya Hub 27.1",900,620); self.base(win,"🌐 Vanya Hub")
        tk.Label(inner,text="Один центр для приложений, игр, тем и инструментов",bg=WINDOW_BG,fg="#444",font=("Arial",12)).pack(anchor="w",padx=12,pady=(0,10))
        groups=[
            ("🚀 Быстрый доступ",[("📁 Explorer",self.explorer),("📝 Notes",self.notes),("🎮 Games",self.games),("🛍️ Store",self.store),("🔎 Search",self.vanya_search)]),
            ("🛠️ Система",[("👤 Users",self.vanya_users),("🔔 Notifications",self.vanya_notifications),("🎛️ Control Center",self.vanya_control_center),("🌐 Network",self.vanya_network),("🛠️ Developer Center",self.vanya_developer_mode),("🖥️ Server Hosting",self.server_hosting)]),
            ("🎨 Создание",[("🎨 Theme Studio",self.vanya_theme_studio),("🧩 App Builder",self.vanya_app_builder),("🧪 Sandbox",self._mega_sandbox),("🗜️ VZIP",self._mega_archive)])
        ]
        for title,items in groups:
            tk.Label(inner,text=title,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",14,"bold")).pack(anchor="w",padx=10,pady=(14,6))
            grid=tk.Frame(inner,bg=WINDOW_BG); grid.pack(fill="x",padx=8)
            for i,(label,fn) in enumerate(items): self.make_button(grid,label,fn,22).grid(row=i//3,column=i%3,padx=5,pady=5,sticky="ew")
            for c in range(3): grid.grid_columnconfigure(c,weight=1)

    def vanya_network(self):
        win=self.new_window("🌐 Vanya Network",680,500); self.base(win,"🌐 Vanya Network")
        info=tk.Text(win.content,bg="#10151d",fg="#dce8ff",font=("Menlo",11),height=18,bd=0); info.pack(fill="both",expand=True,padx=12,pady=8)
        def refresh():
            try:
                host=platform.node()
                local=__import__('socket').gethostbyname(host)
            except Exception: local="не определён"
            lines=[f"Хост: {host}",f"Локальный IP: {local}",f"Платформа: {platform.platform()}",f"Текущий пользователь: {self.current_user.get('name') if self.current_user else '—'}", "", "Geyser / Minecraft:"
            ]
            info.delete("1.0","end"); info.insert("end","\n".join(lines)+"\n\nСовет: внешний IP и UDP-порты зависят от хостинга.")
        self.make_button(win.content,"🔄 Обновить",refresh,16).pack(anchor="w",padx=12,pady=5); refresh()

    def _toggle_fullscreen(self):
        try:
            self.attributes("-fullscreen", not bool(self.attributes("-fullscreen")))
        except Exception:
            try: self.state("normal" if self.state()=="zoomed" else "zoomed")
            except Exception: pass

    def _enable_trackpad_scroll(self, canvas, inner=None):
        """Включает прокрутку Canvas колесом мыши и тачпадом macOS.
        Обработчик добавляется отдельным bindtag, поэтому не ломает обычные клики.
        """
        tag=f"VanyaTrackpad_{id(canvas)}"
        def wheel(event):
            delta=getattr(event,"delta",0) or 0
            num=getattr(event,"num",None)
            if num==4:
                units=-3
            elif num==5:
                units=3
            elif delta:
                # macOS может присылать маленькие значения delta от тачпада,
                # Windows обычно присылает 120, Linux — Button-4/5.
                direction=-1 if delta>0 else 1
                amount=max(1,min(6,round(abs(delta)/30)))
                units=direction*amount
            else:
                return
            try:
                canvas.yview_scroll(units,"units")
                return "break"
            except tk.TclError:
                return

        self.bind_class(tag,"<MouseWheel>",wheel,add="+")
        self.bind_class(tag,"<Button-4>",wheel,add="+")
        self.bind_class(tag,"<Button-5>",wheel,add="+")

        def add_tag(widget):
            try:
                tags=list(widget.bindtags())
                if tag not in tags:
                    widget.bindtags((tag,)+tuple(tags))
            except Exception:
                pass
            for child in widget.winfo_children():
                add_tag(child)

        add_tag(canvas)
        if inner is not None:
            inner.bind("<Configure>",lambda e:add_tag(inner),add="+")
            add_tag(inner)
        return tag

    def _on_desktop_resize(self,e=None):
        if self._resize_job is not None:
            try: self.after_cancel(self._resize_job)
            except Exception: pass
        self._resize_job=self.after(120,self._finish_desktop_resize)
    def _finish_desktop_resize(self):
        self._resize_job=None
        self._position_wallpaper()
        self._keep_windows_visible()
        self.position_icons()

    def _keep_windows_visible(self):
        for win in list(self.open_windows):
            if getattr(win,"_closing",False) or getattr(win,"_minimized",False): continue
            try:
                maxx=max(0,self.desktop.winfo_width()-win.window_width); maxy=max(0,self.desktop.winfo_height()-win.window_height)
                win.x=max(0,min(win.x,maxx)); win.y=max(0,min(win.y,maxy))
                self.desktop.coords(win.item,win.x,win.y)
                self.desktop.coords(win.shadow,win.x,win.y) if win.shadow else None
            except Exception: pass
    def update_clock(self):
        self.clock.config(text=datetime.now().strftime("%d.%m.%Y  %H:%M:%S")); self.after(1000,self.update_clock)
    def _taskbar_default_pins(self):
        return ["explorer", "notes", "games"]

    def _taskbar_catalog(self):
        items = [
            ("all_functions", "🧰 Все функции", self.all_functions),
            ("terminal", "💻 Терминал", self.terminal),
            ("vanya_hub", "🌐 Vanya Hub", self.vanya_hub),
            ("server_hosting", "🖥️ Server Hosting", self.server_hosting),
            ("start_menu", "◈ Пуск", self.start_menu),
            ("lock_screen", "🔒 Заблокировать", self.show_lock_screen),
            ("search", "🔎 Vanya Search", self.vanya_search),
            ("notes", "📝 Заметки", self.notes),
            ("games", "🎮 Игры", self.games),
            ("store", "🛒 Vanya Store", self.store),
            ("task_manager", "📊 Task Manager", self.vanya_task_manager),
            ("control_center", "⚙️ Control Center", self.vanya_control_center),
            ("explorer", "📁 Explorer", self.explorer),
        ]
        # Добавляем известные функции из общего каталога.
        known = {x[0] for x in items}
        for _cat, entries in FUNCTIONS:
            for label, name in entries:
                if name in known:
                    continue
                fn = getattr(self, name, None)
                if callable(fn):
                    items.append((name, label, fn)); known.add(name)
        return items

    def _load_taskbar_pins(self):
        default = self._taskbar_default_pins()
        try:
            if not self.taskbar_pins_path.exists():
                self.taskbar_pins_path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
                return default
            data = json.loads(self.taskbar_pins_path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return [str(x) for x in data]
        except Exception:
            pass
        return default

    def _save_taskbar_pins(self):
        try:
            self.taskbar_pins_path.write_text(json.dumps(self.taskbar_pins, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def build_windows10_taskbar(self):
        """Современная панель задач: поиск слева, приложения строго по центру."""
        self.taskbar_pins = self._load_taskbar_pins()
        self.taskbar_catalog = {key: (label, fn) for key, label, fn in self._taskbar_catalog()}

        start = self.make_dock_button("◈ Пуск", self.start_menu)
        start.place(x=7, rely=0.5, anchor="w")
        start.bind("<Button-3>", lambda e: self._taskbar_context(e, "start_menu"))

        search_wrap = tk.Frame(self.dock, bg="#20242b", highlightthickness=1, highlightbackground="#3a414b")
        search_wrap.place(x=88, rely=0.5, anchor="w")
        tk.Label(search_wrap, text="🔎", bg="#20242b", fg=MUTED, font=("Arial", 11)).pack(side="left", padx=(8, 2))
        self.taskbar_search_var = tk.StringVar()
        self.taskbar_search_entry = tk.Entry(search_wrap, textvariable=self.taskbar_search_var, width=18,
                                              bg="#20242b", fg=TEXT, insertbackground=TEXT, relief="flat", bd=0, font=("Arial", 11))
        self.taskbar_search_entry.pack(side="left", padx=(0, 8), ipady=6)
        self.taskbar_search_entry.insert(0, "Поиск")
        self.taskbar_search_entry.config(fg=MUTED)
        self.taskbar_search_entry.bind("<FocusIn>", self._taskbar_search_focus_in)
        self.taskbar_search_entry.bind("<FocusOut>", self._taskbar_search_focus_out)
        self.taskbar_search_entry.bind("<KeyRelease>", self._taskbar_search_changed)
        self.taskbar_search_entry.bind("<Return>", self._taskbar_search_enter)

        self.taskbar_apps_frame = tk.Frame(self.dock, bg=PANEL)
        self.taskbar_apps_frame.place(relx=0.5, rely=0.5, anchor="center")
        self._taskbar_render_pins()

        tk.Label(self.dock, text="Vanya OS 27.1", bg=PANEL, fg=MUTED, font=("Arial", 9)).place(relx=1.0, x=-12, rely=0.5, anchor="e")

    def _taskbar_render_pins(self):
        for w in self.taskbar_apps_frame.winfo_children():
            w.destroy()
        icons = {"explorer":"📁", "notes":"📝", "games":"🎮", "store":"🛍️", "terminal":"💻", "vanya_hub":"🌐", "all_functions":"🧰"}
        for key in self.taskbar_pins:
            data = self.taskbar_catalog.get(key)
            if not data:
                continue
            label, fn = data
            icon = icons.get(key, label.split(" ", 1)[0] if label else "◉")
            b = tk.Button(self.taskbar_apps_frame, text=icon, command=fn, bg=PANEL, fg=TEXT, activebackground=ACCENT,
                          activeforeground="#07151a", relief="flat", bd=0, font=("Arial", 22), width=3, height=1, cursor="hand2")
            b.pack(side="left", padx=3, pady=3)
            b.bind("<Enter>", lambda e, w=b: w.configure(bg="#414954"))
            b.bind("<Leave>", lambda e, w=b: w.configure(bg=PANEL))
            b.bind("<Button-3>", lambda e, k=key: self._taskbar_context(e, k))
            # Подсказка с названием приложения
            self._add_tooltip(b, label)

    def _add_tooltip(self, widget, text):
        tip = [None]
        def show(_=None):
            if tip[0] is not None: return
            try:
                x=widget.winfo_rootx()+widget.winfo_width()//2; y=widget.winfo_rooty()-30
                t=tk.Toplevel(self); t.overrideredirect(True); t.configure(bg="#11161c")
                t.geometry(f"+{x-55}+{y}")
                tk.Label(t,text=text,bg="#11161c",fg="white",font=("Arial",9),padx=8,pady=4).pack()
                tip[0]=t
            except Exception: pass
        def hide(_=None):
            if tip[0] is not None:
                try: tip[0].destroy()
                except Exception: pass
                tip[0]=None
        widget.bind("<Enter>", show, add="+"); widget.bind("<Leave>", hide, add="+")

    def _taskbar_context(self, event, key):
        menu = tk.Menu(self, tearoff=0, bg=CARD, fg=TEXT, activebackground=ACCENT, activeforeground="#07151a")
        if key in self.taskbar_pins:
            menu.add_command(label="📌 Открепить от панели задач", command=lambda k=key: self._taskbar_unpin(k))
        else:
            menu.add_command(label="📌 Закрепить на панели задач", command=lambda k=key: self._taskbar_pin(k))
        menu.add_separator()
        menu.add_command(label="⚙️ Настроить панель задач", command=self.taskbar_settings)
        menu.tk_popup(event.x_root, event.y_root)

    def _taskbar_pin(self, key):
        if key in self.taskbar_catalog and key not in self.taskbar_pins:
            self.taskbar_pins.append(key)
            self._save_taskbar_pins()
            self._taskbar_render_pins()

    def _taskbar_unpin(self, key):
        if key in self.taskbar_pins:
            self.taskbar_pins.remove(key)
            self._save_taskbar_pins()
            self._taskbar_render_pins()

    def _taskbar_search_focus_in(self, _event=None):
        if self.taskbar_search_var.get() == "Поиск":
            self.taskbar_search_var.set("")
            self.taskbar_search_entry.config(fg=TEXT)

    def _taskbar_search_focus_out(self, _event=None):
        if not self.taskbar_search_var.get().strip():
            self.taskbar_search_var.set("Поиск")
            self.taskbar_search_entry.config(fg=MUTED)

    def _taskbar_search_changed(self, _event=None):
        q = self.taskbar_search_var.get().strip().lower()
        if not q or q == "поиск":
            self._close_taskbar_results()
            return
        matches = []
        for key, (label, fn) in self.taskbar_catalog.items():
            if q in label.lower() or q in key.lower():
                matches.append((key, label, fn))
        self._show_taskbar_results(matches[:8])

    def _show_taskbar_results(self, matches):
        self._close_taskbar_results()
        if not matches:
            return
        self.taskbar_results = tk.Toplevel(self)
        self.taskbar_results.overrideredirect(True)
        self.taskbar_results.configure(bg=PANEL)
        self.taskbar_results.attributes("-topmost", True)
        x = self.taskbar_search_entry.winfo_rootx()
        y = self.taskbar_search_entry.winfo_rooty() - min(8, len(matches)) * 39 - 8
        if y < 10: y = self.taskbar_search_entry.winfo_rooty() + self.taskbar_search_entry.winfo_height() + 4
        self.taskbar_results.geometry(f"340x{len(matches)*39 + 8}+{x}+{y}")
        for key, label, fn in matches:
            row = tk.Frame(self.taskbar_results, bg=CARD, cursor="hand2")
            row.pack(fill="x", padx=4, pady=2)
            tk.Label(row, text=label, bg=CARD, fg=TEXT, font=("Arial", 10, "bold"), anchor="w").pack(fill="both", expand=True, padx=10, pady=7)
            row.bind("<Button-1>", lambda e, f=fn: (self._close_taskbar_results(), f()))
            row.bind("<Button-3>", lambda e, k=key: self._taskbar_context(e, k))

    def _close_taskbar_results(self):
        w = getattr(self, "taskbar_results", None)
        if w is not None:
            try: w.destroy()
            except Exception: pass
            self.taskbar_results = None

    def _taskbar_search_enter(self, _event=None):
        if getattr(self, "taskbar_results", None):
            children = self.taskbar_results.winfo_children()
            if children:
                children[0].event_generate("<Button-1>")

    def taskbar_settings(self):
        win = self.new_window("⚙️ Панель задач", 560, 420)
        self.base(win, "Панель задач Vanya OS")
        tk.Label(win.content, text="Панель задач", bg=WINDOW_BG, fg=WINDOW_TEXT, font=("Arial", 18, "bold")).pack(pady=(12, 4))
        tk.Label(win.content, text="Закреплённые приложения сохраняются в taskbar_pins.json.", bg=WINDOW_BG, fg=MUTED).pack(pady=(0, 12))
        for key, (label, fn) in self.taskbar_catalog.items():
            var = tk.BooleanVar(value=key in self.taskbar_pins)
            cb = tk.Checkbutton(win.content, text=label, variable=var, bg=WINDOW_BG, fg=WINDOW_TEXT,
                                selectcolor=CARD, activebackground=WINDOW_BG, activeforeground=WINDOW_TEXT,
                                anchor="w", command=lambda k=key, v=var: self._taskbar_toggle_pin(k, v.get()))
            cb.pack(fill="x", padx=30, pady=2)

    def _taskbar_toggle_pin(self, key, value):
        if value: self._taskbar_pin(key)
        else: self._taskbar_unpin(key)

    def make_button(self,parent,text,command,width=18):
        # Кастомная кнопка: никаких системных белых Tk-кнопок на macOS.
        frame=tk.Frame(parent,bg=CARD,bd=0,highlightthickness=0,cursor="hand2")
        label=tk.Label(frame,text=text,bg=CARD,fg=TEXT,font=("Arial",11,"bold"),anchor="center",padx=10,pady=7)
        label.pack(fill="both",expand=True)
        def click(_=None): command()
        def enter(_=None): frame.config(bg=ACCENT); label.config(bg=ACCENT,fg="#07151a")
        def leave(_=None): frame.config(bg=CARD); label.config(bg=CARD,fg=TEXT)
        for w in (frame,label):
            w.bind("<Button-1>",click); w.bind("<Enter>",enter); w.bind("<Leave>",leave)
        return frame
    def make_dock_button(self,text,cmd): return self.make_button(self.dock,text,cmd,width=16)
    def new_window(self,title,w=620,h=430):
        win=InternalWindow(self,title,w,h); self.open_windows.append(win); return win
    def _stretch_wallpaper_png(self, path, w, h):
        """Растягивает PNG точно до w×h без Pillow и без внешних программ."""
        raw = path.read_bytes()
        if raw[:8] != b"\x89PNG\r\n\x1a\n":
            raise ValueError("Не PNG")
        pos = 8; chunks = []; width = height = ctype = None; bitdepth = None
        while pos < len(raw):
            n = struct.unpack(">I", raw[pos:pos+4])[0]; typ = raw[pos+4:pos+8]; data = raw[pos+8:pos+8+n]; pos += 12+n
            if typ == b"IHDR":
                width, height, bitdepth, ctype, comp, filt, inter = struct.unpack(">IIBBBBB", data)
                if bitdepth != 8 or ctype not in (2, 6) or inter != 0: raise ValueError("Неподдерживаемый PNG")
            elif typ == b"IDAT": chunks.append(data)
            elif typ == b"IEND": break
        bpp = 3 if ctype == 2 else 4
        decoded = zlib.decompress(b"".join(chunks)); stride = width*bpp; rows=[]; prev=bytearray(stride); off=0
        for _ in range(height):
            f=decoded[off]; off += 1; cur=bytearray(decoded[off:off+stride]); off += stride
            for i in range(stride):
                a=cur[i-bpp] if i>=bpp else 0; b=prev[i]; c=prev[i-bpp] if i>=bpp else 0
                if f==1: cur[i]=(cur[i]+a)&255
                elif f==2: cur[i]=(cur[i]+b)&255
                elif f==3: cur[i]=(cur[i]+((a+b)//2))&255
                elif f==4:
                    p0=a+b-c; pa=abs(p0-a); pb=abs(p0-b); pc=abs(p0-c); pr=a if pa<=pb and pa<=pc else (b if pb<=pc else c); cur[i]=(cur[i]+pr)&255
            rows.append(cur); prev=cur
        out=bytearray()
        for y in range(h):
            src=rows[min(height-1, int(y*height/h))]; out.append(0)
            for x in range(w):
                sx=min(width-1, int(x*width/w)); i=sx*bpp
                if bpp==3: out.extend(src[i:i+3])
                else: out.extend(src[i:i+4])
        def chunk(t,d): return struct.pack(">I",len(d))+t+d+struct.pack(">I",zlib.crc32(t+d)&0xffffffff)
        return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR",struct.pack(">IIBBBBB",w,h,8,ctype,0,0,0)) + chunk(b"IDAT",zlib.compress(bytes(out),6)) + chunk(b"IEND",b"")

    def _position_wallpaper(self):
        """Растягивает обои ровно на весь рабочий стол после завершения изменения размера."""
        try:
            w=max(1,self.desktop.winfo_width()); h=max(1,self.desktop.winfo_height())
            last=getattr(self,"_wallpaper_size",None)
            if last==(w,h): return
            self._wallpaper_size=(w,h)
            if HAVE_PIL and self._wallpaper_source is not None:
                resized=self._wallpaper_source.resize((w,h), Image.Resampling.BILINEAR)
                self.wallpaper_image=ImageTk.PhotoImage(resized)
            else:
                png=self._stretch_wallpaper_png(self.wallpaper_path,w,h)
                self.wallpaper_image=tk.PhotoImage(data=base64.b64encode(png).decode("ascii"))
            self.desktop.itemconfigure(self.wallpaper_item,image=self.wallpaper_image)
            self.desktop.coords(self.wallpaper_item,0,0)
            self.desktop.tag_lower(self.wallpaper_item)
        except Exception:
            pass

    def _add_minimized_window(self, win):
        if win in self.minimized_windows: return
        btn=self.make_button(self.dock, f"▣ {win.title_label.cget('text')}", win.restore, width=18)
        btn.pack(side="left",padx=3,pady=8)
        self.minimized_windows[win]=btn

    def _remove_minimized_window(self, win):
        btn=self.minimized_windows.pop(win,None)
        if btn is not None:
            try: btn.destroy()
            except Exception: pass

    def _load_icon_positions(self):
        try:
            if self.desktop_icons_path.exists():
                data=json.loads(self.desktop_icons_path.read_text(encoding="utf-8"))
                if isinstance(data,dict):
                    return {str(k):(float(v[0]),float(v[1])) for k,v in data.items() if isinstance(v,(list,tuple)) and len(v)>=2}
        except Exception:
            pass
        return {}
    def _save_icon_positions(self):
        try:
            data={}
            for tag, *_ in getattr(self,'icon_tags',[]):
                ids=self.desktop.find_withtag(tag)
                if ids:
                    x,y=self.desktop.coords(ids[0])
                    data[tag]=[round(x,1),round(y,1)]
            self.desktop_icons_path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
        except Exception:
            pass
    def icon(self,row,col,emoji,title,cmd):
        # Иконки прозрачные и теперь свободно перетаскиваются по рабочему столу.
        tag=f"desktop_icon_{len(getattr(self,'icon_tags',[]))}"
        if not hasattr(self,'icon_tags'): self.icon_tags=[]
        self.icon_tags.append((tag,row,col))
        x=y=0
        self.desktop.create_text(x,y,text=emoji,font=("Arial",30),fill=TEXT,anchor="center",tags=("desktop_icon",tag))
        self.desktop.create_text(x,y+34,text=title,font=("Arial",11,"bold"),fill="white",anchor="center",tags=("desktop_icon",tag))
        self.desktop.tag_bind(tag,"<ButtonPress-1>",lambda e,t=tag,c=cmd:self._icon_drag_start(e,t,c))
        self.desktop.tag_bind(tag,"<B1-Motion>",lambda e,t=tag:self._icon_drag_motion(e,t))
        self.desktop.tag_bind(tag,"<ButtonRelease-1>",lambda e,t=tag,c=cmd:self._icon_drag_end(e,t,c))
        self.desktop.tag_bind(tag,"<Enter>",lambda e:self._icon_hover(tag,True))
        self.desktop.tag_bind(tag,"<Leave>",lambda e:self._icon_hover(tag,False))
        self.position_icons()
    def _icon_drag_start(self,event,tag,cmd):
        ids=self.desktop.find_withtag(tag)
        if not ids: return
        x,y=self.desktop.coords(ids[0])
        self.icon_drag_state[tag]={"start_x":event.x,"start_y":event.y,"x":x,"y":y,"moved":False,"cmd":cmd}
        self.desktop.config(cursor="fleur")
    def _icon_drag_motion(self,event,tag):
        state=self.icon_drag_state.get(tag)
        if not state: return
        dx=event.x-state["start_x"]; dy=event.y-state["start_y"]
        if abs(dx)>4 or abs(dy)>4: state["moved"]=True
        if not state["moved"]: return
        x=max(45,min(self.desktop.winfo_width()-45,state["x"]+dx))
        y=max(45,min(self.desktop.winfo_height()-80,state["y"]+dy))
        ids=self.desktop.find_withtag(tag)
        for idx,item in enumerate(ids):
            self.desktop.coords(item,x,y+(34 if idx==1 else 0))
    def _icon_drag_end(self,event,tag,cmd):
        state=self.icon_drag_state.pop(tag,None)
        self.desktop.config(cursor="hand2")
        if not state: return
        if state["moved"]:
            self._save_icon_positions()
        else:
            try: cmd()
            except Exception: pass
    def _icon_hover(self,tag,on):
        self.desktop.itemconfigure(tag,fill=(ACCENT if on else "white"))
        if tag not in self.icon_drag_state: self.desktop.config(cursor="hand2" if on else "")
    def position_icons(self):
        self.update_idletasks()
        width=max(900,self.desktop.winfo_width()); cols=5; cell_w=width/cols; start_y=34
        if not hasattr(self,'icon_positions'): self.icon_positions=self._load_icon_positions()
        for tag,row,col in getattr(self,'icon_tags',[]):
            saved=self.icon_positions.get(tag)
            if saved:
                x,y=saved
                # Масштабируем сохранённую позицию только по ширине, сохраняя пользовательскую раскладку.
                x=max(45,min(width-45,x))
            else:
                x=col*cell_w+cell_w/2; y=start_y+row*118
            ids=self.desktop.find_withtag(tag)
            for idx,item in enumerate(ids):
                self.desktop.coords(item,x,y+(34 if idx==1 else 0))
    def apply_desktop_mods(self):
        """Apply enabled Vanya OS .txt mods to the graphical desktop."""
        try:
            spec=importlib.util.spec_from_file_location("vanya_classic_mods", APP_DIR/"vanya_classic.py")
            mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            mods=mod.load_mods()
            title,fg,count,names=mod.apply_mods(mods)
            self.title(title)
            if names:
                self.mod_status=f"🧩 Моды: {count}"
            else:
                self.mod_status="🧩 Моды: 0"
        except Exception:
            self.mod_status="🧩 Моды: ?"

    def mega_tools(self):
        win=self.new_window("🧰 Инструменты",920,620)
        self.base(win,"🧰 Инструменты")
        canvas=tk.Canvas(win.content,bg=WINDOW_BG,highlightthickness=0)
        sb=tk.Scrollbar(win.content,command=canvas.yview)
        inner=tk.Frame(canvas,bg=WINDOW_BG)
        inner.bind("<Configure>",lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0),window=inner,anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
        self._enable_trackpad_scroll(canvas,inner)
        items=[
            ("🌐 Vanya Hub","Каталог всех приложений",self.vanya_hub),
            ("🚀 Vanya OS 50+","50 новых мини-функций",self.vanya_50_plus),
            ("🖥️ Server Hosting","Свой Minecraft-сервер",self.server_hosting),
            ("🧩 Mods","Менеджер модов",self.mods),
            ("🧮 Calculator","Калькулятор",self.calculator),
            ("🔎 Search","Поиск по Vanya OS",self.vanya_search),
            ("📊 Task Manager","Диспетчер задач",self.vanya_task_manager),
            ("🌐 Network","Диагностика сети",self.vanya_network),
            ("🕹️ Arcade","Классический игровой зал",self.vanya_arcade),
            ("🛠️ Developer Mode","Инструменты разработчика",self.vanya_developer_mode),
            ("🧠 Vanya AI","Локальный помощник",self.vanya_assistant),
            ("🎲 Games (классика)","Старый список игр",self.games),
            ("🗃️ Vanya Backup","Создание резервной копии",self._mega_backup),
            ("🔔 Notifications","Центр уведомлений",self.vanya_notifications),
            ("📦 Package Manager","Менеджер пакетов",self._mega_packages),
            ("🔄 Updater","Проверка обновлений",self.vanya_updater),
            ("👤 Users","Профили пользователя",self._mega_users),
            ("🖼️ Gallery","Галерея изображений",self._mega_gallery),
            ("🎵 Music","Музыкальный центр",self._mega_music),
            ("🗜️ VZIP Archive","Архиватор VZIP",self._mega_archive),
            ("🖥️ Terminal 2.0","Новая консоль",self.terminal),
            ("🧪 Sandbox","Папка экспериментов",self._mega_sandbox),
            ("🧱 Widgets","Виджеты",self._mega_widgets),
            ("🥚 Secret Room","Секретная комната",self._mega_secrets),
            ("🏆 Achievements","Система достижений",self._mega_achievements),
            ("📱 Vanya Phone","Симулятор телефона",self._mega_phone),
            ("🌍 Vanya World","Мини-мир Vanya",self._mega_world),
            ("🎨 Theme Studio","Редактор тем",self.vanya_theme_studio),
            ("🧩 App Builder","Создание .vanya",self.vanya_app_builder),
            ("🎮 Game Center","Все игры в одном месте",self.game_center),
            ("🧰 Recovery","Восстановление Vanya OS",self.vanya_recovery),
            ("🤖 AI Lab","Офлайн ИИ-игрушки",self.vanya_ai_lab),
            ("🧪 Lab","Запуск своего Python-кода",self.vanya_lab),
            ("🛍️ Vanya Store","Магазин .vanya приложений",self.store),
        ]
        for i,(title,desc,cmd) in enumerate(items):
            r,c=divmod(i,2); card=tk.Frame(inner,bg=CARD); card.grid(row=r,column=c,sticky="nsew",padx=7,pady=7)
            inner.grid_columnconfigure(c,weight=1)
            self.make_button(card,title,cmd,24).pack(fill="x",padx=8,pady=(8,4))
            tk.Label(card,text=desc,bg=CARD,fg=MUTED,font=("Arial",10),anchor="w").pack(fill="x",padx=10,pady=(0,10))

    def _mega_message(self,title,msg):
        w=self.new_window(title,600,400); self.base(w,title)
        tk.Label(w.content,text=msg,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13),justify="left",wraplength=550).pack(fill="both",expand=True,padx=20,pady=20)
        self.make_button(w.content,"Закрыть",w.close,14).pack(pady=8)

    def _mega_backup(self):
        import zipfile
        folder=APP_DIR/"backups"; folder.mkdir(exist_ok=True)
        target=folder/("Vanya_OS_21_backup_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".vbackup")
        try:
            with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
                for name in ("notes","mods","vanya_apps","packages","vanya_settings.txt"):
                    q=APP_DIR/name
                    if q.is_file(): z.write(q,q.name)
                    elif q.is_dir():
                        for f in q.rglob("*"):
                            if f.is_file(): z.write(f,f.relative_to(APP_DIR))
            self._mega_message("🗃️ Backup",f"Резервная копия создана:\n\n{target}")
        except Exception as e: self._mega_message("🗃️ Backup",f"Ошибка backup:\n{e}")

    def _mega_packages(self):
        self._mega_message("📦 Package Manager","Команды Vanya Package Manager:\n\n• vanya install <app>\n• vanya remove <app>\n• vanya list\n• vanya update")
    def _mega_users(self): self.vanya_users()
    def _mega_gallery(self): self.explorer()
    def _mega_music(self): self._mega_message("🎵 Music","Открой папку Music в Explorer, чтобы работать с музыкой.")
    def _mega_archive(self): self.vanya_archive()
    def _mega_sandbox(self):
        q=APP_DIR/"sandbox"; q.mkdir(exist_ok=True); self._mega_message("🧪 Sandbox",f"Папка Sandbox:\n\n{q}")
    def _mega_widgets(self):
        win=self.new_window("🧱 Vanya Widgets",760,520); self.base(win,"🧱 Vanya Widgets")
        grid=tk.Frame(win.content,bg=WINDOW_BG); grid.pack(fill="both",expand=True,padx=12,pady=12)
        cards=[("🕐",datetime.now().strftime("%H:%M:%S"),"Часы"),("📅",datetime.now().strftime("%d.%m.%Y"),"Дата"),("🖥️",str(self.current_workspace),"Рабочий стол"),("👤",self.current_user.get("name") if self.current_user else "—","Пользователь"),("🪟",str(len(self.open_windows)),"Открытых окон"),("🧩",self.mod_status,"Моды")]
        for i,(icon,val,cap) in enumerate(cards):
            r,c=divmod(i,3); card=tk.Frame(grid,bg=CARD); card.grid(row=r,column=c,padx=8,pady=8,sticky="nsew"); grid.grid_columnconfigure(c,weight=1); grid.grid_rowconfigure(r,weight=1)
            tk.Label(card,text=icon,bg=CARD,fg=ACCENT,font=("Arial",28)).pack(pady=(18,4))
            tk.Label(card,text=val,bg=CARD,fg=TEXT,font=("Arial",15,"bold"),wraplength=180).pack()
            tk.Label(card,text=cap,bg=CARD,fg=MUTED,font=("Arial",10)).pack(pady=(2,16))
    def _mega_secrets(self): self._mega_message("🥚 Secret Room","🥚 СЕКРЕТНАЯ КОМНАТА\n\nVANYA OS SECRET MODE ACTIVATED 😎")
    def _mega_achievements(self): self._mega_message("🏆 Achievements","🏆 ДОСТИЖЕНИЯ\n\n✅ Первый запуск\n⬜ Первая заметка\n⬜ 10 приложений\n⬜ Найден секрет\n⬜ Победа в игре")
    def _mega_phone(self): self._mega_message("📱 Vanya Phone","┌─────────────────┐\n│   Vanya Phone   │\n│                 │\n│  📞  💬  🎵     │\n│  📷  ⚙️  🗺️     │\n└─────────────────┘")
    def _mega_world(self): self._mega_message("🌍 Vanya World","🌍 Vanya World\n\nМини-мир внутри Vanya OS.\nЗдесь можно будет исследовать локации и искать секреты.")

    def vanya_50_plus(self):
        win=self.new_window("🚀 Vanya OS 50+",900,620)
        self.base(win,"🚀 Vanya OS 50+ — 50 новых функций")
        canvas=tk.Canvas(win.content,bg=WINDOW_BG,highlightthickness=0)
        sb=tk.Scrollbar(win.content,command=canvas.yview)
        inner=tk.Frame(canvas,bg=WINDOW_BG)
        inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0),window=inner,anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
        self._enable_trackpad_scroll(canvas,inner)
        for i,name in enumerate(V50_FEATURES,1):
            def launch(n=i):
                try: self._mega_message(f"🚀 {V50_FEATURES[n-1]}", _v50_run(n))
                except Exception as e: self._mega_message("Vanya OS 50+",f"Ошибка функции #{n}:\n{e}")
            r,c=divmod(i-1,2); card=tk.Frame(inner,bg=CARD); card.grid(row=r,column=c,sticky="nsew",padx=7,pady=6); inner.grid_columnconfigure(c,weight=1)
            self.make_button(card,f"{i}. {name}",launch,22).pack(fill="x",padx=8,pady=8)
    def build_icons(self):
        self.icon_positions=self._load_icon_positions()
        icons=[("📁","Explorer",self.explorer),("📝","Notes",self.notes),("🎮","Game Center",self.game_center),("💻","Terminal",self.terminal),("🛍️","Vanya Store",self.store),("⚙️","Settings",self.settings),("🧰","Инструменты",self.all_functions)]
        for i,(e,t,c) in enumerate(icons): self.icon(i//5,i%5,e,t,c)
        self.bind_icon_resize()
    def bind_icon_resize(self):
        pass
    def base(self,win,title=None):
        if title: tk.Label(win.content,text=title,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",19,"bold")).pack(anchor="w",padx=12,pady=8)
    def explorer(self):
        """Полноценный Vanya Explorer — файловый менеджер внутри Vanya OS.

        По стилю и логике он вдохновлён проводником из скриншота: верхнее меню,
        навигация, адресная строка, поиск, боковая панель, карточки папок/дисков
        и рабочая область. Никаких отдельных окон Finder для навигации по папкам.
        """
        win=self.new_window("📁 Vanya Explorer",900,560)
        # Explorer занимает всё внутреннее окно, поэтому старый заголовок base не нужен.
        for child in win.content.winfo_children():
            child.destroy()
        root=win.content
        root.configure(bg="#f7f7f7")

        # ---------- state ----------
        home=Path.home()
        state={"path":None, "history":[None], "pos":0, "selected":None, "view":"large"}
        known_special={
            "Рабочий стол": home/"Desktop",
            "Загрузки": home/"Downloads",
            "Документы": home/"Documents",
            "Изображения": home/"Pictures",
            "Музыка": home/"Music",
            "Видео": home/"Movies",
            "Vanya OS": APP_DIR,
        }

        # ---------- helpers ----------
        def safe_entries(path):
            try:
                return sorted(list(path.iterdir()), key=lambda p:(not p.is_dir(), p.name.lower()))
            except (OSError, PermissionError):
                return []

        def folder_icon(p):
            if p.name in known_special: return "📁"
            return "📁"

        def file_icon(p):
            ext=p.suffix.lower()
            if ext in {".png",".jpg",".jpeg",".gif",".webp",".bmp"}: return "🖼️"
            if ext in {".mp3",".wav",".m4a",".flac"}: return "🎵"
            if ext in {".mp4",".mov",".mkv",".avi",".webm"}: return "🎬"
            if ext in {".zip",".rar",".7z",".tar",".gz"}: return "🗜️"
            if ext in {".py",".js",".html",".css",".json"}: return "💻"
            if ext in {".txt",".md",".rtf"}: return "📄"
            if ext in {".pdf"}: return "📕"
            return "📄"

        def human_size(n):
            if n < 1024: return f"{n} Б"
            if n < 1024**2: return f"{n/1024:.1f} КБ"
            if n < 1024**3: return f"{n/1024**2:.1f} МБ"
            return f"{n/1024**3:.1f} ГБ"

        def open_path(path):
            """Открыть файл/папку системным приложением на текущей ОС."""
            try:
                path = Path(path).expanduser().resolve()
                if not path.exists():
                    raise FileNotFoundError(path)
                if sys.platform.startswith("win"):
                    os.startfile(str(path))
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", str(path)])
                else:
                    subprocess.Popen(["xdg-open", str(path)])
            except Exception as e:
                messagebox.showerror("Vanya Explorer", f"Не удалось открыть:\n{e}", parent=self)

        def set_path(path, add_history=True):
            if path is None:
                state["path"] = None
            else:
                path=Path(path).expanduser()
                if not path.exists() or not path.is_dir(): return
                state["path"]=path
            if add_history:
                state["history"]=state["history"][:state["pos"]+1]+[path]
                state["pos"]+=1
            state["selected"]=None
            address_var.set("This PC" if path is None else str(path))
            render()

        def go_back():
            if state["pos"]>0:
                state["pos"]-=1; state["path"]=state["history"][state["pos"]]; address_var.set(str(state["path"])); render()

        def go_forward():
            if state["pos"]+1<len(state["history"]):
                state["pos"]+=1; state["path"]=state["history"][state["pos"]]; address_var.set(str(state["path"])); render()

        def go_up():
            if state["path"] is None:
                return
            parent=state["path"].parent
            if parent!=state["path"]: set_path(parent)
            else: set_path(None)

        def select(path, card):
            state["selected"]=path
            for c in cards.values():
                try: c.configure(bg="#ffffff")
                except Exception: pass
            try: card.configure(bg="#dcecff")
            except Exception: pass
            details_var.set(f"{path.name}   •   {'Папка' if path.is_dir() else human_size(path.stat().st_size)}")

        def activate(path):
            if path.is_dir(): set_path(path)
            else: open_path(path)

        def context_menu(path, x, y):
            # Контекстное меню Vanya Explorer по правой кнопке мыши.
            m=tk.Menu(root, tearoff=0, bg="#ffffff", fg="#222", activebackground="#dcecff", activeforeground="#111",
                      relief="solid", bd=1, font=("Arial", 10))
            m.add_command(label="📂 Открыть", command=lambda: activate(path))
            m.add_separator()
            m.add_command(label="✏️ Переименовать", command=lambda: rename_item(path))
            m.add_command(label="📋 Копировать", command=lambda: copy_item(path))
            m.add_command(label="📍 Показать в проводнике", command=lambda: show_in_finder(path))
            m.add_separator()
            m.add_command(label="🗑️ Переместить в корзину", command=lambda: trash_item(path))
            try:
                m.tk_popup(x, y)
            finally:
                m.grab_release()

        def rename_item(path):
            name=simpledialog.askstring("Переименовать", "Новое имя:", initialvalue=path.name, parent=self)
            if not name: return
            name="".join(ch for ch in name if ch not in '/\\:')
            if not name or name == path.name: return
            try:
                target=path.parent/name
                if target.exists():
                    messagebox.showwarning("Vanya Explorer", "Такой файл или папка уже существует.", parent=self); return
                path.rename(target); render(search_var.get().strip().lower())
            except Exception as e:
                messagebox.showerror("Vanya Explorer", f"Не удалось переименовать:\n{e}", parent=self)

        def copy_item(path):
            try:
                from tkinter import filedialog
                dest=filedialog.askdirectory(title="Выберите папку для копии", parent=self)
                if not dest: return
                dest=Path(dest) / path.name
                if dest.exists():
                    messagebox.showwarning("Vanya Explorer", "В выбранной папке уже есть такой объект.", parent=self); return
                if path.is_dir(): shutil.copytree(path, dest)
                else: shutil.copy2(path, dest)
            except Exception as e:
                messagebox.showerror("Vanya Explorer", f"Не удалось скопировать:\n{e}", parent=self)

        def show_in_finder(path):
            try:
                path = Path(path).expanduser().resolve()
                if sys.platform.startswith("win"):
                    subprocess.Popen(["explorer.exe", "/select,", str(path)])
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", "-R", str(path)])
                else:
                    subprocess.Popen(["xdg-open", str(path.parent if path.is_file() else path)])
            except Exception: pass

        def trash_item(path):
            try:
                trash=APP_DIR / "vanya_trash"
                trash.mkdir(exist_ok=True)
                target=trash/path.name
                if target.exists():
                    target=trash/(path.stem + "_copy" + path.suffix)
                shutil.move(str(path), str(target))
                render(search_var.get().strip().lower())
            except Exception as e:
                messagebox.showerror("Vanya Explorer", f"Не удалось переместить в корзину:\n{e}", parent=self)

        def bind_item(widget, path, card=None):
            widget.bind("<Button-3>", lambda e, p=path: context_menu(p, e.x_root, e.y_root))

        def create_folder():
            base=state["path"]
            if base is None:
                messagebox.showinfo("Vanya Explorer", "Сначала откройте папку, в которой нужно создать новую папку.", parent=self)
                return
            name=simpledialog.askstring("Новая папка","Имя папки:",parent=self)
            if not name: return
            name="".join(ch for ch in name if ch not in '/\\:')
            if not name: return
            try:
                (base/name).mkdir()
                render()
            except Exception as e:
                messagebox.showerror("Vanya Explorer",f"Не удалось создать папку:\n{e}",parent=self)

        def open_selected():
            if state["selected"]: activate(state["selected"])

        def search_now(*_):
            render(search_var.get().strip().lower())

        def clear_search():
            search_var.set(""); render()

        def toggle_view():
            state["view"]="list" if state["view"]=="large" else "large"
            render(search_var.get().strip().lower())

        # ---------- top menu ----------
        menu=tk.Frame(root,bg="#ffffff",height=34); menu.pack(fill="x"); menu.pack_propagate(False)
        for label in ("File","Computer","View"):
            tk.Label(menu,text=label,bg="#ffffff",fg="#222",font=("Arial",10),padx=12).pack(side="left",fill="y",pady=7)
        tk.Frame(menu,bg="#e6e6e6",width=1).pack(side="left",fill="y",pady=7)
        tk.Label(menu,text="📁 Vanya Explorer",bg="#ffffff",fg="#777",font=("Arial",10,"bold"),padx=12).pack(side="left")

        # ---------- navigation ----------
        nav=tk.Frame(root,bg="#ffffff",height=46,highlightbackground="#dedede",highlightthickness=1); nav.pack(fill="x"); nav.pack_propagate(False)
        def nav_button(text,cmd,w=34):
            b=tk.Label(nav,text=text,bg="#ffffff",fg="#555",font=("Arial",14),width=w,cursor="hand2")
            b.pack(side="left",fill="y",padx=1)
            b.bind("<Button-1>",lambda e:cmd())
            b.bind("<Enter>",lambda e:b.configure(bg="#eef5ff")); b.bind("<Leave>",lambda e:b.configure(bg="#ffffff"))
            return b
        nav_button("‹",go_back,3); nav_button("›",go_forward,3); nav_button("↑",go_up,3)
        address_var=tk.StringVar(value="This PC")
        address=tk.Entry(nav,textvariable=address_var,bg="#ffffff",fg="#333",font=("Arial",11),relief="solid",bd=1,insertbackground="#222")
        address.pack(side="left",fill="x",expand=True,padx=8,pady=8)
        address.bind("<Return>",lambda e:set_path(address_var.get()))
        search_var=tk.StringVar()
        search=tk.Entry(nav,textvariable=search_var,bg="#ffffff",fg="#333",font=("Arial",10),relief="solid",bd=1,insertbackground="#222",width=23)
        search.pack(side="right",padx=(0,8),pady=8)
        search.insert(0,"")
        search.bind("<Return>",search_now)
        search.bind("<KeyRelease>",lambda e: render(search_var.get().strip().lower()))
        tk.Label(nav,text="🔎",bg="#ffffff",fg="#777",font=("Arial",11)).place(relx=0.98,rely=.5,anchor="e",x=-15)

        # ---------- toolbar ----------
        tools=tk.Frame(root,bg="#f3f3f3",height=38); tools.pack(fill="x"); tools.pack_propagate(False)
        def tool(text,cmd):
            b=tk.Label(tools,text=text,bg="#f3f3f3",fg="#333",font=("Arial",10),padx=10,cursor="hand2")
            b.pack(side="left",pady=5); b.bind("<Button-1>",lambda e:cmd()); b.bind("<Enter>",lambda e:b.configure(bg="#e2ecfa")); b.bind("<Leave>",lambda e:b.configure(bg="#f3f3f3"))
        tool("📁 New folder",create_folder); tool("↻ Refresh",lambda:render(search_var.get().strip().lower())); tool("▦ View",toggle_view); tool("↗ Open",open_selected)
        details_var=tk.StringVar(value="Select an item to see details")
        tk.Label(tools,textvariable=details_var,bg="#f3f3f3",fg="#777",font=("Arial",9)).pack(side="right",padx=12)

        # ---------- body ----------
        body=tk.Frame(root,bg="#ffffff"); body.pack(fill="both",expand=True)
        side=tk.Frame(body,bg="#f7f7f7",width=190,highlightbackground="#dddddd",highlightthickness=1); side.pack(side="left",fill="y"); side.pack_propagate(False)
        main=tk.Frame(body,bg="#ffffff"); main.pack(side="right",fill="both",expand=True)

        tk.Label(side,text="Quick access",bg="#f7f7f7",fg="#333",font=("Arial",10,"bold"),anchor="w").pack(fill="x",padx=14,pady=(14,7))
        side_items=[("⭐","Quick access",None),("🖥️","Desktop",home/"Desktop"),("⬇️","Downloads",home/"Downloads"),("📄","Documents",home/"Documents"),("🖼️","Pictures",home/"Pictures"),("🎵","Music",home/"Music"),("🎬","Videos",home/"Movies"),("🧩","Vanya OS",APP_DIR)]
        for ico,label,path in side_items:
            if path is not None and not path.exists(): continue
            row=tk.Frame(side,bg="#f7f7f7",cursor="hand2",height=30); row.pack(fill="x",padx=7,pady=1); row.pack_propagate(False)
            tk.Label(row,text=ico,bg="#f7f7f7",font=("Arial",12),width=3).pack(side="left")
            lab=tk.Label(row,text=label,bg="#f7f7f7",fg="#333",font=("Arial",10),anchor="w"); lab.pack(side="left",fill="x",expand=True)
            for wdg in (row,lab):
                wdg.bind("<Button-1>",lambda e,p=path:set_path(p)); wdg.bind("<Enter>",lambda e,r=row:r.configure(bg="#e7effa")); wdg.bind("<Leave>",lambda e,r=row:r.configure(bg="#f7f7f7"))
        tk.Frame(side,bg="#dedede",height=1).pack(fill="x",padx=10,pady=12)
        is_windows = sys.platform.startswith("win")
        is_macos = sys.platform == "darwin"
        computer_title = "This PC" if is_windows else ("This Mac" if is_macos else "Computer")
        drive_name = "Windows" if is_windows else ("Macintosh HD" if is_macos else "Local disk")
        drive_anchor = Path(home.anchor if is_windows else "/")
        tk.Label(side,text=computer_title,bg="#f7f7f7",fg="#555",font=("Arial",10,"bold"),anchor="w").pack(fill="x",padx=14,pady=5)
        diskrow=tk.Frame(side,bg="#f7f7f7",height=48,cursor="hand2"); diskrow.pack(fill="x",padx=8,pady=3); diskrow.pack_propagate(False)
        disk_icon=tk.Label(diskrow,text="💻",bg="#f7f7f7",font=("Arial",19))
        disk_icon.pack(side="left",padx=5)
        disk_label=tk.Label(diskrow,text=f"{drive_name}\nLocal files",bg="#f7f7f7",fg="#444",font=("Arial",9),anchor="w",justify="left")
        disk_label.pack(side="left")
        # Важно: дочерние Label перехватывают клики Frame, поэтому обработчик
        # ставим и на них. Один клик открывает диск, двойной тоже.
        def open_mac_disk(_=None):
            set_path(drive_anchor)
        for widget in (diskrow,disk_icon,disk_label):
            widget.bind("<Button-1>",open_mac_disk)
            widget.bind("<Double-Button-1>",open_mac_disk)
            widget.bind("<Enter>",lambda e,r=diskrow:r.configure(bg="#e7effa"))
            widget.bind("<Leave>",lambda e,r=diskrow:r.configure(bg="#f7f7f7"))

        # main header
        head=tk.Frame(main,bg="#ffffff",height=44); head.pack(fill="x"); head.pack_propagate(False)
        section_var=tk.StringVar(value="Folders")
        tk.Label(head,textvariable=section_var,bg="#ffffff",fg="#333",font=("Arial",13,"bold"),anchor="w").pack(side="left",padx=16,pady=12)
        count_var=tk.StringVar()
        tk.Label(head,textvariable=count_var,bg="#ffffff",fg="#888",font=("Arial",9)).pack(side="right",padx=14)

        canvas=tk.Canvas(main,bg="#ffffff",highlightthickness=0)
        scroll=tk.Scrollbar(main,orient="vertical",command=canvas.yview)
        canvas.pack(side="left",fill="both",expand=True); scroll.pack(side="right",fill="y")
        canvas.configure(yscrollcommand=scroll.set)
        inner=tk.Frame(canvas,bg="#ffffff")
        canvas_window=canvas.create_window((0,0),window=inner,anchor="nw")
        inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",lambda e:canvas.itemconfigure(canvas_window,width=max(1,e.width)))
        self._enable_trackpad_scroll(canvas,inner)
        cards={}

        def render_this_pc():
            # Windows-Explorer-like home page: common folders + local drive.
            folders=[
                ("Desktop", home/"Desktop", "📁"),
                ("Documents", home/"Documents", "📄"),
                ("Downloads", home/"Downloads", "⬇️"),
                ("Music", home/"Music", "🎵"),
                ("Pictures", home/"Pictures", "🖼️"),
                ("Videos", home/"Movies", "🎬"),
            ]
            tk.Label(inner,text="Folders (6)",bg="#ffffff",fg="#555",font=("Arial",10,"bold"),anchor="w").pack(fill="x",padx=18,pady=(8,6))
            fg=tk.Frame(inner,bg="#ffffff"); fg.pack(fill="x",padx=12)
            for i,(name,path,ico) in enumerate(folders):
                card=tk.Frame(fg,bg="#ffffff",width=180,height=100,highlightthickness=1,highlightbackground="#eeeeee",cursor="hand2")
                card.grid(row=i//3,column=i%3,padx=7,pady=6,sticky="nsew"); card.grid_propagate(False)
                tk.Label(card,text=ico,bg="#ffffff",font=("Arial",30)).pack(side="left",padx=12)
                tk.Label(card,text=name,bg="#ffffff",fg="#333",font=("Arial",11),anchor="w").pack(side="left",fill="x",expand=True)
                cards[path]=card
                card.bind("<Button-1>",lambda e,p=path,c=card:select(p,c)); card.bind("<Double-Button-1>",lambda e,p=path:activate(p))
                bind_item(card, path, card)
                for child in card.winfo_children():
                    child.bind("<Button-1>",lambda e,p=path,c=card:select(p,c)); child.bind("<Double-Button-1>",lambda e,p=path:activate(p)); bind_item(child, path, card)
            for c in range(3): fg.grid_columnconfigure(c,weight=1)

            tk.Label(inner,text="Devices and drives (1)",bg="#ffffff",fg="#555",font=("Arial",10,"bold"),anchor="w").pack(fill="x",padx=18,pady=(20,6))
            drive=drive_anchor
            try:
                total,used,free=shutil.disk_usage(drive)
                free_txt=human_size(free); total_txt=human_size(total)
                pct=max(0,min(100,int(used/total*100))) if total else 0
            except Exception:
                free_txt=total_txt="—"; pct=0
            d=tk.Frame(inner,bg="#ffffff",highlightthickness=1,highlightbackground="#eeeeee",cursor="hand2",height=92)
            d.pack(fill="x",padx=19,pady=6); d.pack_propagate(False)
            tk.Label(d,text="💻",bg="#ffffff",font=("Arial",34)).pack(side="left",padx=14)
            info=tk.Frame(d,bg="#ffffff"); info.pack(side="left",fill="both",expand=True,pady=12)
            drive_title = f"Windows ({home.anchor.rstrip(chr(92))})" if is_windows else ("Macintosh HD" if is_macos else "Local disk")
            tk.Label(info,text=drive_title,bg="#ffffff",fg="#222",font=("Arial",11,"bold"),anchor="w").pack(fill="x")
            tk.Label(info,text=f"{free_txt} free of {total_txt}",bg="#ffffff",fg="#666",font=("Arial",9),anchor="w").pack(fill="x",pady=(2,4))
            bar=tk.Frame(info,bg="#e4e4e4",height=12); bar.pack(fill="x",padx=(0,30)); bar.pack_propagate(False)
            tk.Frame(bar,bg="#55a9df",width=max(4,int(260*pct/100)),height=12).pack(side="left")
            def open_drive(_=None):
                set_path(drive_anchor)
            d.bind("<Button-1>",open_drive)
            d.bind("<Double-Button-1>",open_drive)
            for child in d.winfo_children():
                child.bind("<Button-1>",open_drive)
                child.bind("<Double-Button-1>",open_drive)
                child.bind("<Button-3>",lambda e: context_menu(Path("/"), e.x_root, e.y_root))

        def render(query=""):
            for w in inner.winfo_children(): w.destroy()
            cards.clear(); state["selected"]=None; details_var.set("Select an item to see details")
            path=state["path"]
            if path is None:
                address_var.set("This PC")
                section_var.set("This PC")
                count_var.set("6 folders  •  1 drive")
                render_this_pc()
                return
            address_var.set(str(path))
            entries=safe_entries(path)
            if query: entries=[p for p in entries if query in p.name.lower()]
            folders=[p for p in entries if p.is_dir()]; files=[p for p in entries if not p.is_dir()]
            section_var.set(path.name if path.name else str(path))
            count_var.set(f"{len(entries)} items")

            if not entries:
                empty=tk.Frame(inner,bg="#ffffff"); empty.pack(fill="both",expand=True,pady=80)
                tk.Label(empty,text="📂",bg="#ffffff",font=("Arial",42)).pack()
                tk.Label(empty,text="This folder is empty",bg="#ffffff",fg="#777",font=("Arial",12)).pack(pady=8)
                return

            if state["view"]=="large":
                if folders:
                    tk.Label(inner,text="Folders",bg="#ffffff",fg="#555",font=("Arial",10,"bold"),anchor="w").pack(fill="x",padx=18,pady=(5,6))
                    fg=tk.Frame(inner,bg="#ffffff"); fg.pack(fill="x",padx=12)
                    for i,p in enumerate(folders):
                        card=tk.Frame(fg,bg="#ffffff",width=155,height=112,highlightthickness=1,highlightbackground="#eeeeee",cursor="hand2"); card.grid(row=i//4,column=i%4,padx=5,pady=5,sticky="nsew"); card.grid_propagate(False)
                        tk.Label(card,text=folder_icon(p),bg="#ffffff",font=("Arial",39)).pack(pady=(10,0))
                        tk.Label(card,text=p.name,bg="#ffffff",fg="#333",font=("Arial",10),wraplength=135).pack(pady=4)
                        cards[p]=card
                        card.bind("<Button-1>",lambda e,p=p,c=card:select(p,c)); card.bind("<Double-Button-1>",lambda e,p=p:activate(p))
                        bind_item(card, p, card)
                        for child in card.winfo_children(): child.bind("<Button-1>",lambda e,p=p,c=card:select(p,c)); child.bind("<Double-Button-1>",lambda e,p=p:activate(p)); bind_item(child, p, card)
                    for c in range(4): fg.grid_columnconfigure(c,weight=1)
                if files:
                    tk.Label(inner,text="Files",bg="#ffffff",fg="#555",font=("Arial",10,"bold"),anchor="w").pack(fill="x",padx=18,pady=(16,6))
                    fg=tk.Frame(inner,bg="#ffffff"); fg.pack(fill="x",padx=12,pady=(0,12))
                    for i,p in enumerate(files):
                        card=tk.Frame(fg,bg="#ffffff",width=155,height=112,highlightthickness=1,highlightbackground="#eeeeee",cursor="hand2"); card.grid(row=i//4,column=i%4,padx=5,pady=5,sticky="nsew"); card.grid_propagate(False)
                        tk.Label(card,text=file_icon(p),bg="#ffffff",font=("Arial",34)).pack(pady=(10,0))
                        tk.Label(card,text=p.name,bg="#ffffff",fg="#333",font=("Arial",9),wraplength=135).pack(pady=4)
                        cards[p]=card
                        card.bind("<Button-1>",lambda e,p=p,c=card:select(p,c)); card.bind("<Double-Button-1>",lambda e,p=p:activate(p))
                        bind_item(card, p, card)
                        for child in card.winfo_children(): child.bind("<Button-1>",lambda e,p=p,c=card:select(p,c)); child.bind("<Double-Button-1>",lambda e,p=p:activate(p)); bind_item(child, p, card)
                    for c in range(4): fg.grid_columnconfigure(c,weight=1)
            else:
                # Compact Details view.
                headers=tk.Frame(inner,bg="#f1f1f1"); headers.pack(fill="x",padx=10,pady=(4,0))
                for txt,w in (("Name",42),("Type",16),("Size",12)):
                    tk.Label(headers,text=txt,bg="#f1f1f1",fg="#444",font=("Arial",9,"bold"),width=w,anchor="w").pack(side="left",padx=5,pady=5)
                for p in entries:
                    row=tk.Frame(inner,bg="#ffffff",height=34,cursor="hand2"); row.pack(fill="x",padx=10); row.pack_propagate(False)
                    typ="Folder" if p.is_dir() else (p.suffix.upper().lstrip(".") or "File")
                    size="—" if p.is_dir() else human_size(p.stat().st_size)
                    tk.Label(row,text=(folder_icon(p) if p.is_dir() else file_icon(p))+"  "+p.name,bg="#ffffff",fg="#333",font=("Arial",10),width=42,anchor="w").pack(side="left",padx=5)
                    tk.Label(row,text=typ,bg="#ffffff",fg="#666",font=("Arial",9),width=16,anchor="w").pack(side="left",padx=5)
                    tk.Label(row,text=size,bg="#ffffff",fg="#666",font=("Arial",9),width=12,anchor="w").pack(side="left",padx=5)
                    cards[p]=row
                    row.bind("<Button-1>",lambda e,p=p,c=row:select(p,c)); row.bind("<Double-Button-1>",lambda e,p=p:activate(p))
                    bind_item(row, p, row)

        render()

    def notes(self):
        win=self.new_window("📝 Vanya Notes",700,470); self.base(win,"📝 Vanya Notes")
        toolbar=tk.Frame(win.content,bg=WINDOW_BG); toolbar.pack(side="top",fill="x",pady=(0,8))
        frame=tk.Frame(win.content,bg=WINDOW_BG); frame.pack(fill="both",expand=True)
        files=tk.Listbox(frame,bg="#20242b",fg=TEXT,selectbackground=ACCENT,selectforeground="#07151a",bd=0,width=24); files.pack(side="left",fill="y")
        text=tk.Text(frame,bg="#111722",fg=TEXT,insertbackground=TEXT,bd=0,font=("Arial",12)); text.pack(side="right",fill="both",expand=True,padx=(10,0))
        status=tk.Label(toolbar,text="Готово",bg=WINDOW_BG,fg="#697383",font=("Arial",9))
        def refresh():
            files.delete(0,"end")
            for p in sorted(NOTES_DIR.glob("*.txt")):
                files.insert("end",p.name)
        def load(_=None):
            if files.curselection():
                p=NOTES_DIR/files.get(files.curselection()[0])
                try:
                    text.delete("1.0","end")
                    text.insert("1.0",p.read_text(encoding="utf8",errors="ignore"))
                    status.config(text=f"Открыто: {p.name}")
                except OSError as e:
                    status.config(text=f"Ошибка: {e}")
        def new_note():
            text.delete("1.0","end")
            files.selection_clear(0,"end")
            status.config(text="Новая заметка — нажми «💾 Сохранить»")
        def save():
            if files.curselection():
                p=NOTES_DIR/files.get(files.curselection()[0])
            else:
                n=simpledialog.askstring("Vanya Notes","Имя заметки:",parent=self)
                if not n:return
                safe="".join(ch for ch in n.strip() if ch not in '/\\\\:*?"<>|')
                if not safe:return
                p=NOTES_DIR/(safe if safe.endswith(".txt") else safe+".txt")
            try:
                p.write_text(text.get("1.0","end-1c"),encoding="utf8")
                refresh()
                status.config(text=f"✓ Сохранено: {p.name}")
            except OSError as e:
                status.config(text=f"Ошибка сохранения: {e}")
        self.make_button(toolbar,"➕ Новая",new_note,12).pack(side="left",padx=(0,6))
        self.make_button(toolbar,"💾 Сохранить",save,14).pack(side="left",padx=6)
        status.pack(side="left",padx=10)
        files.bind("<<ListboxSelect>>",load); refresh()

    def games(self):
        win=self.new_window("🎮 Vanya Games",560,520); self.base(win,"🎮 Vanya Games")
        games=[("🐍 Snake","mini_snake"),("🧠 Memory","memory_game"),("⚡ Reaction","reaction_game"),("🎲 Кубик","dice_roll"),("🏓 Pong","vanya_pong"),("🧩 Tetris","vanya_tetris"),("🐔 Chickingan","chickingan_game"),("🧠 Memory 2","vanya_memory2"),("⛏️ Minecraft","minecraft"),("🔠 Большие буковки","big_letters")]
        for name,fn in games:
            self.make_button(win.content,name,lambda n=fn:self.run_game(n),22).pack(pady=4)
        tk.Label(win.content,text="⛏️ Minecraft запускает HTML из папки eaglercraft",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",10)).pack(pady=8)
    def run_game(self,name):
        if name=="minecraft":
            self.minecraft()
            return
        if name=="big_letters":
            self.big_letters_game()
            return
        self.run_legacy(name)
    def minecraft(self):
        """Launch Eaglercraft as a standalone game window, never as a browser tab.
        The game itself is HTML/JavaScript/WebGL, so Tkinter cannot render it inside a
        Canvas window. On macOS we prefer Chrome/Chromium app mode (no tabs/address bar),
        with a Vanya OS internal launcher window as the control surface.
        """
        htmls=sorted((APP_DIR/"eaglercraft").glob("*.html"))+sorted((APP_DIR/"eaglercraft").glob("*.htm"))
        if not htmls:
            win=self.new_window("⛏️ Minecraft",560,280); self.base(win,"⛏️ Minecraft")
            tk.Label(win.content,text="HTML-файл Minecraft пока не найден.",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",14,"bold")).pack(pady=15)
            tk.Label(win.content,text="Положи веб-версию Minecraft в:\n"+str(APP_DIR/"eaglercraft"),bg=WINDOW_BG,fg=WINDOW_TEXT,wraplength=500).pack(pady=5)
            self.make_button(win.content,"📂 Открыть папку eaglercraft",lambda:subprocess.run(["open",str(APP_DIR/"eaglercraft")]),18).pack(pady=10)
            return

        html=htmls[0].resolve()
        launcher=self.new_window("⛏️ Minecraft • Eaglercraft 1.12.2",700,330)
        self.base(launcher,"⛏️ Minecraft • Eaglercraft")
        tk.Label(launcher.content,text="Eaglercraft запускается отдельным игровым окном — без вкладки браузера.",
                 bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold"),wraplength=620).pack(pady=(20,8))
        tk.Label(launcher.content,text=html.name,bg=WINDOW_BG,fg="#333333",font=("Arial",11)).pack(pady=4)
        status=tk.Label(launcher.content,text="Запуск…",bg=WINDOW_BG,fg="#333333",font=("Arial",11))
        status.pack(pady=8)

        def launch():
            # macOS: Chrome/Chromium --app opens a standalone window with no tabs.
            uri=html.as_uri()
            candidates=["Google Chrome","Chromium","Google Chrome Canary"]
            for app in candidates:
                try:
                    r=subprocess.run(["open","-na",app,"--args",f"--app={uri}"])
                    if r.returncode==0:
                        status.config(text=f"✅ Запущено через {app} — это отдельное окно")
                        return
                except Exception:
                    pass
            # Fallback: use the system default browser only if no Chromium app exists.
            # This may be a normal window depending on the browser.
            try:
                subprocess.run(["open",str(html)],check=True)
                status.config(text="⚠️ Открыто системным браузером; для режима без вкладок нужен Chrome/Chromium")
            except Exception as e:
                status.config(text=f"Ошибка запуска: {e}")

        self.make_button(launcher.content,"▶ Запустить Minecraft",launch,24).pack(pady=8)
        self.make_button(launcher.content,"📂 Открыть папку eaglercraft",lambda:subprocess.run(["open",str(APP_DIR/"eaglercraft")]),24).pack(pady=5)
        launcher.after(100,launch)
    def legacy_game(self): pass
    def mods(self):
        # Open the real text-mod manager; mods affect the classic engine and are discovered from /mods.
        self.run_legacy("mods_manager")
    def calculator(self): self.run_legacy("vanya_calculator")
    def settings(self): self.run_legacy("vanya_settings")
    def system_info(self): self.run_legacy("system_info_full")
    def about(self): self.run_legacy("about_program")
    def easter(self): self.run_legacy("easter_egg")
    def terminal(self):
        win=self.new_window("💻 Vanya Terminal",760,480); self.base(win,"💻 Vanya Terminal")
        out=tk.Text(win.content,bg="#0b0f15",fg="#d9e7ff",insertbackground="white",font=("Menlo",12),bd=0); out.pack(fill="both",expand=True,pady=5)
        ent=tk.Entry(win.content,bg="#151c27",fg=TEXT,insertbackground=TEXT,bd=0,font=("Menlo",12)); ent.pack(fill="x",pady=6)
        state={"cwd":APP_DIR}
        def run(_=None):
            cmd=ent.get().strip(); ent.delete(0,"end")
            if not cmd:return
            if cmd in ("clear","cls"):out.delete("1.0","end");return
            if cmd=="pwd": out.insert("end",str(state["cwd"])+"\n");return
            if cmd=="ls": out.insert("end","  ".join(p.name for p in state["cwd"].iterdir())+"\n");return
            try:
                r=subprocess.run(cmd,shell=True,cwd=str(state["cwd"]),capture_output=True,text=True)
                out.insert("end",re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", r.stdout+r.stderr)+"\n")
            except Exception as e:out.insert("end",f"Ошибка: {e}\n")
            out.see("end")
        ent.bind("<Return>",run); out.insert("end","Vanya Terminal 19.0\n$ ")
    def start_menu(self):
        win=self.new_window("🚀 Пуск",390,500); self.base(win,"🚀 Vanya OS")
        for t,c in [("📁 Explorer",self.explorer),("📝 Notes",self.notes),("🎮 Games",self.games),("🔎 Search",self.vanya_search),("📊 Task Manager",self.vanya_task_manager),("🎨 Theme Studio",self.vanya_theme_studio),("🧩 App Builder",self.vanya_app_builder),("🕹️ Arcade",self.vanya_arcade),("🛠️ Developer Mode",self.vanya_developer_mode),("🧠 Assistant",self.vanya_assistant),("🧰 Все функции",self.all_functions),("ℹ️ About",self.about)]: self.make_button(win.content,t,lambda f=c:f(),24).pack(pady=4)

    def server_hosting(self):

        """Vanya Server Hosting — локальный менеджер Minecraft Java/Bedrock серверов.
        Создаёт серверы внутри Vanya OS, сохраняет профили и умеет запускать готовые ядра,
        а папку сервера можно открыть в Vanya Explorer/Finder.
        """
        win,inner=self._scrollable_window("🖥️ Vanya Server Hosting",980,650)
        self.base(win,"🖥️ Vanya Server Hosting")
        tk.Label(inner,text="Создавай и храни игровые серверы прямо в Vanya OS.",bg=WINDOW_BG,fg="#444",font=("Arial",12)).pack(anchor="w",padx=12,pady=(0,10))

        toolbar=tk.Frame(inner,bg=WINDOW_BG); toolbar.pack(fill="x",padx=12,pady=6)
        self.make_button(toolbar,"➕ Новый сервер",lambda:self._server_new(win),18).pack(side="left",padx=(0,7))
        self.make_button(toolbar,"📥 Импортировать",lambda:self._server_import(win),18).pack(side="left",padx=7)
        self.make_button(toolbar,"📂 Открыть в Explorer",lambda:self._server_open_selected(win),20).pack(side="left",padx=7)
        self.make_button(toolbar,"🔄 Обновить",lambda:self._server_refresh(win),15).pack(side="left",padx=7)

        body=tk.Frame(inner,bg=WINDOW_BG); body.pack(fill="both",expand=True,padx=12,pady=6)
        left=tk.Frame(body,bg="#202733",width=250); left.pack(side="left",fill="y"); left.pack_propagate(False)
        tk.Label(left,text="Мои серверы",bg="#202733",fg=TEXT,font=("Arial",14,"bold")).pack(anchor="w",padx=12,pady=12)
        lb=tk.Listbox(left,bg="#151a22",fg=TEXT,selectbackground="#355b84",relief="flat",highlightthickness=0,font=("Arial",11))
        lb.pack(fill="both",expand=True,padx=10,pady=(0,10))

        right=tk.Frame(body,bg=WINDOW_BG); right.pack(side="left",fill="both",expand=True,padx=(10,0))
        title_var=tk.StringVar(value="Выбери сервер")
        tk.Label(right,textvariable=title_var,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",18,"bold")).pack(anchor="w",padx=10,pady=(8,2))
        detail=tk.Text(right,bg="#11161f",fg="#e1e9f7",font=("Menlo",10),height=9,bd=0)
        detail.pack(fill="x",padx=10,pady=8)
        tk.Label(right,text="Консоль",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")).pack(anchor="w",padx=10)
        console=tk.Text(right,bg="#0b0f15",fg="#bfe9c9",font=("Menlo",10),bd=0)
        console.pack(fill="both",expand=True,padx=10,pady=(4,4))

        cmd_row=tk.Frame(right,bg=WINDOW_BG); cmd_row.pack(fill="x",padx=10,pady=(0,6))
        cmd_var=tk.StringVar()
        cmd_entry=tk.Entry(cmd_row,textvariable=cmd_var,bg="#0b0f15",fg="#bfe9c9",
                            insertbackground="#bfe9c9",font=("Menlo",11),relief="flat")
        cmd_entry.pack(side="left",fill="x",expand=True,ipady=4)
        send_btn=self.make_button(cmd_row,"➤ Отправить",lambda:self._server_send_command(state,cmd_var),16)
        send_btn.pack(side="left",padx=(6,0))
        cmd_entry.bind("<Return>",lambda e:self._server_send_command(state,cmd_var))

        actions=tk.Frame(right,bg=WINDOW_BG); actions.pack(fill="x",padx=10,pady=(0,8))
        start_btn=self.make_button(actions,"▶ Запустить",lambda:self._server_start_selected(state),16)
        stop_btn=self.make_button(actions,"■ Остановить",lambda:self._server_stop_selected(state),16)
        core_btn=self.make_button(actions,"🌐 Открыть ядро",lambda:self._server_open_core_page(state),18)
        download_btn=self.make_button(actions,"⬇️ Скачать server.jar",lambda:self._server_download_core(state),20)
        start_btn.pack(side="left",padx=(0,6)); stop_btn.pack(side="left",padx=6); core_btn.pack(side="left",padx=6); download_btn.pack(side="left",padx=6)

        state={"selected":None,"listbox":lb,"title":title_var,"detail":detail,"console":console,
               "start":start_btn,"stop":stop_btn,"cmd_entry":cmd_entry}

        def select(_=None):
            sel=lb.curselection()
            if not sel: return
            names=self._server_list()
            if sel[0] >= len(names): return
            state["selected"]=names[sel[0]]
            self._server_show(state)
        lb.bind("<<ListboxSelect>>",select)
        win._server_state=state
        self._server_refresh(win)

    def _server_list(self):
        return sorted([p.name for p in SERVERS_DIR.iterdir() if p.is_dir()], key=str.lower)

    def _server_config(self,name):
        return SERVERS_DIR/name/"server.json"

    def _server_refresh(self,win):
        state=getattr(win,"_server_state",None)
        if not state: return
        lb=state["listbox"]; lb.delete(0,"end")
        names=self._server_list()
        for name in names:
            cfg=self._server_read(name) or {}
            edition=cfg.get("edition","Java")
            core=cfg.get("core","Vanilla")
            ver=cfg.get("version","26.2")
            running=name in self.server_processes and self.server_processes[name].poll() is None
            lb.insert("end",f"{'🟢' if running else '⚪'} {name} • {edition} • {core} {ver}")
        if state.get("selected") not in names:
            state["selected"]=names[0] if names else None
        if state.get("selected"):
            idx=names.index(state["selected"]); lb.selection_set(idx); lb.activate(idx); self._server_show(state)
        else:
            state["title"].set("Нет серверов"); state["detail"].delete("1.0","end"); state["console"].delete("1.0","end")
            state["detail"].insert("end","Нажми «Новый сервер», чтобы создать сервер внутри Vanya OS.")

    def _server_read(self,name):
        try:
            return json.loads(self._server_config(name).read_text(encoding="utf-8"))
        except Exception:
            return None

    def _server_show(self,state):
        name=state.get("selected")
        if not name: return
        cfg=self._server_read(name) or {}
        folder=SERVERS_DIR/name
        state["title"].set(f"🖥️ {name}")
        state["detail"].delete("1.0","end")
        state["detail"].insert("end",f"Имя: {name}\nРедакция: {cfg.get('edition','Java')}\nЯдро: {cfg.get('core','Vanilla')}\nВерсия: {cfg.get('version','26.2')}\nПорт: {cfg.get('port',25565)}\nRAM: {cfg.get('ram','2G')}\nПапка: {folder}\nЛицензия/EULA: {'Принята' if cfg.get('eula') else 'Не принята'}\n")
        running=name in self.server_processes and self.server_processes[name].poll() is None
        if running:
            state["console"].insert("end","🟢 Сервер запущен\n")
        else:
            state["console"].insert("end","⚪ Сервер остановлен\n")

    def _server_new(self,parent):
        dialog=tk.Toplevel(self); dialog.title("Новый Vanya Server"); dialog.geometry("480x520"); dialog.transient(self); dialog.grab_set(); dialog.configure(bg=WINDOW_BG)
        tk.Label(dialog,text="🖥️ Создать сервер",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",19,"bold")).pack(pady=14)
        form=tk.Frame(dialog,bg=WINDOW_BG); form.pack(fill="both",expand=True,padx=20)
        vars={}
        def row(label,var,values=None):
            tk.Label(form,text=label,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",10,"bold")).pack(anchor="w",pady=(8,2))
            if isinstance(values, (list, tuple)):
                lb=tk.Listbox(form,height=min(4,len(values)),bg="#222937",fg="white",selectbackground="#355b84",relief="flat",exportselection=False)
                for v in values: lb.insert("end",v)
                lb.selection_set(0); lb.pack(fill="x")
                vars[var]=lb
            else:
                e=tk.Entry(form,bg="#222937",fg="white",insertbackground="white",relief="flat"); e.insert(0, values if values is not None else ""); e.pack(fill="x"); vars[var]=e
        row("Название","name","")
        row("Редакция","edition",["Java","Bedrock"])
        row("Ядро","core",["Vanilla","Paper","Purpur","Fabric","Forge","Bedrock Dedicated Server"])
        row("Версия","version",["26.2","26.1","1.21.11","1.21.10","1.21.8","1.20.4"])
        row("Порт (например, 25565)","port","25565")
        row("RAM (например, 2G)","ram","2G")
        eula=tk.BooleanVar(value=False)
        tk.Checkbutton(form,text="Я принимаю EULA (если требуется)",variable=eula,bg=WINDOW_BG,fg=WINDOW_TEXT,selectcolor="#222937",activebackground=WINDOW_BG,activeforeground=WINDOW_TEXT).pack(anchor="w",pady=10)
        online=tk.BooleanVar(value=True)
        tk.Checkbutton(form,text="Online mode",variable=online,bg=WINDOW_BG,fg=WINDOW_TEXT,selectcolor="#222937",activebackground=WINDOW_BG,activeforeground=WINDOW_TEXT).pack(anchor="w")
        def val(key):
            w=vars[key]
            if isinstance(w,tk.Listbox):
                sel=w.curselection(); return w.get(sel[0]) if sel else ""
            return w.get().strip()
        def create():
            name=val("name").strip()
            name = re.sub(r"[{\/\\:*?\"<>|]", "_", name)
            if not name: messagebox.showerror("Server Hosting","Введи название сервера",parent=dialog); return
            folder=SERVERS_DIR/name
            if folder.exists(): messagebox.showerror("Server Hosting","Такой сервер уже существует.",parent=dialog); return
            folder.mkdir(parents=True)
            cfg={"name":name,"edition":val("edition"),"core":val("core"),"version":val("version"),"port":int(val("port") or "25565"),"ram":val("ram") or "2G","eula":bool(eula.get()),"online_mode":bool(online.get()),"created_at":datetime.now().isoformat()}
            (folder/"server.json").write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding="utf-8")
            (folder/"README.txt").write_text("Положи сюда ядро сервера. Для Java по умолчанию ожидается server.jar; для Bedrock — bedrock_server.\n",encoding="utf-8")
            self._server_write_start_scripts(folder,cfg)
            messagebox.showinfo("Server Hosting","Сервер создан в Vanya OS! 📦\n\n"+str(folder),parent=dialog)
            dialog.destroy(); self._server_refresh(parent)
        self.make_button(dialog,"✅ Создать сервер",create,22).pack(pady=10)

    def _server_write_start_scripts(self,folder,cfg):
        if cfg.get("edition")=="Java":
            sh='#!/bin/bash\ncd "$(dirname "$0")"\nexec java -Xmx%s -jar server.jar nogui\n' % cfg.get("ram","2G")
            (folder/"start.command").write_text(sh,encoding="utf-8"); (folder/"start.command").chmod(0o755)
            (folder/"start.bat").write_text('@echo off\njava -Xmx%s -jar server.jar nogui\npause\n' % cfg.get("ram","2G"),encoding="utf-8")
        else:
            sh='#!/bin/bash\ncd "$(dirname "$0")"\nexec ./bedrock_server\n'
            (folder/"start_bedrock.command").write_text(sh,encoding="utf-8"); (folder/"start_bedrock.command").chmod(0o755)
            (folder/"start_bedrock.bat").write_text('@echo off\nbedrock_server.exe\npause\n',encoding="utf-8")

    def _server_import(self,parent):
        path=filedialog.askdirectory(parent=self,title="Выбери папку существующего Minecraft-сервера")
        if not path:return
        src=Path(path); name=re.sub(r"[^A-Za-z0-9_-]","_",src.name) or "ImportedServer"; dest=SERVERS_DIR/name
        if dest.exists(): name=name+"_2"; dest=SERVERS_DIR/name
        try:
            shutil.copytree(src,dest)
            cfg={"name":name,"edition":"Java","core":"Vanilla","version":"Unknown","port":25565,"ram":"2G","eula":False,"online_mode":True,"imported":True}
            if (dest/"bedrock_server").exists() or (dest/"bedrock_server.exe").exists(): cfg["edition"]="Bedrock"; cfg["core"]="Bedrock Dedicated Server"
            elif (dest/"server.jar").exists(): cfg["edition"]="Java"
            (dest/"server.json").write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding="utf-8")
            self._server_write_start_scripts(dest,cfg)
            messagebox.showinfo("Server Hosting","Сервер импортирован в Vanya OS! 📥",parent=self); self._server_refresh(parent)
        except Exception as e: messagebox.showerror("Server Hosting",f"Импорт не удался:\n{e}",parent=self)

    def _server_open_selected(self,parent):
        state=getattr(parent,"_server_state",None); name=state.get("selected") if state else None
        if not name: return
        folder=SERVERS_DIR/name
        try: subprocess.run(["open",str(folder)],check=False)
        except Exception as e: messagebox.showerror("Server Hosting",str(e),parent=self)

    def _server_download_core(self,state):
        name=state.get("selected") if state else None
        cfg=self._server_read(name) if name else None
        if not cfg: return
        if cfg.get("edition") != "Java":
            state["console"].insert("end","ℹ️ Автоскачивание server.jar доступно для Java-серверов.\n")
            return
        core=cfg.get("core","Vanilla")
        version=cfg.get("version","26.2")
        folder=SERVERS_DIR/name
        target=folder/"server.jar"
        if target.exists():
            messagebox.showinfo("Server Hosting","server.jar уже существует.\n\n"+str(target),parent=self)
            return
        state["console"].insert("end",f"⬇️ Получаю ядро {core} {version}...\n")
        def worker():
            try:
                if core == "Vanilla":
                    manifest_url="https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
                    with urllib.request.urlopen(manifest_url, timeout=20) as r:
                        manifest=json.load(r)
                    match=next((v for v in manifest.get("versions",[]) if v.get("id")==version),None)
                    if not match: raise RuntimeError(f"Версия Vanilla {version} не найдена")
                    with urllib.request.urlopen(match["url"], timeout=20) as r:
                        meta=json.load(r)
                    url=meta["downloads"]["server"]["url"]
                elif core == "Paper":
                    # ВАЖНО: старый api.papermc.io/v2 отключён PaperMC с 1 июля 2026.
                    # Теперь используется новый Fill API v3.
                    api=f"https://fill.papermc.io/v3/projects/paper/versions/{urllib.parse.quote(version)}/builds"
                    req=urllib.request.Request(api, headers={"User-Agent":"VanyaOS-ServerHosting/1.0"})
                    with urllib.request.urlopen(req, timeout=20) as r:
                        builds=json.load(r)
                    if not builds: raise RuntimeError(f"Для Paper {version} нет доступных builds")
                    stable=[b for b in builds if b.get("channel")=="STABLE"]
                    chosen=stable[0] if stable else builds[0]
                    url=chosen["downloads"]["server:default"]["url"]
                elif core == "Purpur":
                    # Query latest build for selected version from the official Purpur API.
                    api=f"https://api.purpurmc.org/v2/purpur/{urllib.parse.quote(version)}"
                    with urllib.request.urlopen(api, timeout=20) as r:
                        data=json.load(r)
                    build=data.get("builds",{}).get("latest") if isinstance(data.get("builds"),dict) else None
                    if build is None:
                        raise RuntimeError(f"Для Purpur {version} не найден latest build")
                    url=f"https://api.purpurmc.org/v2/purpur/{urllib.parse.quote(version)}/{build}/download"
                elif core == "Fabric":
                    # Fabric даёт готовый server jar через свой Meta API - без
                    # отдельного шага установки, всё в один файл.
                    with urllib.request.urlopen("https://meta.fabricmc.net/v2/versions/loader", timeout=20) as r:
                        loaders=json.load(r)
                    if not loaders: raise RuntimeError("Fabric: пустой список версий загрузчика")
                    loader_version=loaders[0]["version"]
                    with urllib.request.urlopen("https://meta.fabricmc.net/v2/versions/installer", timeout=20) as r:
                        installers=json.load(r)
                    if not installers: raise RuntimeError("Fabric: пустой список установщиков")
                    installer_version=installers[0]["version"]
                    url=(f"https://meta.fabricmc.net/v2/versions/loader/{urllib.parse.quote(version)}"
                         f"/{urllib.parse.quote(loader_version)}/{urllib.parse.quote(installer_version)}/server/jar")
                elif core == "Forge":
                    # У Forge нет единого готового server.jar - нужно скачать
                    # его установщик и запустить его в "тихом" режиме, он сам
                    # соберёт нужные файлы в папке сервера.
                    promo_url="https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"
                    with urllib.request.urlopen(promo_url, timeout=20) as r:
                        promos=json.load(r).get("promos",{})
                    forge_build=promos.get(f"{version}-recommended") or promos.get(f"{version}-latest")
                    if not forge_build:
                        raise RuntimeError(f"Forge: нет сборки для версии Minecraft {version}")
                    full_ver=f"{version}-{forge_build}"
                    installer_url=(f"https://maven.minecraftforge.net/net/minecraftforge/forge/"
                                    f"{full_ver}/forge-{full_ver}-installer.jar")
                    installer_path=folder/"forge-installer.jar"
                    with urllib.request.urlopen(installer_url, timeout=60) as r, open(installer_path,'wb') as f:
                        shutil.copyfileobj(r, f)
                    state["console"].after(0, lambda: state["console"].insert(
                        "end", "⚙️ Установщик Forge скачан, запускаю установку сервера "
                               "(нужна установленная Java)...\n"))
                    result=subprocess.run(
                        ["java","-jar",str(installer_path),"--installServer"],
                        cwd=str(folder), capture_output=True, text=True, timeout=300
                    )
                    if result.returncode != 0:
                        raise RuntimeError("Forge installer завершился с ошибкой:\n"+result.stderr[-500:])
                    installer_path.unlink(missing_ok=True)
                    # Современный Forge запускается через run.sh/run.bat с
                    # файлом аргументов, а не через "java -jar server.jar".
                    # Запоминаем правильную команду запуска в server.json.
                    run_script=folder/("run.bat" if platform.system()=="Windows" else "run.sh")
                    cfg2=self._server_read(name) or {}
                    if run_script.exists():
                        cfg2["launch_mode"]="forge_script"
                        cfg2["launch_script"]=run_script.name
                    else:
                        cfg2["launch_mode"]="forge_manual"
                    self._server_config(name).write_text(json.dumps(cfg2,ensure_ascii=False,indent=2),encoding="utf-8")
                    state["console"].after(0, lambda: state["console"].insert(
                        "end", "✅ Forge установлен! Он запускается по-другому (через "
                               "run.sh/run.bat), кнопка «Запустить» теперь это учитывает.\n"))
                    state["console"].after(0, lambda: self._server_refresh(self._find_server_window(state)))
                    return  # у Forge нет единого server.jar, дальше скачивать нечего
                else:
                    raise RuntimeError("Для этого ядра автоматическая загрузка server.jar пока не реализована")

                tmp=target.with_suffix('.jar.part')
                with urllib.request.urlopen(url, timeout=60) as r, open(tmp,'wb') as f:
                    while True:
                        chunk=r.read(1024*1024)
                        if not chunk: break
                        f.write(chunk)
                tmp.replace(target)
                state["console"].after(0, lambda: state["console"].insert("end",f"✅ server.jar скачан: {target.name}\n"))
                state["console"].after(0, lambda: self._server_refresh(self._find_server_window(state)))
            except Exception as e:
                state["console"].after(0, lambda: state["console"].insert("end",f"❌ Не удалось скачать ядро: {e}\n"))
        threading.Thread(target=worker,daemon=True).start()

    def _server_open_core_page(self,state):
        name=state.get("selected") if state else None
        cfg=self._server_read(name) if name else None
        if not cfg: return
        urls={"Vanilla":"https://www.minecraft.net/download/server","Paper":"https://papermc.io/downloads/paper","Purpur":"https://purpurmc.org/downloads","Fabric":"https://fabricmc.net/use/server/","Forge":"https://minecraftforge.net/","Bedrock Dedicated Server":"https://www.minecraft.net/download/server/bedrock"}
        url=urls.get(cfg.get("core"));
        if url:
            try: subprocess.run(["open",url],check=False)
            except Exception: pass

    def _server_start_selected(self,state):
        name=state.get("selected") if state else None
        cfg=self._server_read(name) if name else None
        if not cfg: return
        if name in self.server_processes and self.server_processes[name].poll() is None:
            state["console"].insert("end","Сервер уже запущен.\n"); return
        if cfg.get("edition")=="Java":
            if cfg.get("launch_mode")=="forge_script":
                script=SERVERS_DIR/name/cfg.get("launch_script","run.sh")
                if not script.exists():
                    state["console"].insert("end","❌ Не найден run.sh/run.bat от Forge.\n"); return
                if not cfg.get("eula"):
                    state["console"].insert("end","❌ Для запуска отметь EULA в server.json/создай сервер с EULA.\n"); return
                if platform.system()=="Windows":
                    cmd=[str(script)]
                else:
                    cmd=["bash",str(script)]
            else:
                core_path=SERVERS_DIR/name/"server.jar"
                if not core_path.exists():
                    state["console"].insert("end","❌ Не найден server.jar. Положи ядро в папку сервера.\n"); return
                if not cfg.get("eula"):
                    state["console"].insert("end","❌ Для запуска отметь EULA в server.json/создай сервер с EULA.\n"); return
                cmd=["java",f"-Xmx{cfg.get('ram','2G')}","-jar","server.jar","nogui"]
        else:
            exe=SERVERS_DIR/name/("bedrock_server.exe" if platform.system()=="Windows" else "bedrock_server")
            if not exe.exists(): state["console"].insert("end","❌ Не найден Bedrock server executable.\n"); return
            cmd=[str(exe)]
        try:
            proc=subprocess.Popen(cmd,cwd=str(SERVERS_DIR/name),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
            self.server_processes[name]=proc
            state["console"].insert("end",f"🟢 Запущен: {' '.join(cmd)}\n")
            def reader():
                try:
                    for line in proc.stdout:
                        state["console"].after(0,lambda line=line: state["console"].insert("end",line))
                except Exception: pass
            threading.Thread(target=reader,daemon=True).start()
            self._server_refresh(self._find_server_window(state))
        except Exception as e: state["console"].insert("end",f"❌ Ошибка запуска: {e}\n")

    def _find_server_window(self,state):
        for w in list(self.open_windows):
            if getattr(w,"_server_state",None) is state: return w
        return None

    def _server_send_command(self,state,cmd_var):
        name=state.get("selected") if state else None
        proc=self.server_processes.get(name) if name else None
        text=cmd_var.get().strip()
        if not text:
            return
        if not proc or proc.poll() is not None:
            state["console"].insert("end","⚠️ Сервер не запущен - сначала нажми «Запустить».\n")
            return
        try:
            proc.stdin.write(text+"\n")
            proc.stdin.flush()
            state["console"].insert("end",f"> {text}\n")
            state["console"].see("end")
        except Exception as e:
            state["console"].insert("end",f"❌ Не удалось отправить команду: {e}\n")
        cmd_var.set("")

    def _server_stop_selected(self,state):
        name=state.get("selected") if state else None
        proc=self.server_processes.get(name) if name else None
        if not proc or proc.poll() is not None:
            state["console"].insert("end","⚪ Сервер уже остановлен.\n"); return
        try:
            cfg=self._server_read(name) or {}
            if cfg.get("edition")=="Java" and proc.stdin:
                proc.stdin.write("stop\n"); proc.stdin.flush()
            else:
                proc.terminate()
            state["console"].insert("end","⏹️ Остановка сервера...\n")
        except Exception as e: state["console"].insert("end",f"❌ Ошибка остановки: {e}\n")

    def store(self):
        """Vanya Store 2.0 — local .vanya application store."""
        win=self.new_window("🛍️ Vanya Store 2.0",820,570)
        self.base(win,"🛍️ Vanya Store 2.0")
        tk.Label(win.content,text="Устанавливай приложения Vanya OS прямо из магазина.",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",12)).pack(anchor="w",padx=12)

        toolbar=tk.Frame(win.content,bg=WINDOW_BG); toolbar.pack(fill="x",padx=12,pady=10)
        self.make_button(toolbar,"📦 Установить .vanya",self.install_vanya,20).pack(side="left",padx=(0,8))
        self.make_button(toolbar,"🔄 Обновить",lambda:self.store_refresh(win),16).pack(side="left")
        status=tk.Label(win.content,text="",bg=WINDOW_BG,fg="#333333",font=("Arial",11)); status.pack(anchor="w",padx=12)
        body=tk.Frame(win.content,bg=WINDOW_BG); body.pack(fill="both",expand=True,padx=12,pady=5)

        catalog=[
            ("vanya_notes_plus","📝 Vanya Notes+","Заметки с быстрым сохранением.","1.0"),
            ("vanya_paint","🎨 Vanya Paint","Простая рисовалка для Vanya OS.","1.0"),
            ("vanya_games_pack","🎮 Vanya Games Pack","Набор мини-игр для Arcade.","1.0"),
            ("vanya_tools","🔧 Vanya Tools","Полезные системные инструменты.","1.0"),
        ]
        for app_id,title,desc,ver in catalog:
            card=tk.Frame(body,bg=CARD,bd=1,relief="solid"); card.pack(fill="x",pady=5)
            tk.Label(card,text=title,bg=CARD,fg=TEXT,font=("Arial",14,"bold"),anchor="w").pack(side="left",padx=12,pady=10)
            tk.Label(card,text=f"v{ver} • {desc}",bg=CARD,fg=MUTED,font=("Arial",10),anchor="w").pack(side="left",fill="x",expand=True)
            installed=(APPS_DIR/app_id).exists()
            def do_install(aid=app_id, t=title, d=desc, v=ver):
                self.install_builtin_app(aid,t,d,v)
                self.store_refresh(win)
            self.make_button(card,"✓ Установлено" if installed else "＋ Установить",lambda f=do_install:f(),16).pack(side="right",padx=10,pady=7)

        tk.Label(body,text="Установленные приложения",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",15,"bold")).pack(anchor="w",pady=(14,5))
        installed=list(APPS_DIR.glob("*/manifest.json"))
        if not installed:
            tk.Label(body,text="Пока ничего не установлено.",bg=WINDOW_BG,fg="#555555",font=("Arial",11)).pack(anchor="w")
        for mf in installed:
            try: data=json.loads(mf.read_text(encoding="utf-8"))
            except Exception: continue
            aid=mf.parent.name; title=data.get("name",aid); desc=data.get("description",""); ver=data.get("version","?")
            row=tk.Frame(body,bg="#ececec"); row.pack(fill="x",pady=2)
            tk.Label(row,text=f"{title}  v{ver}",bg="#ececec",fg="#111111",font=("Arial",11,"bold"),anchor="w").pack(side="left",padx=8,pady=6)
            tk.Label(row,text=desc,bg="#ececec",fg="#444444",anchor="w").pack(side="left",fill="x",expand=True)
            self.make_button(row,"▶ Открыть",lambda a=aid:self.launch_vanya_app(a),16).pack(side="right",padx=6,pady=4)
            self.make_button(row,"🗑 Удалить",lambda a=aid,w=win:self.remove_vanya_app(a,w),15).pack(side="right",pady=4)
        status.config(text=f"📦 Установлено приложений: {len(installed)}")

    def store_refresh(self,win):
        win.close()
        self.after(60,self.store)

    def install_builtin_app(self,app_id,title,desc,version):
        folder=APPS_DIR/app_id; folder.mkdir(parents=True,exist_ok=True)
        manifest={"id":app_id,"name":title,"description":desc,"version":version,"type":"builtin"}
        (folder/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
        messagebox.showinfo("Vanya Store",f"{title} установлено! 🎉\n\nТеперь оно находится в Vanya Store.",parent=self)

    def install_vanya(self):
        path=filedialog.askopenfilename(parent=self,title="Выбери пакет Vanya",filetypes=[("Vanya package","*.vanya"),("ZIP","*.zip"),("Все файлы","*.*")])
        if not path:return
        import zipfile
        try:
            with zipfile.ZipFile(path,"r") as z:
                names=set(z.namelist())
                if "manifest.json" not in names:
                    raise ValueError("В пакете нет manifest.json")
                data=json.loads(z.read("manifest.json").decode("utf-8"))
                aid=str(data.get("id","")).strip()
                if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}",aid): raise ValueError("Неверный id приложения")
                title=str(data.get("name",aid))[:80]
                folder=APPS_DIR/aid; folder.mkdir(parents=True,exist_ok=True)
                for name in z.namelist():
                    target=(folder/name).resolve()
                    if folder.resolve() not in target.parents and target!=folder.resolve(): raise ValueError("Опасный путь в пакете")
                z.extractall(folder)
            messagebox.showinfo("Vanya Store",f"{title} установлено! 📦",parent=self)
        except Exception as e:
            messagebox.showerror("Vanya Store",f"Не удалось установить пакет:\n{e}",parent=self)

    def launch_vanya_app(self,app_id):
        folder=APPS_DIR/app_id; mf=folder/"manifest.json"
        try:data=json.loads(mf.read_text(encoding="utf-8"))
        except Exception as e:
            messagebox.showerror("Vanya Store",f"Не читается приложение:\n{e}",parent=self); return
        title=data.get("name",app_id); desc=data.get("description","")
        # Built-ins use existing Vanya OS functionality; custom packages may provide app.py.
        builtin={"vanya_notes_plus":self.notes,"vanya_paint":lambda:self.run_legacy("vanya_paint"),"vanya_games_pack":self.games,"vanya_tools":self.all_functions}
        if app_id in builtin:
            builtin[app_id](); return
        app_py=folder/"app.py"
        if not app_py.exists():
            win=self.new_window(f"📦 {title}",600,360); self.base(win,title)
            tk.Label(win.content,text=desc or "Приложение установлено, но app.py не найден.",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13),wraplength=520).pack(pady=20)
            return
        # Custom app contract: app.py may define main(parent) or run(parent).
        try:
            spec=importlib.util.spec_from_file_location(f"vanya_app_{app_id}",app_py); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            fn=getattr(mod,"main",None) or getattr(mod,"run",None)
            if not fn: raise ValueError("app.py должен содержать main(parent) или run(parent)")
            fn(self)
        except Exception as e:
            messagebox.showerror("Vanya Store",f"Ошибка запуска {title}:\n{e}",parent=self)

    def remove_vanya_app(self,app_id,win):
        import shutil
        if not messagebox.askyesno("Vanya Store",f"Удалить приложение {app_id}?",parent=self): return
        try: shutil.rmtree(APPS_DIR/app_id); win.close(); self.after(60,self.store)
        except Exception as e: messagebox.showerror("Vanya Store",str(e),parent=self)

    def all_functions(self):
        win=self.new_window("🧰 Все функции Vanya OS 27.1",850,570)
        canvas=tk.Canvas(win.content,bg=WINDOW_BG,highlightthickness=0); sb=tk.Scrollbar(win.content,command=canvas.yview,bg=CARD,activebackground=ACCENT,troughcolor="#20242b",bd=0,highlightthickness=0); inner=tk.Frame(canvas,bg=WINDOW_BG); inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all"))); canvas.create_window((0,0),window=inner,anchor="nw"); canvas.configure(yscrollcommand=sb.set); canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y"); self._enable_trackpad_scroll(canvas,inner)
        for cat,items in FUNCTIONS:
            tk.Label(inner,text=cat,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",15,"bold"),anchor="w").pack(fill="x",padx=12,pady=(12,5))
            grid=tk.Frame(inner,bg=WINDOW_BG); grid.pack(fill="x",padx=8)
            for i,(label,name) in enumerate(items): self.make_button(grid,label,lambda n=name:self.run_legacy(n),26).grid(row=i//3,column=i%3,padx=5,pady=5,sticky="ew")
            for c in range(3):grid.grid_columnconfigure(c,weight=1)
    def run_legacy(self,name):
        if name=="vanya_terminal":
            self.terminal(); return
        direct={"vanya_search":self.vanya_search,"vanya_task_manager":self.vanya_task_manager,"vanya_control_center":self.vanya_control_center,"vanya_workspaces":self.vanya_workspaces,"vanya_theme_studio":self.vanya_theme_studio,"vanya_app_builder":self.vanya_app_builder,"vanya_arcade":self.vanya_arcade,"vanya_developer_mode":self.vanya_developer_mode,"vanya_assistant":self.vanya_assistant,"vanya_users":self.vanya_users,"vanya_network":self.vanya_network,"lock_screen":self.show_lock_screen,"vanya_lock":self.show_lock_screen,"vanya_store":self.store,"vanya_notes":self.notes,"vanya_explorer":self.explorer,"vanya_games":self.games,"vanya_calculator":self.calculator,"vanya_hub":self.vanya_hub,"_mega_backup":self._mega_backup,"_mega_widgets":self._mega_widgets,"vanya_50_plus":self.vanya_50_plus}
        if name in direct:
            direct[name](); return
        if self.legacy_busy:
            messagebox.showinfo("Vanya OS","Сейчас уже выполняется другая функция. Дождись её завершения 🙂",parent=self); return
        path=APP_DIR/"vanya_classic.py"
        try:
            spec=importlib.util.spec_from_file_location("vanya_classic_173",path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            fn=getattr(mod,name)
        except Exception as e:
            messagebox.showerror("Vanya OS",f"Не удалось загрузить {name}:\n{e}",parent=self); return
        win=self.new_window(f"Vanya OS • {name}",720,500)
        out=tk.Text(win.content,bg="#10151d",fg="#e8f0ff",insertbackground="white",font=("Menlo",11),bd=0); out.pack(fill="both",expand=True)
        self.make_button(win.content,"▶ Запустить ещё раз",lambda:self._legacy_execute(mod,fn,out),22).pack(anchor="w",pady=7)
        self._legacy_execute(mod,fn,out)
    def _legacy_execute(self,mod,fn,out):
        """Run a legacy Vanya OS program in a worker thread.

        Terminal-style input is displayed as an internal Vanya OS window, not a
        native macOS dialog. ANSI SGR fragments are removed from the GUI output.
        """
        if self.legacy_busy:
            return
        self.legacy_busy=True
        events=queue.Queue()
        old_print=getattr(mod,"print",builtins.print)
        old_input=getattr(mod,"input",builtins.input)
        old_ask=getattr(mod,"ask",None)
        old_pause=getattr(mod,"pause",None)

        def clean(text):
            # Remove real ANSI escape sequences and bare SGR fragments like [92m/[0m.
            text=str(text)
            text=re.sub(r"\x1b\[(?:\d{1,3}(?:;\d{1,3})*)m", "", text)
            text=re.sub(r"\[(?:\d{1,3}(?:;\d{1,3})*)m", "", text)
            return text

        def p(*args,**kw):
            text=" ".join(map(str,args))
            events.put(("print",clean(text)+kw.get("end","\n")))

        def inp(prompt=""):
            answer_box={"value":""}
            done=threading.Event()
            events.put(("input",clean(prompt),answer_box,done))
            done.wait()
            return answer_box["value"]

        def worker():
            try:
                mod.print=p
                mod.input=inp
                if hasattr(mod,"ask"):
                    mod.ask=lambda prompt="": inp(clean(prompt)).strip()
                if hasattr(mod,"pause"):
                    mod.pause=lambda msg="Нажми Enter, чтобы продолжить...": inp(clean(msg))
                fn()
            except SystemExit:
                pass
            except Exception as e:
                p(f"\n❌ Ошибка в {fn.__name__}: {type(e).__name__}: {e}")
            finally:
                mod.print=old_print
                mod.input=old_input
                if old_ask is not None: mod.ask=old_ask
                if old_pause is not None: mod.pause=old_pause
                events.put(("done",))

        def show_input(prompt,box,done):
            # A real Vanya OS internal window instead of simpledialog/Tk's macOS window.
            iw=self.new_window("Vanya OS • Ввод",520,220)
            tk.Label(iw.content,text=clean(prompt) or "Введи значение:",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold"),wraplength=470,justify="left").pack(anchor="w",padx=16,pady=(12,8))
            entry=tk.Entry(iw.content,bg="#ffffff",fg="#111111",insertbackground="#111111",font=("Arial",13),relief="solid",bd=1)
            entry.pack(fill="x",padx=16,pady=6)
            buttons=tk.Frame(iw.content,bg=WINDOW_BG); buttons.pack(fill="x",padx=16,pady=10)
            # Сохраняем настоящий close() внутреннего окна.
            # Нельзя заменять его функцией finish(), иначе finish() вызовет
            # саму себя по кругу и крестик перестанет закрывать окно.
            original_close=iw.close
            finished=False
            def finish(value=""):
                nonlocal finished
                if finished:
                    return
                finished=True
                box["value"]=value
                done.set()
                original_close()
            self.make_button(buttons,"OK",lambda:finish(entry.get()),10).pack(side="left",padx=(0,8))
            self.make_button(buttons,"Отмена",lambda:finish(""),10).pack(side="left")
            # Крестик и Esc отменяют ввод и разблокируют программу.
            iw.close=lambda:finish("")
            iw.bind("<Escape>",lambda e:finish(""))
            entry.focus_set()
            entry.bind("<Return>",lambda e:finish(entry.get()))

        def pump():
            finished=False
            try:
                while True:
                    ev=events.get_nowait()
                    kind=ev[0]
                    if kind=="print":
                        out.insert("end",ev[1]); out.see("end")
                    elif kind=="input":
                        _,prompt,box,done=ev
                        out.insert("end",clean(prompt)); out.see("end")
                        show_input(prompt,box,done)
                    elif kind=="done":
                        finished=True
            except queue.Empty:
                pass
            if finished:
                self.legacy_busy=False
                out.insert("end","\n[Программа завершена. Можно запустить снова.]\n"); out.see("end")
            else:
                self.after(30,pump)

        out.insert("end",f"▶ Запуск {fn.__name__}...\n")
        threading.Thread(target=worker,daemon=True).start()
        self.after(30,pump)

    # ---------------- Vanya OS 27.1 ----------------
    def _scrollable_window(self, title, w=760, h=520):
        win=self.new_window(title,w,h)
        canvas=tk.Canvas(win.content,bg=WINDOW_BG,highlightthickness=0)
        sb=tk.Scrollbar(win.content,orient="vertical",command=canvas.yview)
        inner=tk.Frame(canvas,bg=WINDOW_BG)
        inner.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all")))
        cw=canvas.create_window((0,0),window=inner,anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left",fill="both",expand=True); sb.pack(side="right",fill="y")
        canvas.bind("<Configure>",lambda e:canvas.itemconfigure(cw,width=max(1,e.width)))
        self._enable_trackpad_scroll(canvas,inner)
        return win,inner

    def vanya_search(self):
        win=self.new_window("🔎 Vanya Search",620,470); self.base(win,"🔎 Vanya Search")
        q=tk.StringVar(); ent=tk.Entry(win.content,textvariable=q,font=("Arial",15),bg="white",fg="#111",insertbackground="#111")
        ent.pack(fill="x",padx=18,pady=12); ent.focus_set()
        result=tk.Frame(win.content,bg=WINDOW_BG); result.pack(fill="both",expand=True,padx=12)
        items=[]
        for cat,vals in FUNCTIONS:
            for label,name in vals: items.append((label,name,cat))
        items += [("🌐 Vanya Hub","vanya_hub","Apps"),("📁 Explorer","vanya_explorer","Apps"),("📝 Notes","vanya_notes","Apps"),("🎮 Games","vanya_games","Apps"),("🛍️ Vanya Store","vanya_store","Apps"),("👤 Users","vanya_users","Apps"),("🌐 Network","vanya_network","Apps"),("🎨 Theme Studio","vanya_theme_studio","Apps"),("🧩 App Builder","vanya_app_builder","Apps"),("🕹️ Vanya Arcade","vanya_arcade","Apps"),("🛠️ Developer Mode","vanya_developer_mode","Apps"),("🧠 Vanya Assistant","vanya_assistant","Apps")]
        def render(*_):
            for x in result.winfo_children(): x.destroy()
            text=q.get().strip().lower()
            matches=[x for x in items if not text or text in (x[0]+" "+x[2]).lower()]
            tk.Label(result,text=f"Найдено: {len(matches)}",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",11,"bold")).pack(anchor="w",padx=8,pady=5)
            for label,name,cat in matches[:40]:
                self.make_button(result,f"{label}  • {cat}",lambda n=name:self.run_legacy(n),36).pack(fill="x",pady=3)
        q.trace_add("write",render); render(); ent.bind("<Return>",lambda e:render())

    def vanya_task_manager(self):
        win,inner=self._scrollable_window("📊 Task Manager 2.0",820,560); self.base(win,"📊 Task Manager 2.0")
        header=tk.Label(inner,text="Процессы macOS + окна Vanya OS",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",12,"bold")); header.pack(anchor="w",padx=12,pady=8)
        table=tk.Text(inner,bg="#10151d",fg="#dce8ff",font=("Menlo",10),height=22,bd=0); table.pack(fill="both",expand=True,padx=10,pady=6)
        def refresh():
            try:
                r=subprocess.run(["ps","-axo","pid,comm,%cpu,%mem"],capture_output=True,text=True,check=False)
                lines=r.stdout.splitlines()[:35]
                table.delete("1.0","end"); table.insert("end","PID     CPU%  MEM%  COMMAND\n"+"\n".join(lines[1:]))
                table.insert("end",f"\n\nОткрытых окон Vanya OS: {len(self.open_windows)}")
            except Exception as e: table.insert("end",f"Ошибка: {e}")
        self.make_button(inner,"🔄 Обновить",refresh,16).pack(anchor="w",padx=10,pady=5); refresh()

    def vanya_control_center(self):
        win=self.new_window("🎛️ Vanya Control Center",650,470); self.base(win,"🎛️ Vanya Control Center")
        tk.Label(win.content,text="Быстрые настройки Vanya OS",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13)).pack(anchor="w",padx=15,pady=8)
        info=tk.Label(win.content,text="",bg=WINDOW_BG,fg="#333",font=("Arial",11),justify="left"); info.pack(anchor="w",padx=15,pady=10)
        def refresh():
            info.config(text=f"Рабочий стол: {self.current_workspace}\nОткрытых окон: {len(self.open_windows)}\nСвернуто: {len(self.minimized_windows)}\nТема: {self.theme_name}")
        for txt,fn in [("🕹️ Переключить рабочие столы",self.vanya_workspaces),("🎨 Открыть Theme Studio",self.vanya_theme_studio),("🔎 Открыть поиск",self.vanya_search),("📊 Task Manager",self.vanya_task_manager)]: self.make_button(win.content,txt,fn,28).pack(pady=5)
        self.make_button(win.content,"🔄 Обновить",refresh,18).pack(pady=8); refresh()

    def vanya_workspaces(self):
        win=self.new_window("🖥️ Vanya Workspaces",620,390); self.base(win,"🖥️ Виртуальные рабочие столы")
        status=tk.Label(win.content,text=f"Сейчас: Рабочий стол {self.current_workspace}",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",14,"bold")); status.pack(pady=15)
        hint=tk.Label(win.content,text="Переключение меняет рабочее пространство Vanya OS и запоминает выбранный номер.",bg=WINDOW_BG,fg="#444",wraplength=520); hint.pack(pady=5)
        buttons=tk.Frame(win.content,bg=WINDOW_BG); buttons.pack(pady=20)
        def switch(n):
            self.current_workspace=n; status.config(text=f"Сейчас: Рабочий стол {n}"); self._notify(f"Переключено на рабочий стол {n}")
        for n in range(1,self.workspace_count+1): self.make_button(buttons,f"🖥️ {n}",lambda n=n:switch(n),10).pack(side="left",padx=6)
        self.make_button(win.content,"⌘1 / ⌘2 / ⌘3",lambda:self._notify("Быстрое переключение рабочих столов готово в панели Workspaces"),24).pack(pady=5)

    def _notify(self,text):
        # Lightweight notification without native dialogs.
        note=tk.Label(self,bg="#151b24",fg="white",text="  🔔 "+text+"  ",font=("Arial",11,"bold"),bd=1,relief="solid")
        note.place(relx=0.5,rely=0.075,anchor="n"); self.after(2200,note.destroy)

    def vanya_theme_studio(self):
        win=self.new_window("🎨 Vanya Theme Studio",700,520); self.base(win,"🎨 Vanya Theme Studio")
        name=tk.StringVar(value=self.theme_name)
        tk.Label(win.content,text="Название темы",bg=WINDOW_BG,fg=WINDOW_TEXT).pack(anchor="w",padx=18,pady=(8,3)); tk.Entry(win.content,textvariable=name,bg="white",fg="#111",font=("Arial",12)).pack(fill="x",padx=18)
        preview=tk.Frame(win.content,bg=BG,height=130); preview.pack(fill="x",padx=18,pady=15); preview.pack_propagate(False)
        tk.Label(preview,text="VANYA OS 27.1",bg=BG,fg=TEXT,font=("Arial",22,"bold")).pack(pady=35)
        status=tk.Label(win.content,text="Можно сохранить тему локально.",bg=WINDOW_BG,fg="#444"); status.pack()
        def save():
            self.theme_name=name.get().strip() or "Vanya Theme"
            data={"name":self.theme_name,"bg":BG,"panel":PANEL,"accent":ACCENT,"window_bg":WINDOW_BG}
            try: self.theme_path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8"); status.config(text="✓ Тема сохранена в vanya_theme.json"); self._notify("Тема сохранена")
            except Exception as e: status.config(text=f"Ошибка: {e}")
        def load():
            try:
                data=json.loads(self.theme_path.read_text(encoding="utf-8")); self.theme_name=data.get("name","Vanya Theme"); name.set(self.theme_name); status.config(text="✓ Тема загружена")
            except Exception: status.config(text="Сохранённой темы пока нет.")
        self.make_button(win.content,"💾 Сохранить тему",save,22).pack(pady=8); self.make_button(win.content,"📂 Загрузить тему",load,22).pack(pady=4)

    def vanya_app_builder(self):
        win=self.new_window("🧩 Vanya App Builder",760,570); self.base(win,"🧩 Vanya App Builder")
        name=tk.StringVar(value="Моё приложение"); aid=tk.StringVar(value="my_app")
        for label,var in (("Название",name),("ID (латиница)",aid)):
            tk.Label(win.content,text=label,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",11,"bold")).pack(anchor="w",padx=14,pady=(5,2)); tk.Entry(win.content,textvariable=var,bg="white",fg="#111").pack(fill="x",padx=14)
        code=tk.Text(win.content,bg="#10151d",fg="#dce8ff",insertbackground="white",font=("Menlo",10),height=15); code.pack(fill="both",expand=True,padx=14,pady=10)
        code.insert("1.0",'def main(parent):\n    import tkinter as tk\n    win = parent.new_window("Моё приложение", 500, 350)\n    parent.base(win, "Моё приложение")\n    tk.Label(win.content, text="Привет из моего .vanya!", bg="#d3d3d3", fg="#111").pack(pady=30)\n')
        status=tk.Label(win.content,text="Создаёт настоящий .vanya-пакет с manifest.json + app.py",bg=WINDOW_BG,fg="#444"); status.pack(anchor="w",padx=14)
        def build():
            raw=re.sub(r"[^A-Za-z0-9_-]","_",aid.get().strip())[:40] or "my_app"; title=name.get().strip() or raw
            folder=APP_DIR/"packages"; folder.mkdir(exist_ok=True); temp=folder/raw; temp.mkdir(exist_ok=True)
            manifest={"id":raw,"name":title,"description":"Приложение, созданное Vanya App Builder","version":"1.0","type":"python"}
            (temp/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8"); (temp/"app.py").write_text(code.get("1.0","end-1c"),encoding="utf-8")
            import zipfile
            out=folder/(raw+".vanya")
            with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
                z.write(temp/"manifest.json","manifest.json"); z.write(temp/"app.py","app.py")
            status.config(text=f"✓ Создано: packages/{out.name}"); self._notify(".vanya приложение создано")
        self.make_button(win.content,"📦 Собрать .vanya",build,22).pack(pady=7)

    def vanya_arcade(self):
        win,inner=self._scrollable_window("🕹️ Vanya Arcade",700,540); self.base(win,"🕹️ Vanya Arcade")
        games=[("🐍 Snake","mini_snake"),("🧠 Memory","memory_game"),("⚡ Reaction","reaction_game"),("🎲 Dice","dice_roll"),("🏓 Pong","vanya_pong"),("🧩 Tetris","vanya_tetris"),("🐔 Chickingan","chickingan_game"),("🧠 Memory 2","vanya_memory2"),("⛏️ Minecraft","minecraft"),("🔠 Большие буковки","big_letters")]
        for title,name in games: self.make_button(inner,title,lambda n=name:self.run_game(n),28).pack(pady=4)
        tk.Label(inner,text="🏆 Достижения",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",14,"bold")).pack(anchor="w",padx=10,pady=(18,5))
        for text in ("🏆 Первая игра","⭐ 10 игр","🔥 Игровой день","🧠 Мастер памяти"): tk.Label(inner,text=text,bg=WINDOW_BG,fg="#333",font=("Arial",11)).pack(anchor="w",padx=18,pady=2)

    def vanya_developer_mode(self):
        win,inner=self._scrollable_window("🛠️ Vanya Developer Mode",780,550); self.base(win,"🛠️ Developer Mode")
        tk.Label(inner,text="Инструменты разработчика Vanya OS 27.1",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")).pack(anchor="w",padx=12,pady=8)
        log=tk.Text(inner,bg="#0d1117",fg="#cfe3ff",font=("Menlo",10),height=16,bd=0); log.pack(fill="both",expand=True,padx=10,pady=5)
        def refresh():
            log.delete("1.0","end")
            log.insert("end",f"Vanya OS 27.1\nPython: {platform.python_version()}\nPlatform: {platform.platform()}\nWorkspace: {self.current_workspace}\nOpen windows: {len(self.open_windows)}\nApps: {len(list(APPS_DIR.glob('*')))}\nMods: {len(list(MODS_DIR.glob('*.txt')))}\n\nFunctions: {sum(len(x[1]) for x in FUNCTIONS)}")
        for text,fn in (("🔄 Refresh logs",refresh),("📊 Task Manager",self.vanya_task_manager),("🧩 App Builder",self.vanya_app_builder),("🛍️ Vanya Store",self.store)): self.make_button(inner,text,fn,24).pack(anchor="w",padx=10,pady=4)
        refresh()

    def vanya_assistant(self):
        win=self.new_window("🧠 Vanya Assistant",650,500); self.base(win,"🧠 Vanya Assistant")
        tk.Label(win.content,text="Локальный помощник Vanya OS",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13)).pack(anchor="w",padx=15,pady=5)
        out=tk.Text(win.content,bg="#10151d",fg="#dce8ff",font=("Menlo",11),height=14,bd=0); out.pack(fill="both",expand=True,padx=12,pady=8)
        ent=tk.Entry(win.content,bg="white",fg="#111",font=("Arial",12)); ent.pack(fill="x",padx=12,pady=5)
        answers={"python":"Python — язык программирования. Vanya OS построена на Python + Tkinter.","ошибка":"Посмотри последнюю строку traceback: там обычно находится причина сбоя.","игры":"Открой 🕹️ Vanya Arcade или 🎮 Games. Там Snake, Memory, Pong и другие игры.","моды":"Моды лежат в папке mods и управляются через Mod Manager.","store":"Vanya Store устанавливает локальные .vanya приложения.","пользователь":"Открой Users или нажми Ctrl+L, чтобы открыть экран выбора пользователя.","сеть":"Открой Vanya Network для диагностики локальной сети.","backup":"Резервные копии создаются через Vanya Backup.","тема":"Theme Studio сохраняет локальные темы в vanya_theme.json.","помощь":"Попробуй: python, ошибка, игры, моды, store, пользователь, сеть, backup, тема."}
        def ask(_=None):
            q=ent.get().strip().lower(); ent.delete(0,"end"); out.insert("end",f"Ты: {q}\n")
            ans=next((v for k,v in answers.items() if k in q),"Я пока локальный помощник. Попробуй спросить про Python, ошибки, игры, моды или Store.")
            out.insert("end",f"Ваня: {ans}\n\n"); out.see("end")
        ent.bind("<Return>",ask); out.insert("end","Ваня: Привет! Чем помочь? 🙂\n\n")

    def big_letters_game(self):
        """Игра 'Большие буковки' - печатает текст огромными буквами.
        Сначала пробует настоящий pyfiglet (и сама ставит его, если нет),
        а если не получилось - использует свой встроенный 5x5 шрифт."""
        win=self.new_window("🔠 Большие буковки",760,500); self.base(win,"🔠 Большие буковки")
        tk.Label(win.content,text="Введи текст и нажми «Показать» - увидишь его огромными буквами!",
                 bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",12)).pack(anchor="w",padx=12,pady=(10,4))

        row=tk.Frame(win.content,bg=WINDOW_BG); row.pack(fill="x",padx=12)
        entry=tk.Entry(row,font=("Arial",13)); entry.pack(side="left",fill="x",expand=True,ipady=4)

        status=tk.Label(win.content,text="⏳ Проверяю pyfiglet...",bg=WINDOW_BG,fg="#555555",font=("Arial",10))
        status.pack(anchor="w",padx=12,pady=(4,0))

        out=tk.Text(win.content,bg="#0b0f15",fg="#8be28b",font=("Menlo",11),bd=0)
        out.pack(fill="both",expand=True,padx=12,pady=8)

        state={"pyfiglet_ready":False,"checked":False}

        def ensure_pyfiglet():
            if state["checked"]:
                return
            state["checked"]=True
            try:
                import pyfiglet  # noqa: F401
                state["pyfiglet_ready"]=True
                status.config(text="✅ Используется настоящий pyfiglet (FIGlet)")
                return
            except ImportError:
                pass
            status.config(text="⏳ pyfiglet не установлен, пробую установить автоматически...")
            win.update_idletasks()
            try:
                result=subprocess.run(
                    [sys.executable,"-m","pip","install","pyfiglet"],
                    capture_output=True,text=True,timeout=90
                )
                if result.returncode==0:
                    try:
                        import pyfiglet  # noqa: F401
                        state["pyfiglet_ready"]=True
                        status.config(text="✅ pyfiglet установлен и подключён!")
                        return
                    except ImportError:
                        pass
                status.config(text="⚠️ Не удалось установить pyfiglet - использую встроенный запасной шрифт")
            except Exception as e:
                status.config(text=f"⚠️ Ошибка установки pyfiglet ({e}) - использую встроенный запасной шрифт")

        def render_fallback(text):
            rows=["","","","",""]
            for ch in text.upper():
                glyph=FALLBACK_FONT.get(ch,FALLBACK_FONT[" "])
                for i in range(5):
                    rows[i]+=glyph[i].replace("#","█").replace(".", " ")+"  "
            return "\n".join(rows)

        def show(_=None):
            text=entry.get().strip()
            out.delete("1.0","end")
            if not text:
                return
            if state["pyfiglet_ready"]:
                try:
                    import pyfiglet
                    out.insert("end",pyfiglet.figlet_format(text))
                    return
                except Exception as e:
                    status.config(text=f"⚠️ pyfiglet дал сбой ({e}) - использую встроенный шрифт")
            out.insert("end",render_fallback(text))

        entry.bind("<Return>",show)
        self.make_button(win.content,"🔠 Показать",show,18).pack(pady=(0,10))
        win.after(50,ensure_pyfiglet)

    def game_center(self):
        """Game Center - единый центр всех игр Vanya OS, с категориями."""
        win,inner=self._scrollable_window("🎮 Game Center",720,560); self.base(win,"🎮 Game Center")
        tk.Label(inner,text="Добро пожаловать в Game Center!",bg=WINDOW_BG,fg=WINDOW_TEXT,
                 font=("Arial",15,"bold")).pack(anchor="w",padx=12,pady=(10,4))

        categories=[
            ("🕹️ Классика",[("🐍 Snake","mini_snake"),("🏓 Pong","vanya_pong"),("🧩 Tetris","vanya_tetris")]),
            ("🧠 На сообразительность",[("🧠 Memory","memory_game"),("🧠 Memory 2","vanya_memory2"),("⚡ Reaction","reaction_game")]),
            ("🎲 Разное",[("🎲 Кубик","dice_roll"),("🐔 Chickingan","chickingan_game"),("🔠 Большие буковки","big_letters")]),
            ("⛏️ Miner",[("⛏️ Minecraft","minecraft")]),
        ]
        for cat_name,games in categories:
            tk.Label(inner,text=cat_name,bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")).pack(anchor="w",padx=12,pady=(14,4))
            row=tk.Frame(inner,bg=WINDOW_BG); row.pack(fill="x",padx=12)
            for title,key in games:
                self.make_button(row,title,lambda k=key:self.run_game(k),18).pack(side="left",padx=4,pady=2)

        tk.Label(inner,text="🏆 Достижения",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")).pack(anchor="w",padx=12,pady=(18,4))
        for text in ("🏆 Первая игра","⭐ 10 игр","🔥 Игровой день","🧠 Мастер памяти","🔠 Мастер букв"):
            tk.Label(inner,text=text,bg=WINDOW_BG,fg="#333333",font=("Arial",11)).pack(anchor="w",padx=20,pady=1)

    def vanya_recovery(self):
        """Recovery - восстановление и починка Vanya OS."""
        win,inner=self._scrollable_window("🧰 Vanya Recovery",700,520); self.base(win,"🧰 Recovery")
        tk.Label(inner,text="Инструменты восстановления Vanya OS",bg=WINDOW_BG,fg=WINDOW_TEXT,
                 font=("Arial",14,"bold")).pack(anchor="w",padx=12,pady=(10,4))
        tk.Label(inner,text="Если что-то сломалось - попробуй один из вариантов ниже.",
                 bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",11)).pack(anchor="w",padx=12,pady=(0,10))

        log=tk.Text(inner,bg="#0d1117",fg="#cfe3ff",font=("Menlo",10),height=10,bd=0)
        log.pack(fill="both",expand=True,padx=12,pady=6)

        def report(text):
            log.insert("end",text+"\n"); log.see("end")

        def check_files():
            report("🔍 Проверка целостности файлов Vanya OS...")
            required=["vanya_os.py","vanya_desktop.py","wallpaper.png"]
            ok=True
            for name in required:
                path=APP_DIR/name
                if path.exists():
                    report(f"  ✅ {name}")
                else:
                    report(f"  ❌ {name} - не найден!")
                    ok=False
            report("✅ Все файлы на месте!" if ok else "⚠️ Некоторые файлы отсутствуют.")

        def reset_settings():
            if not messagebox.askyesno("Recovery","Сбросить настройки Vanya OS к значениям по умолчанию?"):
                return
            try:
                settings_path=APP_DIR/"vanya_settings.txt"
                if settings_path.exists():
                    backup_path=APP_DIR/"vanya_settings.txt.bak"
                    shutil.copy(settings_path,backup_path)
                    settings_path.unlink()
                report("♻️ Настройки сброшены (старые сохранены в vanya_settings.txt.bak)")
            except Exception as e:
                report(f"❌ Ошибка сброса настроек: {e}")

        def restore_backup():
            backups_dir=APP_DIR/"backups"
            if not backups_dir.exists():
                report("⚠️ Папка backups не найдена - ещё не было ни одной резервной копии.")
                return
            backups=sorted(backups_dir.glob("*.zip"),key=lambda p:p.stat().st_mtime,reverse=True)
            if not backups:
                report("⚠️ Резервных копий пока нет.")
                return
            latest=backups[0]
            if not messagebox.askyesno("Recovery",f"Восстановить из {latest.name}?"):
                return
            try:
                restore_dir=APP_DIR/"restored_backup"
                restore_dir.mkdir(exist_ok=True)
                with zipfile.ZipFile(latest,"r") as z:
                    z.extractall(restore_dir)
                report(f"✅ Восстановлено в папку: {restore_dir}")
            except Exception as e:
                report(f"❌ Ошибка восстановления: {e}")

        def clear_cache():
            try:
                removed=0
                for pycache in APP_DIR.rglob("__pycache__"):
                    shutil.rmtree(pycache,ignore_errors=True); removed+=1
                report(f"🧹 Очищено папок __pycache__: {removed}")
            except Exception as e:
                report(f"❌ Ошибка очистки кэша: {e}")

        actions=tk.Frame(inner,bg=WINDOW_BG); actions.pack(fill="x",padx=12,pady=6)
        self.make_button(actions,"🔍 Проверить файлы",check_files,20).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"♻️ Сбросить настройки",reset_settings,20).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"💾 Восстановить backup",restore_backup,20).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"🧹 Очистить кэш",clear_cache,18).pack(side="left",padx=4,pady=4)
        report("🧰 Recovery готов к работе. Выбери действие выше.")

    def vanya_archive(self):
        """Archive - настоящий архиватор: создаёт и распаковывает .zip/.vzip файлы."""
        win,inner=self._scrollable_window("🗜️ Vanya Archive",700,520); self.base(win,"🗜️ Archive")
        tk.Label(inner,text="Архиватор Vanya OS (на основе ZIP)",bg=WINDOW_BG,fg=WINDOW_TEXT,
                 font=("Arial",14,"bold")).pack(anchor="w",padx=12,pady=(10,4))

        log=tk.Text(inner,bg="#0d1117",fg="#cfe3ff",font=("Menlo",10),height=12,bd=0)
        log.pack(fill="both",expand=True,padx=12,pady=8)

        def report(text):
            log.insert("end",text+"\n"); log.see("end")

        def create_archive():
            paths=filedialog.askopenfilenames(title="Выбери файлы для архива")
            if not paths:
                return
            out_path=filedialog.asksaveasfilename(
                title="Сохранить архив как",defaultextension=".vzip",
                filetypes=[("Vanya Archive","*.vzip"),("ZIP архив","*.zip")]
            )
            if not out_path:
                return
            try:
                with zipfile.ZipFile(out_path,"w",zipfile.ZIP_DEFLATED) as z:
                    for p in paths:
                        z.write(p,arcname=os.path.basename(p))
                report(f"✅ Архив создан: {out_path} ({len(paths)} файл(ов))")
            except Exception as e:
                report(f"❌ Ошибка создания архива: {e}")

        def extract_archive():
            archive_path=filedialog.askopenfilename(
                title="Выбери архив для распаковки",
                filetypes=[("Архивы","*.vzip *.zip"),("Все файлы","*.*")]
            )
            if not archive_path:
                return
            target_dir=filedialog.askdirectory(title="Куда распаковать?")
            if not target_dir:
                return
            try:
                with zipfile.ZipFile(archive_path,"r") as z:
                    names=z.namelist()
                    z.extractall(target_dir)
                report(f"✅ Распаковано {len(names)} файл(ов) в {target_dir}")
            except zipfile.BadZipFile:
                report("❌ Это не похоже на настоящий архив (повреждён или не ZIP).")
            except Exception as e:
                report(f"❌ Ошибка распаковки: {e}")

        def list_archive():
            archive_path=filedialog.askopenfilename(
                title="Выбери архив, чтобы посмотреть содержимое",
                filetypes=[("Архивы","*.vzip *.zip"),("Все файлы","*.*")]
            )
            if not archive_path:
                return
            try:
                with zipfile.ZipFile(archive_path,"r") as z:
                    report(f"📦 Содержимое {os.path.basename(archive_path)}:")
                    for info in z.infolist():
                        size_kb=info.file_size/1024
                        report(f"   • {info.filename} ({size_kb:.1f} КБ)")
            except Exception as e:
                report(f"❌ Не удалось прочитать архив: {e}")

        actions=tk.Frame(inner,bg=WINDOW_BG); actions.pack(fill="x",padx=12,pady=6)
        self.make_button(actions,"🗜️ Создать архив",create_archive,20).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"📂 Распаковать",extract_archive,18).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"👁️ Содержимое",list_archive,16).pack(side="left",padx=4,pady=4)
        report("🗜️ VZIP — архив Vanya OS на основе настоящего ZIP-формата.")

    def vanya_ai_lab(self):
        """AI Lab - весёлые офлайн-игрушки в стиле ИИ (без интернета)."""
        win,inner=self._scrollable_window("🤖 AI Lab",700,560); self.base(win,"🤖 AI Lab")
        tk.Label(inner,text="Лаборатория мини-ИИ игрушек Vanya OS (всё работает офлайн)",
                 bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")).pack(anchor="w",padx=12,pady=(10,8))

        out=tk.Text(inner,bg="#0b0f15",fg="#bfe9c9",font=("Menlo",11),height=12,bd=0)
        out.pack(fill="both",expand=True,padx=12,pady=6)

        def report(text):
            out.insert("end",text+"\n\n"); out.see("end")

        def magic_8ball():
            answers=["Да, определённо!","Не думаю.","Спроси позже.","Точно да!",
                      "Маловероятно.","Мои источники говорят «да».","Сложно сказать.",
                      "Даже не думай.","100% да!","Скорее нет."]
            report("🎱 Магический шар говорит: "+random.choice(answers))

        mobs=[
            ("Крипер",["Тссс... БУМ! Ладно, шучу, я мирный сегодня.","Я просто хотел обнять тебя. Честно."]),
            ("Зомби",["Ммм... блоки...","Я не ем игроков, только двери."]),
            ("Эндермен",["Не смотри мне в глаза! ...Ну ладно, смотри.","Телепортируюсь домой, увидимся."]),
        ]
        def mob_fortune():
            name,phrases=random.choice(mobs)
            report(f"🧟 {name} говорит: \"{random.choice(phrases)}\"")

        def markov_from_notes():
            notes_dir=APP_DIR/"notes"
            words=[]
            if notes_dir.exists():
                for f in notes_dir.glob("*.txt"):
                    try:
                        words+=f.read_text(encoding="utf-8",errors="ignore").split()
                    except Exception:
                        pass
            if len(words) < 5:
                report("🤖 Маловато текста в заметках (Notes), чтобы что-то придумать. "
                       "Напиши несколько заметок и попробуй снова!")
                return
            chain={}
            for a,b in zip(words,words[1:]):
                chain.setdefault(a,[]).append(b)
            start=random.choice(words)
            result=[start]
            current=start
            for _ in range(14):
                nexts=chain.get(current)
                if not nexts:
                    break
                current=random.choice(nexts)
                result.append(current)
            report("🤖 Придумал фразу из твоих заметок: \""+" ".join(result)+"\"")

        actions=tk.Frame(inner,bg=WINDOW_BG); actions.pack(fill="x",padx=12,pady=6)
        self.make_button(actions,"🎱 Магический шар",magic_8ball,20).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"🧟 Мудрость моба",mob_fortune,20).pack(side="left",padx=4,pady=4)
        self.make_button(actions,"📝 Придумать из заметок",markov_from_notes,22).pack(side="left",padx=4,pady=4)
        report("🤖 Добро пожаловать в AI Lab! Выбери одну из игрушек выше.")

    def vanya_lab(self):
        """Lab - мини-лаборатория: можно писать и сразу запускать код Python."""
        win,inner=self._scrollable_window("🧪 Vanya Lab",760,560); self.base(win,"🧪 Lab")
        tk.Label(inner,text="Мини-лаборатория кода: пиши Python и сразу запускай!",
                 bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",13,"bold")).pack(anchor="w",padx=12,pady=(10,6))

        code_box=tk.Text(inner,bg="#0d1117",fg="#e6edf3",font=("Menlo",11),height=10,bd=0)
        code_box.pack(fill="both",expand=True,padx=12,pady=4)
        code_box.insert("1.0","print('Привет из Vanya Lab!')")

        tk.Label(inner,text="Результат:",bg=WINDOW_BG,fg=WINDOW_TEXT,font=("Arial",11,"bold")).pack(anchor="w",padx=12,pady=(8,2))
        result_box=tk.Text(inner,bg="#0b0f15",fg="#8be28b",font=("Menlo",10),height=8,bd=0)
        result_box.pack(fill="both",expand=True,padx=12,pady=(0,8))

        def run_code():
            code=code_box.get("1.0","end")
            result_box.delete("1.0","end")
            script_path=APP_DIR/"sandbox"/"_lab_run.py"
            script_path.parent.mkdir(exist_ok=True)
            try:
                script_path.write_text(code,encoding="utf-8")
                proc=subprocess.run([sys.executable,str(script_path)],
                                     capture_output=True,text=True,timeout=10)
                if proc.stdout:
                    result_box.insert("end",proc.stdout)
                if proc.stderr:
                    result_box.insert("end",proc.stderr)
                if not proc.stdout and not proc.stderr:
                    result_box.insert("end","(код выполнен, но ничего не напечатал)")
            except subprocess.TimeoutExpired:
                result_box.insert("end","⏱️ Код выполнялся слишком долго (больше 10 секунд) и был остановлен.")
            except Exception as e:
                result_box.insert("end",f"❌ Ошибка запуска: {e}")

        actions=tk.Frame(inner,bg=WINDOW_BG); actions.pack(fill="x",padx=12,pady=(0,10))
        self.make_button(actions,"▶ Запустить код",run_code,20).pack(side="left",padx=4)
        tk.Label(actions,text="⚠️ Код выполняется на 10 секунд, без доступа к остальной Vanya OS",
                 bg=WINDOW_BG,fg="#666666",font=("Arial",9)).pack(side="left",padx=10)

    def __del__(self): pass

if __name__=="__main__": VanyaDesktop().mainloop()
